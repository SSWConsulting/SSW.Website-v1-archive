-- GETWORDCOUNT, GETWORDNUM, AT, RAT, OCCURS, PADC, PADR, PADL, PROPER, RCHARINDEX, ARABTOROMAN, ROMANTOARAB
-- GETWORDCOUNT() Counts the words in a string
-- GETWORDNUM()   Returns a specified word from a string
-- AT()  Returns the beginning numeric position of the first occurrence of a character expression within
--       another character expression, counting from the leftmost character
-- RAT() Returns the numeric position of the last (rightmost) occurrence of a character string within 
--       another character string
-- OCCURS() Returns the number of times a character expression occurs within another character expression
-- PADL()   Returns a string from an expression, padded with spaces or characters to a specified length on the left side
-- PADR()   Returns a string from an expression, padded with spaces or characters to a specified length on the right side
-- PADC()   Returns a string from an expression, padded with spaces or characters to a specified length on the both sides
-- PROPER() Returns from a character expression a string capitalized as appropriate for proper names
-- RCHARINDEX()  Is similar to a built-in function Transact-SQL charindex but the search of which is on the right
-- ARABTOROMAN() Returns the character Roman number equivalent of a specified numeric expression 
-- ROMANTOARAB() Returns the number equivalent of a specified character Roman number expression 
-- Examples:   GETWORDCOUNT, GETWORDNUM
-- select  dbo.GETWORDCOUNT('User-Defined marvellous string Functions Transact-SQL', default)
-- select  dbo.GETWORDNUM('User-Defined marvellous string Functions Transact-SQL', 2, default)
-- AT, RAT, OCCURS, PROPER  
-- select  dbo.AT ('marvellous', 'User-Defined marvellous string Functions Transact-SQL', default)
-- select  dbo.OCCURS ('F', 'User-Defined marvellous string Functions Transact-SQL')
-- select  dbo.PROPER ('User-Defined marvellous string Functions Transact-SQL')
-- PADC, PADR, PADL 
-- select  dbo.PADC (' marvellous string Functions', 60, '*')
-- ARABTOROMAN, ROMANTOARAB
-- select dbo.ARABTOROMAN(3888)      -- Displays MMMDCCCLXXXVIII
-- select dbo.ROMANTOARAB('CCXXXIV') -- Displays 234
--------------------------------------------------------------------------------------------------------
-- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca   
-- AT() User-Defined Function 
-- Returns the beginning numeric position of the first occurrence of a character expression within another character expression, counting from the leftmost character.
-- AT(@cSearchExpression, @cExpressionSearched [, @nOccurrence]) Return Values smallint 
-- Parameters
-- @cSearchExpression nvarchar(4000) Specifies the character expression that AT( ) searches for in @cExpressionSearched. 
-- @cExpressionSearched nvarchar(4000) Specifies the character expression @cSearchExpression searches for. 
-- @nOccurrence smallint Specifies which occurrence (first, second, third, and so on) of @cSearchExpression is searched for in @cExpressionSearched. By default, AT() searches for the first occurrence of @cSearchExpression (@nOccurrence = 1). Including @nOccurrence lets you search for additional occurrences of @cSearchExpression in @cExpressionSearched. AT( ) returns 0 if @nOccurrence is greater than the number of times @cSearchExpression occurs in @cExpressionSearched. 
-- Remarks AT() searches the second character expression for the first occurrence of the first character expression. It then returns an integer indicating the position of the first character in the character expression found. If the character expression isn't found, AT() returns 0. The search performed by AT() is case-sensitive.
-- Example
-- declare @gcString nvarchar(4000), @gcFindString nvarchar(4000)
-- select @gcString = 'Now is the time for all good men', @gcFindString = 'is the'
-- select dbo.AT(@gcFindString, @gcString, default)  -- Displays 5
-- set @gcFindString = 'IS'
-- select dbo.AT(@gcFindString, @gcString, default)  -- Displays 0, case-sensitive
-- See Also RAT()  User-Defined Function 
-- UDF the name and functionality of which correspond  to the same built-in functions of Visual FoxPro
CREATE function AT  (@cSearchExpression nvarchar(4000), @cExpressionSearched  nvarchar(4000), @nOccurrence  smallint = 1 )
returns smallint
as
    begin
      if @nOccurrence > 0
         begin
            declare @i smallint,  @StartingPosition  smallint
            select  @i = 1, @StartingPosition  = dbo.CHARINDEX_BIN(@cSearchExpression, @cExpressionSearched, 1)
            while  @StartingPosition <> 0 and @nOccurrence > @i
               select  @i = @i + 1, @StartingPosition  = dbo.CHARINDEX_BIN(@cSearchExpression, @cExpressionSearched,  @StartingPosition+1 )
         end
      else
         set @StartingPosition =  NULL

     return @StartingPosition
    end
GO

-- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca 
-- RAT( ) User-Defined Function
-- Returns the numeric position of the last (rightmost) occurrence of a character string within another character string.
-- RAT(@cSearchExpression, @cExpressionSearched [, @nOccurrence])
-- Return Values smallint 
-- Parameters
-- @cSearchExpression nvarchar(4000) Specifies the character expression that RAT( ) looks for in @cExpressionSearched. 
-- @cExpressionSearched nvarchar(4000) Specifies the character expression that RAT() searches. 
-- @nOccurrence smallint Specifies which occurrence, starting from the right and moving left, of @cSearchExpression RAT() searches for in @cExpressionSearched. By default, RAT() searches for the last occurrence of @cSearchExpression (@nOccurrence = 1). If @nOccurrence is 2, RAT() searches for the next to last occurrence, and so on. 
-- Remarks
-- RAT(), the reverse of the AT() function, searches the character expression in @cExpressionSearched starting from the right and moving left, looking for the last occurrence of the string specified in @cSearchExpression.
-- RAT() returns an integer indicating the position of the first character in @cSearchExpression in @cExpressionSearched. RAT() returns 0 if @cSearchExpression isn't found in @cExpressionSearched, or if @nOccurrence is greater than the number of times @cSearchExpression occurs in @cExpressionSearched.
-- The search performed by RAT() is case-sensitive.
-- Example
-- declare @gcString nvarchar(4000), @gcFindString nvarchar(4000)
-- select @gcString = 'abracadabra', @gcFindString = 'a' 
-- select dbo.RAT(@gcFindString , @gcString, default)  -- Displays 11
-- select dbo.RAT(@gcFindString , @gcString , 3)       -- Displays 6
-- See Also AT()  User-Defined Function 
-- UDF the name and functionality of which correspond  to the same built-in functions of Visual FoxPro   
CREATE function RAT  (@cSearchExpression nvarchar(4000), @cExpressionSearched  nvarchar(4000), @nOccurrence  smallint = 1 )
returns smallint
as
    begin
      if @nOccurrence > 0
         begin
            declare @i smallint, @length smallint, @StartingPosition  smallint
            select  @i = 1, @length  = datalength(@cExpressionSearched)/(case SQL_VARIANT_PROPERTY(@cExpressionSearched,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode
            select  @StartingPosition  = dbo.RCHARINDEX(@cSearchExpression, @cExpressionSearched, 1)
            while @StartingPosition <> 0 and @nOccurrence > @i
               select  @i = @i + 1, @StartingPosition  = dbo.RCHARINDEX(@cSearchExpression, @cExpressionSearched,  @length - @StartingPosition + 2 )
         end
      if @StartingPosition <> 0
         select @StartingPosition = @StartingPosition + 1  - datalength(@cSearchExpression)/(case SQL_VARIANT_PROPERTY(@cSearchExpression,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode
      else
         set @StartingPosition =  NULL

     return @StartingPosition
    end
GO

 -- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca 
 -- PADL(), PADR(), PADC() User-Defined Functions
 -- Returns a string from an expression, padded with spaces or characters to a specified length on the left or right sides, or both.
 -- PADL(@eExpression, @nResultSize [, @cPadCharacter]) -Or-
 -- PADR(@eExpression, @nResultSize [, @cPadCharacter]) -Or-
 -- PADC(@eExpression, @nResultSize [, @cPadCharacter])
 -- Return Values nvarchar(4000)
 -- 
 -- Parameters
 -- @eExpression nvarchar(4000) Specifies the expression to be padded.
 -- @nResultSize  smallint Specifies the total number of characters in the expression after it is padded. 
 -- @cPadCharacter nvarchar(4000) Specifies the value to use for padding. This value is repeated as necessary to pad the expression to the specified number of characters. 
 -- If you omit @cPadCharacter, spaces (ASCII character 32) are used for padding. 
 -- 
 -- Remarks
 -- PADL() inserts padding on the left, PADR() inserts padding on the right, and PADC() inserts padding on both sides.
 -- 
 -- Example
 -- declare @gcString  nvarchar(4000)
 -- select @gcString  = 'TITLE' 
 -- select dbo.PADL(@gcString, 40, default)
 -- select dbo.PADL(@gcString, 40, '=')
 -- select dbo.PADR(@gcString, 40, '=')
 -- select dbo.PADC(@gcString, 40, '=')  
 -- UDF the name and functionality of which correspond  to the same built-in functions of Visual FoxPro 
CREATE function PADC  (@cSrting nvarchar(4000), @nLen smallint, @cPadCharacter nvarchar(4000) = ' ' )
returns nvarchar(4000)
as
      begin
        declare @length smallint, @lengthPadCharacter smallint
        select  @length  = datalength(@cSrting)/(case SQL_VARIANT_PROPERTY(@cSrting,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode
        select  @lengthPadCharacter  = datalength(@cPadCharacter)/(case SQL_VARIANT_PROPERTY(@cPadCharacter,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode

	if @length >= @nLen
	   set  @cSrting = left(@cSrting, @nLen)
	else
	   begin
              declare @nLeftLen smallint, @nRightLen smallint
              set @nLeftLen = (@nLen - @length )/2            -- Quantity of characters, added at the left
              set @nRightLen  =  @nLen - @length - @nLeftLen  -- Quantity of characters, added on the right
              set @cSrting = left(replicate(@cPadCharacter, ceiling(@nLeftLen/@lengthPadCharacter) + 2), @nLeftLen)+ @cSrting + left(replicate(@cPadCharacter, ceiling(@nRightLen/@lengthPadCharacter) + 2), @nRightLen)
	   end

     return (@cSrting)
    end
GO

 -- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca   
 -- PADL(), PADR(), PADC() User-Defined Functions
 -- Returns a string from an expression, padded with spaces or characters to a specified length on the left or right sides, or both.
CREATE function PADL  (@cSrting nvarchar(4000), @nLen smallint, @cPadCharacter nvarchar(4000) = ' ' )
returns nvarchar(4000)
as
      begin
        declare @length smallint, @lengthPadCharacter smallint
        select  @length = datalength(@cSrting)/(case SQL_VARIANT_PROPERTY(@cSrting,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode
        select  @lengthPadCharacter = datalength(@cPadCharacter)/(case SQL_VARIANT_PROPERTY(@cPadCharacter,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode

        if @length >= @nLen
           set  @cSrting = left(@cSrting, @nLen)
        else
	   begin
              declare @nLeftLen smallint,  @nRightLen smallint
              set @nLeftLen = @nLen - @length  -- Quantity of characters, added at the left
              set @cSrting = left(replicate(@cPadCharacter, ceiling(@nLeftLen/@lengthPadCharacter) + 2), @nLeftLen)+ @cSrting
           end

    return (@cSrting)
   end
GO

 -- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca   
 -- PADL(), PADR(), PADC() User-Defined Functions
 -- Returns a string from an expression, padded with spaces or characters to a specified length on the left or right sides, or both.
CREATE function PADR  (@cSrting nvarchar(4000), @nLen smallint, @cPadCharacter nvarchar(4000) = ' ' )
returns nvarchar(4000)
as
     begin
       declare @length smallint, @lengthPadCharacter smallint
       select  @length  = datalength(@cSrting)/(case SQL_VARIANT_PROPERTY(@cSrting,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode
       select  @lengthPadCharacter  = datalength(@cPadCharacter)/(case SQL_VARIANT_PROPERTY(@cPadCharacter,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode

       if @length >= @nLen
          set  @cSrting = left(@cSrting, @nLen)
       else
          begin
             declare  @nRightLen smallint
             set @nRightLen  =  @nLen - @length -- Quantity of characters, added on the right
             set @cSrting =  @cSrting + left(replicate(@cPadCharacter, ceiling(@nRightLen/@lengthPadCharacter) + 2), @nRightLen)
	  end

     return (@cSrting)
    end
GO

 -- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca   
 -- OCCURS() User-Defined Function
 -- Returns the number of times a character expression occurs within another character expression.
 -- OCCURS(@cSearchExpression, @cExpressionSearched)
 -- Return Values smallint 
 -- Parameters
 -- @cSearchExpression nvarchar(4000) Specifies a character expression that OCCURS() searches for within @cExpressionSearched. 
 -- @cExpressionSearched nvarchar(4000) Specifies the character expression OCCURS() searches for @cSearchExpression. 
 -- Remarks
 -- OCCURS() returns 0 (zero) if @cSearchExpression isn't found within @cExpressionSearched.
 -- Example
 -- declare @gcString nvarchar(4000)
 -- select  @gcString = 'abracadabra'
 -- select dbo.OCCURS('a', @gcString )  -- Displays 5
 -- select dbo.OCCURS('b', @gcString )  -- Displays 2
 -- select dbo.OCCURS('c', @gcString )  -- Displays 1
 -- select dbo.OCCURS('e', @gcString )  -- Displays 0
 -- Attention !!!
 -- select dbo.OCCURS('ABCA', 'ABCABCABCA') -- display 3
 -- 1 occurrence of substring 'ABCA  .. BCABCA' 
 -- 2 occurrence of substring 'ABC...ABCA...BCA' 
 -- 3 occurrence of substring 'ABCABC...ABCA' 
 -- See Also AT(), RAT()  
 -- UDF the name and functionality of which correspond  to the same built-in functions of Visual FoxPro
CREATE function OCCURS  (@cSearchExpression nvarchar(4000), @cExpressionSearched nvarchar(4000))
returns smallint
as
    begin
      declare @start_location smallint,  @occurs  smallint
      select  @start_location = dbo.CHARINDEX_BIN(@cSearchExpression, @cExpressionSearched, 1),   @occurs = 0

     while @start_location > 0
          select  @occurs = @occurs + 1,  @start_location  = dbo.CHARINDEX_BIN(@cSearchExpression, @cExpressionSearched, @start_location+1)
    
     return  @occurs
    end
GO

 -- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca   
 -- PROPER( ) User-Defined Function
 -- Returns from a character expression a string capitalized as appropriate for proper names.
 -- PROPER(@cExpression)
 -- Return Values nvarchar(4000)
 -- Parameters
 -- @cExpression nvarchar(4000) Specifies the character expression from which PROPER( ) returns a capitalized character string. 
 -- Example
 -- declare @gcExpr1 nvarchar(4000), @gcExpr2 nvarchar(4000)
 -- select @gcExpr1 = 'Visual Basic.NET', @gcExpr2 = 'VISUAL BASIC.NET'
 -- select dbo.PROPER(@gcExpr1)  -- Displays 'Visual Basic.net'
 -- select dbo.PROPER(@gcExpr2)  -- Displays 'Visual Basic.net'
 -- UDF the name and functionality of which correspond  to the same built-in functions of Visual FoxPro
CREATE function PROPER  (@expression nvarchar(4000))
returns nvarchar(4000)
as
    begin
      declare @i  smallint, @j  smallint, @start_location smallint, @lenword smallint, @wordcount  smallint,  @word   nvarchar(4000),  @Delimiters  nvarchar(4000), @properexpression nvarchar(4000), @cDelimiters char(7)
      set @cDelimiters = char(9)+char(10)+char(11)+char(12)+char(13)+char(32)+char(160) -- Separators of words in a function FoxPro PROPER
      select  @wordcount = dbo.GETWORDCOUNT(@expression, @cDelimiters), @start_location = 1, @i = 1, @j = 1, @properexpression = ''
    
      while  @i <= @wordcount
          begin
             set @word = dbo.GETWORDNUM(@expression, @i, @cDelimiters)            -- Word
             set @start_location = dbo.CHARINDEX_BIN(@word, @expression, @start_location) -- The stand with which one starts a word
             set @Delimiters = substring(@expression, @j, @start_location - @j)   -- Interval between words
             set @lenword = datalength(@word)/(case SQL_VARIANT_PROPERTY(@word,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode
             set @properexpression = @properexpression + @Delimiters + upper(left(@word,1))+lower(substring(@word, 2, @lenword-1 )) 
             select @i = @i + 1, @start_location = @start_location + @lenword
             set @j = @start_location
          end

     return @properexpression + substring(@expression, @j,  1 - @j + datalength(@expression)/(case SQL_VARIANT_PROPERTY(@expression,'BaseType') when 'nvarchar' then 2  else 1 end) )
    end
GO

 -- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca 
 -- GETWORDCOUNT() User-Defined Function Counts the words in a string.
 -- GETWORDCOUNT(@cString[, @cDelimiters])
 -- Parameters
 -- @cString  nvarchar(4000) - Specifies the string whose words will be counted. 
 -- @cDelimiters nvarchar(256) - Optional. Specifies one or more optional characters used to separate words in @cString.
 -- The default delimiters are space, tab, carriage return, and line feed. Note that GETWORDCOUNT( ) uses each of the characters in @cDelimiters as individual delimiters, not the entire string as a single delimiter. 
 -- Return Value smallint 
 -- Remarks GETWORDCOUNT() by default assumes that words are delimited by spaces or tabs. If you specify another character as delimiter, this function ignores spaces and tabs and uses only the specified character.
 -- If you use 'AAA aaa, BBB bbb, CCC ccc.' as the target string for dbo.GETWORDCOUNT(), you can get all the following results.
 -- declare @cString nvarchar(4000)
 -- set @cString = 'AAA aaa, BBB bbb, CCC ccc.'
 -- select dbo.GETWORDCOUNT(@cString, default)           -- 6 - character groups, delimited by ' '
 -- select dbo.GETWORDCOUNT(@cString, ',')               -- 3 - character groups, delimited by ','
 -- select dbo.GETWORDCOUNT(@cString, '.')               -- 1 - character group, delimited by '.'
 -- See Also GETWORDNUM() User-Defined Function   
 -- UDF the name and functionality of which correspond  to the same built-in functions of Visual FoxPro
CREATE function GETWORDCOUNT  (@cSrting nvarchar(4000), @cDelimiters nvarchar(256) )
returns smallint 
as
    begin
      -- if no break string is specified, the function uses spaces, tabs and line feed to delimit words.
      set @cDelimiters = isnull(@cDelimiters, space(1)+char(9)+char(10))
      declare @p smallint, @end_of_string smallint, @wordcount smallint
      select  @p = 1, @wordcount = 0
      select  @end_of_string = 1 + datalength(@cSrting)/(case SQL_VARIANT_PROPERTY(@cSrting,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode

      while dbo.CHARINDEX_BIN(substring(@cSrting, @p, 1), @cDelimiters, 1) > 0  and  @end_of_string > @p  -- skip opening break characters, if any
          set @p = @p + 1

      if @p < @end_of_string
         begin
            set @wordcount = 1 -- count the one we are in now count transitions from 'not in word' to 'in word' 
                               -- if the current character is a break char, but the next one is not, we have entered a new word
            while @p < @end_of_string
               begin
                  if @p +1 < @end_of_string  and dbo.CHARINDEX_BIN(substring(@cSrting, @p, 1), @cDelimiters, 1) > 0 and dbo.CHARINDEX_BIN(substring(@cSrting, @p+1, 1), @cDelimiters, 1) = 0
                        select @wordcount = @wordcount + 1, @p = @p + 1 -- Skip over the first character in the word. We know it cannot be a break character.
                  set @p = @p + 1
               end
         end

     return @wordcount
    end
GO

 -- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca   
 -- GETWORDNUM() User-Defined Function 
 -- Returns a specified word from a string.
 -- GETWORDNUM(@cString, @nIndex[, @cDelimiters])
 -- Parameters @cString  nvarchar(4000) - Specifies the string to be evaluated 
 -- @nIndex smallint - Specifies the index position of the word to be returned. For example, if @nIndex is 3, GETWORDNUM( ) returns the third word (if @cString contains three or more words). 
 -- @cDelimiters nvarchar(256) - Optional. Specifies one or more optional characters used to separate words in @cString.
 -- The default delimiters are space, tab, carriage return, and line feed. Note that GetWordNum( ) uses each of the characters in @cDelimiters as individual delimiters, not the entire string as a single delimiter. 
 -- Return Value nvarchar(4000)
 -- Remarks Returns the word at the position specified by @nIndex in the target string, @cString. If @cString contains fewer than @nIndex words, GETWORDNUM( ) returns an empty string.
 -- See Also
 -- GETWORDCOUNT() User-Defined Function 
 -- UDF the name and functionality of which correspond  to the same built-in functions of Visual FoxPro
CREATE function GETWORDNUM  (@cSrting nvarchar(4000), @nIndex smallint, @cDelimiters nvarchar(256) )
returns nvarchar(4000)
as
    begin
      -- if no break string is specified, the function uses spaces, tabs and line feed to delimit words.
      set @cDelimiters = isnull(@cDelimiters,  space(1)+char(9)+char(10))
      declare @i smallint,  @j smallint, @p smallint, @q smallint, @qmin smallint, @end_of_string smallint, @LenDelimiters smallint, @outstr  nvarchar(4000)
      select  @i = 1, @p = 1, @q = 0, @outstr = ''
      select  @end_of_string = 1 + datalength(@cSrting)/(case SQL_VARIANT_PROPERTY(@cSrting,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode
      select  @LenDelimiters = datalength(@cDelimiters)/(case SQL_VARIANT_PROPERTY(@cDelimiters,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode

      while @i <= @nIndex
         begin
            while dbo.CHARINDEX_BIN(substring(@cSrting, @p, 1), @cDelimiters, 1) > 0 and  @end_of_string > @p   -- skip opening break characters, if any
               set @p = @p + 1

            if  @p >= @end_of_string
               break

            select @j = 1, @qmin = @end_of_string -- find next break character it marks the end of this word
            while @j <= @LenDelimiters
               begin
                  set @q = dbo.CHARINDEX_BIN(substring(@cDelimiters, @j, 1), @cSrting, @p)
                  set @j = @j + 1
                  if @q > 0 and @qmin > @q
                     set @qmin = @q
               end

            if @i = @nIndex -- this is the actual word we are looking for
               begin
                  set @outstr =  substring(@cSrting, @p, @qmin-@p)
                  break
               end
             set @p = @qmin + 1

             if (@p >= @end_of_string)
                 break
             set @i = @i + 1
         end

     return @outstr
    end
GO

-- Is similar to the built-in function Transact-SQL charindex but the search of which is on the right
-- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca   
CREATE function RCHARINDEX  (@expression1 nvarchar(4000), @expression2  nvarchar(4000), @start_location  smallint = 1 )
returns nvarchar(4000)
as
    begin
       declare @StartingPosition  smallint
       set  @StartingPosition = dbo.CHARINDEX_BIN( reverse(@expression1), reverse(@expression2), @start_location)

     return case 
               when  @StartingPosition > 0
               then  1 - @StartingPosition + datalength(@expression2)/(case SQL_VARIANT_PROPERTY(@expression2,'BaseType') when 'nvarchar' then 2  else 1 end) -- for unicode  
            else 0 
            end
    end
GO

-- Is similar to the built-in function Transact-SQL charindex, but regardless of collation settings,  
-- executes case-sensitive search  
-- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca   
CREATE function CHARINDEX_BIN(@expression1 nvarchar(4000), @expression2  nvarchar(4000), @start_location  smallint = 1)
returns nvarchar(4000)
as
    begin
       return charindex( cast(@expression1 as nvarchar(4000)) COLLATE Latin1_General_BIN, cast(@expression2  as nvarchar(4000)) COLLATE Latin1_General_BIN, @start_location )
    end
GO

-- ARABTOROMAN() Returns the character Roman number equivalent of a specified numeric expression 
-- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca ,  25 April 2005 or XXV April MMV :-)
-- ARABTOROMAN(@tNum) Return Values varchar(15) Parameters @tNum  number
-- select dbo.ARABTOROMAN(3888)   -- Displays MMMDCCCLXXXVIII
-- select dbo.ARABTOROMAN('1888') -- Displays MDCCCLXXXVIII
-- select dbo.ARABTOROMAN(1)      -- Displays I
-- select dbo.ARABTOROMAN(234)    -- Displays CCXXXIV
 -- See also ROMANTOARAB()  
CREATE function ARABTOROMAN(@tNum sql_variant)
returns varchar(75)
as
   begin
      declare @type char(1), @lResult varchar(75), @lnNum int

      select  @type =  case
         when charindex('char', cast(SQL_VARIANT_PROPERTY(@tNum,'BaseType') as varchar(20)) ) > 0  then 'C'
         when charindex('int', cast(SQL_VARIANT_PROPERTY(@tNum,'BaseType') as varchar(20)) ) > 0   then 'N'
         when cast(SQL_VARIANT_PROPERTY(@tNum,'BaseType') as varchar(20))  IN ('real', 'float', 'numeric', 'decimal')  then 'N'
         else 'W'
         end 
 
     if @type = 'W'
        set @lResult = 'Wrong type of parameter, must be Integer, Numeric or Character'
     else
       begin
         set @lnNum = cast(@tNum as int) 
         if @lnNum  between 1 and 3999
            begin    
               declare @ROMANNUMERALS char(7), @lnI tinyint, @tcNum  varchar(4)
               select @ROMANNUMERALS = 'IVXLCDM', @tcNum = ltrim(rtrim(cast(@lnNum as varchar(4)))), @lResult = ''
               set @lnI = datalength(@tcNum)
               while  @lnI >= 1  
                  begin   
                    set @lnNum = cast(substring(@tcNum, datalength(@tcNum)-@lnI+1, 1) as smallint)
                    select @lResult = @lResult + case 
                       when @lnNum < 4 then replicate(substring(@ROMANNUMERALS, @lnI*2 - 1, 1),@lnNum )
                       when @lnNum = 4 then substring(@ROMANNUMERALS, @lnI*2 - 1, 1)+substring(@ROMANNUMERALS, @lnI*2, 1)
                       when @lnNum < 9 then substring(@ROMANNUMERALS, @lnI*2, 1)+replicate(substring(@ROMANNUMERALS, @lnI*2 - 1, 1),@lnNum -5)
                       else substring(@ROMANNUMERALS, @lnI*2 - 1, 1)+substring(@ROMANNUMERALS, (@lnI+1)*2 - 1, 1) 
                   end
                   set @lnI = @lnI - 1
               end
            end
         else
           set @lResult = 'Out of range, must be between 1 and 3999'
        end
     return  @lResult
   end

GO

-- ROMANTOARAB() Returns the number equivalent of a specified character Roman number expression  
-- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca ,  25 April 2005 or XXV April MMV :-)
-- ROMANTOARAB(@tcRomanNumber) Return Values smallint
-- Parameters @tcRomanNumber  varchar(15) Roman number  
-- select dbo.ROMANTOARAB('MMMDCCCLXXXVIII') -- Displays 3888
-- select dbo.ROMANTOARAB('MDCCCLXXXVIII')   -- Displays 1888
-- select dbo.ROMANTOARAB('I')               -- Displays 1
-- select dbo.ROMANTOARAB('CCXXXIV')         -- Displays 234
-- See also ARABTOROMAN()  
CREATE function ROMANTOARAB(@tcRomanNumber varchar(15))
returns smallint
as
   begin
      declare @lnResult smallint, @lcRomanNumber varchar(15), @lnI tinyint, @ROMANNUMERALS char(7)
      select @tcRomanNumber = ltrim(rtrim(upper(@tcRomanNumber))), @ROMANNUMERALS = 'IVXLCDM', @lcRomanNumber = '', @lnI = 1, @lnResult = 0
   
     while  @lnI <= datalength(@tcRomanNumber)
       begin 
         if charindex(substring(@tcRomanNumber, @lnI, 1), @ROMANNUMERALS) > 0
           set @lcRomanNumber = @lcRomanNumber + substring(@tcRomanNumber, @lnI, 1)
         else
           begin
             set @lnResult = -1
             break
            end
         set @lnI =  @lnI + 1
       end
    
     if @lnResult >  -1
       begin
         declare @lnJ tinyint, @lnDelim smallint, @lnK tinyint
         select  @lnK = datalength(@lcRomanNumber), @lnI = 1
   
         while  @lnI <= 4
            begin
              if @lnK = 0
                  break
              set @lnDelim = power(10, @lnI-1)
              if @lnK >= 2 and substring(@lcRomanNumber, @lnK - 1, 2) = (substring(@ROMANNUMERALS, @lnI*2 - 1, 1)+substring(@ROMANNUMERALS, @lnI*2, 1)) -- CD or XL or IV
                select @lnResult = @lnResult + 4*@lnDelim, @lnK = @lnK - 2
              else  
              if @lnK >= 2 and  substring(@lcRomanNumber, @lnK - 1, 2) = (substring(@ROMANNUMERALS, @lnI*2 - 1, 1)+substring(@ROMANNUMERALS, (@lnI+1)*2 - 1, 1)) -- CM or XC or IX
                select @lnResult = @lnResult + 9*@lnDelim, @lnK = @lnK - 2
              else
                begin 
                  set @lnJ = 1
                  while  @lnJ <= 3  -- MMM or CCC or XXX or III
                    begin
                      if  @lnK >=1 and substring(@lcRomanNumber, @lnK, 1) = substring(@ROMANNUMERALS, @lnI*2 - 1, 1)
                        select @lnResult = @lnResult + @lnDelim, @lnK = @lnK - 1
                      set @lnJ =  @lnJ + 1
                    end 
                  if @lnK = 0
                    break
                  if substring(@lcRomanNumber, @lnK, 1) = substring(@ROMANNUMERALS, @lnI*2, 1) -- D or L or V
                    select @lnResult = @lnResult + 5*@lnDelim, @lnK = @lnK - 1
                end 
             set @lnI =  @lnI + 1
            end
         end      
        
        if @lnK > 0
          set @lnResult = -1
     
     return  @lnResult
   end

GO

-- ADDROMANNUMBERS() User-Defined Function is written just FYA
-- Returns the result of addition, subtraction, multiplication or division of two Roman numbers  
-- Author:  Igor Nikiforov,  Montreal,  EMail: udfs@sympatico.ca ,  25 April 2005 or XXV April MMV :-)
-- ADDROMANNUMBERS(@tcRomanNumber1, @tcRomanNumber2, @tcOperator) Return Values varchar(75)
-- Parameters @tcRomanNumber1 varchar(15) Roman number
-- @tcRomanNumber2 varchar(15) Roman number, @tcOperator char(1) operator
-- select dbo.ADDROMANNUMBERS('I','I',default)                       -- Displays II
-- select dbo.ADDROMANNUMBERS('MMMDCCCLXXXVIII','MDCCCLXXXVIII','-') -- Displays MM
-- select dbo.ADDROMANNUMBERS('DCCCLXXXVIII','VIII',default)         -- Displays DCCCXCVI
-- select dbo.ADDROMANNUMBERS('DCCCLXXXVIII','VIII','*')             -- Displays Out of range, must be between 1 and 3999
-- select dbo.ADDROMANNUMBERS('MMMDCCCLXXXVIII','II','/')            -- Displays MCMXLIV
-- See also ROMANTOARAB(), ARABTOROMAN()  
CREATE function ADDROMANNUMBERS(@tcRomanNumber1 varchar(15), @tcRomanNumber2 varchar(15), @tcOperator char(1)='+' )
returns varchar(75)
   begin
      declare @lcResult varchar(75)
      if @tcOperator in ('+','-','*','/')
        begin
          declare @lnN1 int, @lnN2 int
          select @lnN1 = dbo.ROMANTOARAB(@tcRomanNumber1),  @lnN2 = dbo.ROMANTOARAB(@tcRomanNumber2)
          if @lnN1 < 0
            set @lcResult = 'Wrong first roman number'
          else 
            if @lnN2 < 0
              set @lcResult = 'Wrong second roman number'
            else   
              begin
                select @lcResult = 
                case @tcOperator 
                  when '+' then dbo.ARABTOROMAN(@lnN1 + @lnN2)
                  when '-' then dbo.ARABTOROMAN(@lnN1 - @lnN2)
                  when '*' then dbo.ARABTOROMAN(@lnN1 * @lnN2)
                  when '/' then dbo.ARABTOROMAN(@lnN1 / @lnN2)
                end                
              end
        end
      else 
        set @lcResult = 'Wrong third parameter, must be +,-,*,/'
         
    return @lcResult
  end

GO
