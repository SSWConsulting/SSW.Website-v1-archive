drop function AT 
drop function RAT
drop function PADC
drop function PADL
drop function PADR
drop function OCCURS
drop function PROPER
drop function GETWORDCOUNT
drop function GETWORDNUM
drop function RCHARINDEX  
drop function CHARINDEX_BIN
drop function ARABTOROMAN
drop function ROMANTOARAB
drop function ADDROMANNUMBERS

GO
