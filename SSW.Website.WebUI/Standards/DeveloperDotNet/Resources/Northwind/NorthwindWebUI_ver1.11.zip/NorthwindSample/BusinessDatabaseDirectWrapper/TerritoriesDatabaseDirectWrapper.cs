using System;
using System.Data;
using System.Xml;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DatabaseDirectWrapper.Base;

namespace NorthwindSample.DatabaseDirectWrapper
{
	public class TerritoriesDatabaseDirectWrapper : TerritoriesDatabaseDirectWrapperBase, ITerritoriesService 
	{
		#region Fields

		

		#endregion


		#region Constructors

		public TerritoriesDatabaseDirectWrapper() : base() 
		{
		}
		

		#endregion


		#region  Public Properties



		#endregion


		#region Private Methods



		#endregion


		#region Public Methods



		#endregion

	
	}
}
