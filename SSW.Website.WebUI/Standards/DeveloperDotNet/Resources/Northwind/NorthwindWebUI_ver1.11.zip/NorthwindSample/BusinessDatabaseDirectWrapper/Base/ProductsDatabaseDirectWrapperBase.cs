using System;
using System.Data;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces.Base;
using NorthwindSample.Data;

namespace NorthwindSample.DatabaseDirectWrapper.Base
{
	public class ProductsDatabaseDirectWrapperBase : IProductsServiceBase
	{
		#region Fields

		ProductsService m_ServiceInstance;
		
		#endregion


		#region Constructors

		public ProductsDatabaseDirectWrapperBase() 
		{
			m_ServiceInstance = new ProductsService(); 
		}

		#endregion
		
		
		#region Protected Properties

		protected ProductsService ServiceInstance
		{
			get { return m_ServiceInstance; }
		}


		#endregion
		

		#region Public Methods

		public int GetAll(ProductsDataSet dataSetFill) 
		{
			DataTable resultsTable = ServiceInstance.GetAll().Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int GetByQuery(DataSet dataSetFill, Query queryDefinition) 
		{
			DataTable resultsTable = ServiceInstance.GetByQuery(queryDefinition).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int UpdateDataSet(ProductsDataSet dataSetUpdate)
		{
			DataSet returnedDataSet = ServiceInstance.UpdateDataSet(dataSetUpdate);
			return returnedDataSet.Tables[0].Rows.Count;
		}
		
			
		public int GetByProductID(ProductsDataSet dataSetFill, Int32 ProductID)
		{
			DataTable resultsTable = ServiceInstance.GetByProductID(ProductID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	
		
		public int GetByCategoryID(ProductsDataSet dataSetFill, Int32 CategoryID)
		{
			DataTable resultsTable = ServiceInstance.GetByCategoryID(CategoryID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	
		
		public int GetBySupplierID(ProductsDataSet dataSetFill, Int32 SupplierID)
		{
			DataTable resultsTable = ServiceInstance.GetBySupplierID(SupplierID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	

		
		#endregion
	}
}
