using System;
using System.Data;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces.Base;
using NorthwindSample.Data;

namespace NorthwindSample.DatabaseDirectWrapper.Base
{
	public class CategoriesDatabaseDirectWrapperBase : ICategoriesServiceBase
	{
		#region Fields

		CategoriesService m_ServiceInstance;
		
		#endregion


		#region Constructors

		public CategoriesDatabaseDirectWrapperBase() 
		{
			m_ServiceInstance = new CategoriesService(); 
		}

		#endregion
		
		
		#region Protected Properties

		protected CategoriesService ServiceInstance
		{
			get { return m_ServiceInstance; }
		}


		#endregion
		

		#region Public Methods

		public int GetAll(CategoriesDataSet dataSetFill) 
		{
			DataTable resultsTable = ServiceInstance.GetAll().Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int GetByQuery(DataSet dataSetFill, Query queryDefinition) 
		{
			DataTable resultsTable = ServiceInstance.GetByQuery(queryDefinition).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int UpdateDataSet(CategoriesDataSet dataSetUpdate)
		{
			DataSet returnedDataSet = ServiceInstance.UpdateDataSet(dataSetUpdate);
			return returnedDataSet.Tables[0].Rows.Count;
		}
		
			
		public int GetByCategoryID(CategoriesDataSet dataSetFill, Int32 CategoryID)
		{
			DataTable resultsTable = ServiceInstance.GetByCategoryID(CategoryID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	

		
		#endregion
	}
}
