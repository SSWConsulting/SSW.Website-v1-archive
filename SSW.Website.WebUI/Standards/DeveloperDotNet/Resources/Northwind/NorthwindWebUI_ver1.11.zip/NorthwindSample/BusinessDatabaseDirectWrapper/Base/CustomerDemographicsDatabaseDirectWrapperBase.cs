using System;
using System.Data;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces.Base;
using NorthwindSample.Data;

namespace NorthwindSample.DatabaseDirectWrapper.Base
{
	public class CustomerDemographicsDatabaseDirectWrapperBase : ICustomerDemographicsServiceBase
	{
		#region Fields

		CustomerDemographicsService m_ServiceInstance;
		
		#endregion


		#region Constructors

		public CustomerDemographicsDatabaseDirectWrapperBase() 
		{
			m_ServiceInstance = new CustomerDemographicsService(); 
		}

		#endregion
		
		
		#region Protected Properties

		protected CustomerDemographicsService ServiceInstance
		{
			get { return m_ServiceInstance; }
		}


		#endregion
		

		#region Public Methods

		public int GetAll(CustomerDemographicsDataSet dataSetFill) 
		{
			DataTable resultsTable = ServiceInstance.GetAll().Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int GetByQuery(DataSet dataSetFill, Query queryDefinition) 
		{
			DataTable resultsTable = ServiceInstance.GetByQuery(queryDefinition).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int UpdateDataSet(CustomerDemographicsDataSet dataSetUpdate)
		{
			DataSet returnedDataSet = ServiceInstance.UpdateDataSet(dataSetUpdate);
			return returnedDataSet.Tables[0].Rows.Count;
		}
		
			
		public int GetByCustomerTypeID(CustomerDemographicsDataSet dataSetFill, String CustomerTypeID)
		{
			DataTable resultsTable = ServiceInstance.GetByCustomerTypeID(CustomerTypeID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	

		
		#endregion
	}
}
