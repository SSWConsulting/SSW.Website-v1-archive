using System;
using System.Data;
using System.Xml;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DatabaseDirectWrapper.Base;

namespace NorthwindSample.DatabaseDirectWrapper
{
	public class ViewOrderDetailsDatabaseDirectWrapper : ViewOrderDetailsDatabaseDirectWrapperBase, IViewOrderDetailsService 
	{
		#region Fields

		

		#endregion


		#region Constructors

		public ViewOrderDetailsDatabaseDirectWrapper() : base() 
		{
		}
		

		#endregion


		#region  Public Properties



		#endregion


		#region Private Methods



		#endregion


		#region Public Methods



		#endregion

	
	}
}
