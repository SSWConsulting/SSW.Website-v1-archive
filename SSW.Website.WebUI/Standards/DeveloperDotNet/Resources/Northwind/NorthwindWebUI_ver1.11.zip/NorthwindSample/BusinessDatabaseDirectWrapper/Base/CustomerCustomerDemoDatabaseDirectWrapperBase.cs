using System;
using System.Data;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces.Base;
using NorthwindSample.Data;

namespace NorthwindSample.DatabaseDirectWrapper.Base
{
	public class CustomerCustomerDemoDatabaseDirectWrapperBase : ICustomerCustomerDemoServiceBase
	{
		#region Fields

		CustomerCustomerDemoService m_ServiceInstance;
		
		#endregion


		#region Constructors

		public CustomerCustomerDemoDatabaseDirectWrapperBase() 
		{
			m_ServiceInstance = new CustomerCustomerDemoService(); 
		}

		#endregion
		
		
		#region Protected Properties

		protected CustomerCustomerDemoService ServiceInstance
		{
			get { return m_ServiceInstance; }
		}


		#endregion
		

		#region Public Methods

		public int GetAll(CustomerCustomerDemoDataSet dataSetFill) 
		{
			DataTable resultsTable = ServiceInstance.GetAll().Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int GetByQuery(DataSet dataSetFill, Query queryDefinition) 
		{
			DataTable resultsTable = ServiceInstance.GetByQuery(queryDefinition).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int UpdateDataSet(CustomerCustomerDemoDataSet dataSetUpdate)
		{
			DataSet returnedDataSet = ServiceInstance.UpdateDataSet(dataSetUpdate);
			return returnedDataSet.Tables[0].Rows.Count;
		}
		
			
		public int GetByCustomerIDAndCustomerTypeID(CustomerCustomerDemoDataSet dataSetFill, String CustomerID, String CustomerTypeID)
		{
			DataTable resultsTable = ServiceInstance.GetByCustomerIDAndCustomerTypeID(CustomerID, CustomerTypeID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	
		
		public int GetByCustomerTypeID(CustomerCustomerDemoDataSet dataSetFill, String CustomerTypeID)
		{
			DataTable resultsTable = ServiceInstance.GetByCustomerTypeID(CustomerTypeID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	
		
		public int GetByCustomerID(CustomerCustomerDemoDataSet dataSetFill, String CustomerID)
		{
			DataTable resultsTable = ServiceInstance.GetByCustomerID(CustomerID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	

		
		#endregion
	}
}
