using System;
using System.Data;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces.Base;
using NorthwindSample.Data;

namespace NorthwindSample.DatabaseDirectWrapper.Base
{
	public class TerritoriesDatabaseDirectWrapperBase : ITerritoriesServiceBase
	{
		#region Fields

		TerritoriesService m_ServiceInstance;
		
		#endregion


		#region Constructors

		public TerritoriesDatabaseDirectWrapperBase() 
		{
			m_ServiceInstance = new TerritoriesService(); 
		}

		#endregion
		
		
		#region Protected Properties

		protected TerritoriesService ServiceInstance
		{
			get { return m_ServiceInstance; }
		}


		#endregion
		

		#region Public Methods

		public int GetAll(TerritoriesDataSet dataSetFill) 
		{
			DataTable resultsTable = ServiceInstance.GetAll().Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int GetByQuery(DataSet dataSetFill, Query queryDefinition) 
		{
			DataTable resultsTable = ServiceInstance.GetByQuery(queryDefinition).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int UpdateDataSet(TerritoriesDataSet dataSetUpdate)
		{
			DataSet returnedDataSet = ServiceInstance.UpdateDataSet(dataSetUpdate);
			return returnedDataSet.Tables[0].Rows.Count;
		}
		
			
		public int GetByTerritoryID(TerritoriesDataSet dataSetFill, String TerritoryID)
		{
			DataTable resultsTable = ServiceInstance.GetByTerritoryID(TerritoryID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	
		
		public int GetByRegionID(TerritoriesDataSet dataSetFill, Int32 RegionID)
		{
			DataTable resultsTable = ServiceInstance.GetByRegionID(RegionID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	

		
		#endregion
	}
}
