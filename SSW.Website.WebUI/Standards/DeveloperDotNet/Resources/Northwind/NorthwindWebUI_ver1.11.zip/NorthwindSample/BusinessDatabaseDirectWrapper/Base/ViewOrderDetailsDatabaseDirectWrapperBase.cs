using System;
using System.Data;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces.Base;
using NorthwindSample.Data;

namespace NorthwindSample.DatabaseDirectWrapper.Base
{
	public class ViewOrderDetailsDatabaseDirectWrapperBase : IViewOrderDetailsServiceBase
	{
		#region Fields

		ViewOrderDetailsService m_ServiceInstance;
		
		#endregion


		#region Constructors

		public ViewOrderDetailsDatabaseDirectWrapperBase() 
		{
			m_ServiceInstance = new ViewOrderDetailsService(); 
		}

		#endregion
		
		
		#region Protected Properties

		protected ViewOrderDetailsService ServiceInstance
		{
			get { return m_ServiceInstance; }
		}


		#endregion
		

		#region Public Methods

		public int GetAll(ViewOrderDetailsDataSet dataSetFill) 
		{
			DataTable resultsTable = ServiceInstance.GetAll().Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int GetByQuery(DataSet dataSetFill, Query queryDefinition) 
		{
			DataTable resultsTable = ServiceInstance.GetByQuery(queryDefinition).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int UpdateDataSet(ViewOrderDetailsDataSet dataSetUpdate)
		{
			DataSet returnedDataSet = ServiceInstance.UpdateDataSet(dataSetUpdate);
			return returnedDataSet.Tables[0].Rows.Count;
		}
		
		

		
		#endregion
	}
}
