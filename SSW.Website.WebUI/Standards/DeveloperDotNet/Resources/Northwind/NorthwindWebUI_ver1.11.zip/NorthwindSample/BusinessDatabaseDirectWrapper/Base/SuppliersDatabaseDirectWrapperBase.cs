using System;
using System.Data;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces.Base;
using NorthwindSample.Data;

namespace NorthwindSample.DatabaseDirectWrapper.Base
{
	public class SuppliersDatabaseDirectWrapperBase : ISuppliersServiceBase
	{
		#region Fields

		SuppliersService m_ServiceInstance;
		
		#endregion


		#region Constructors

		public SuppliersDatabaseDirectWrapperBase() 
		{
			m_ServiceInstance = new SuppliersService(); 
		}

		#endregion
		
		
		#region Protected Properties

		protected SuppliersService ServiceInstance
		{
			get { return m_ServiceInstance; }
		}


		#endregion
		

		#region Public Methods

		public int GetAll(SuppliersDataSet dataSetFill) 
		{
			DataTable resultsTable = ServiceInstance.GetAll().Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int GetByQuery(DataSet dataSetFill, Query queryDefinition) 
		{
			DataTable resultsTable = ServiceInstance.GetByQuery(queryDefinition).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int UpdateDataSet(SuppliersDataSet dataSetUpdate)
		{
			DataSet returnedDataSet = ServiceInstance.UpdateDataSet(dataSetUpdate);
			return returnedDataSet.Tables[0].Rows.Count;
		}
		
			
		public int GetBySupplierID(SuppliersDataSet dataSetFill, Int32 SupplierID)
		{
			DataTable resultsTable = ServiceInstance.GetBySupplierID(SupplierID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	

		
		#endregion
	}
}
