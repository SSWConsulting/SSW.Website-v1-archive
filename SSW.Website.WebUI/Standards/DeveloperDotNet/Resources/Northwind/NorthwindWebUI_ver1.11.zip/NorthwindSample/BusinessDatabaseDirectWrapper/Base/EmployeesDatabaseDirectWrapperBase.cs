using System;
using System.Data;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces.Base;
using NorthwindSample.Data;

namespace NorthwindSample.DatabaseDirectWrapper.Base
{
	public class EmployeesDatabaseDirectWrapperBase : IEmployeesServiceBase
	{
		#region Fields

		EmployeesService m_ServiceInstance;
		
		#endregion


		#region Constructors

		public EmployeesDatabaseDirectWrapperBase() 
		{
			m_ServiceInstance = new EmployeesService(); 
		}

		#endregion
		
		
		#region Protected Properties

		protected EmployeesService ServiceInstance
		{
			get { return m_ServiceInstance; }
		}


		#endregion
		

		#region Public Methods

		public int GetAll(EmployeesDataSet dataSetFill) 
		{
			DataTable resultsTable = ServiceInstance.GetAll().Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int GetByQuery(DataSet dataSetFill, Query queryDefinition) 
		{
			DataTable resultsTable = ServiceInstance.GetByQuery(queryDefinition).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int UpdateDataSet(EmployeesDataSet dataSetUpdate)
		{
			DataSet returnedDataSet = ServiceInstance.UpdateDataSet(dataSetUpdate);
			return returnedDataSet.Tables[0].Rows.Count;
		}
		
			
		public int GetByEmployeeID(EmployeesDataSet dataSetFill, Int32 EmployeeID)
		{
			DataTable resultsTable = ServiceInstance.GetByEmployeeID(EmployeeID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	
		
		public int GetByReportsTo(EmployeesDataSet dataSetFill, Int32 ReportsTo)
		{
			DataTable resultsTable = ServiceInstance.GetByReportsTo(ReportsTo).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	

		
		#endregion
	}
}
