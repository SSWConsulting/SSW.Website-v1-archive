using System;
using System.Data;
using System.Xml;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DatabaseDirectWrapper.Base;

namespace NorthwindSample.DatabaseDirectWrapper
{
	public class CustomersDatabaseDirectWrapper : CustomersDatabaseDirectWrapperBase, ICustomersService 
	{
		#region Fields

		

		#endregion


		#region Constructors

		public CustomersDatabaseDirectWrapper() : base() 
		{
		}
		

		#endregion


		#region  Public Properties



		#endregion


		#region Private Methods



		#endregion


		#region Public Methods



		#endregion

	
	}
}
