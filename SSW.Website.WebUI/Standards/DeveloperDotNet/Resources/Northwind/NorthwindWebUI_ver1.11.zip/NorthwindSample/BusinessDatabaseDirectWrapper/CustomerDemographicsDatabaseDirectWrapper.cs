using System;
using System.Data;
using System.Xml;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DatabaseDirectWrapper.Base;

namespace NorthwindSample.DatabaseDirectWrapper
{
	public class CustomerDemographicsDatabaseDirectWrapper : CustomerDemographicsDatabaseDirectWrapperBase, ICustomerDemographicsService 
	{
		#region Fields

		

		#endregion


		#region Constructors

		public CustomerDemographicsDatabaseDirectWrapper() : base() 
		{
		}
		

		#endregion


		#region  Public Properties



		#endregion


		#region Private Methods



		#endregion


		#region Public Methods



		#endregion

	
	}
}
