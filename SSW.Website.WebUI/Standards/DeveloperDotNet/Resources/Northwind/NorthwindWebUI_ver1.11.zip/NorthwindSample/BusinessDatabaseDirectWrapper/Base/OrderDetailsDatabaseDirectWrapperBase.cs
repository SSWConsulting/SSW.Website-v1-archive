using System;
using System.Data;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessWebService;
using NorthwindSample.BusinessServiceInterfaces.Base;
using NorthwindSample.Data;

namespace NorthwindSample.DatabaseDirectWrapper.Base
{
	public class OrderDetailsDatabaseDirectWrapperBase : IOrderDetailsServiceBase
	{
		#region Fields

		OrderDetailsService m_ServiceInstance;
		
		#endregion


		#region Constructors

		public OrderDetailsDatabaseDirectWrapperBase() 
		{
			m_ServiceInstance = new OrderDetailsService(); 
		}

		#endregion
		
		
		#region Protected Properties

		protected OrderDetailsService ServiceInstance
		{
			get { return m_ServiceInstance; }
		}


		#endregion
		

		#region Public Methods

		public int GetAll(OrderDetailsDataSet dataSetFill) 
		{
			DataTable resultsTable = ServiceInstance.GetAll().Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int GetByQuery(DataSet dataSetFill, Query queryDefinition) 
		{
			DataTable resultsTable = ServiceInstance.GetByQuery(queryDefinition).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}


		public int UpdateDataSet(OrderDetailsDataSet dataSetUpdate)
		{
			DataSet returnedDataSet = ServiceInstance.UpdateDataSet(dataSetUpdate);
			return returnedDataSet.Tables[0].Rows.Count;
		}
		
			
		public int GetByOrderIDAndProductID(OrderDetailsDataSet dataSetFill, Int32 OrderID, Int32 ProductID)
		{
			DataTable resultsTable = ServiceInstance.GetByOrderIDAndProductID(OrderID, ProductID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	
		
		public int GetByOrderID(OrderDetailsDataSet dataSetFill, Int32 OrderID)
		{
			DataTable resultsTable = ServiceInstance.GetByOrderID(OrderID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	
		
		public int GetByProductID(OrderDetailsDataSet dataSetFill, Int32 ProductID)
		{
			DataTable resultsTable = ServiceInstance.GetByProductID(ProductID).Tables[0];
			dataSetFill.Merge(resultsTable);
			return resultsTable.Rows.Count;
		}
	

		
		#endregion
	}
}
