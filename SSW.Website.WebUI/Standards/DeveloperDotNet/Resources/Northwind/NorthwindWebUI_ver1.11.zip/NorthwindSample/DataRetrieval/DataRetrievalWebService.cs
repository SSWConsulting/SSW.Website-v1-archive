using System;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.WebServiceWrapper;

namespace NorthwindSample.DataRetrieval
{
	public class DataRetrievalWebService : DataRetrievalFactory
	{
		protected string m_sRootUrl;

		public DataRetrievalWebService(string sBaseUrl)
		{
			m_sRootUrl = sBaseUrl;
		}

		
		public override ICategoriesService CreateCategoriesService() 
		{
			return new CategoriesWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override ICustomerCustomerDemoService CreateCustomerCustomerDemoService() 
		{
			return new CustomerCustomerDemoWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override ICustomerDemographicsService CreateCustomerDemographicsService() 
		{
			return new CustomerDemographicsWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override ICustomersService CreateCustomersService() 
		{
			return new CustomersWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override IEmployeesService CreateEmployeesService() 
		{
			return new EmployeesWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override IEmployeeTerritoriesService CreateEmployeeTerritoriesService() 
		{
			return new EmployeeTerritoriesWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override IOrderDetailsService CreateOrderDetailsService() 
		{
			return new OrderDetailsWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override IOrdersService CreateOrdersService() 
		{
			return new OrdersWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override IProductsService CreateProductsService() 
		{
			return new ProductsWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override IRegionService CreateRegionService() 
		{
			return new RegionWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override IShippersService CreateShippersService() 
		{
			return new ShippersWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override ISuppliersService CreateSuppliersService() 
		{
			return new SuppliersWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override ITerritoriesService CreateTerritoriesService() 
		{
			return new TerritoriesWebServiceWrapper(m_sRootUrl);
		}
		
		
		public override IViewOrderDetailsService CreateViewOrderDetailsService() 
		{
			return new ViewOrderDetailsWebServiceWrapper(m_sRootUrl);
		}
		
		
	}
}
