using System;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.DatabaseDirectWrapper;

namespace NorthwindSample.DataRetrieval
{
	public class DataRetrievalSqlConnection : DataRetrievalFactory
	{
		
		public override ICategoriesService CreateCategoriesService() 
		{ 
			return new CategoriesDatabaseDirectWrapper(); 
		}
		
		
		public override ICustomerCustomerDemoService CreateCustomerCustomerDemoService() 
		{ 
			return new CustomerCustomerDemoDatabaseDirectWrapper(); 
		}
		
		
		public override ICustomerDemographicsService CreateCustomerDemographicsService() 
		{ 
			return new CustomerDemographicsDatabaseDirectWrapper(); 
		}
		
		
		public override ICustomersService CreateCustomersService() 
		{ 
			return new CustomersDatabaseDirectWrapper(); 
		}
		
		
		public override IEmployeesService CreateEmployeesService() 
		{ 
			return new EmployeesDatabaseDirectWrapper(); 
		}
		
		
		public override IEmployeeTerritoriesService CreateEmployeeTerritoriesService() 
		{ 
			return new EmployeeTerritoriesDatabaseDirectWrapper(); 
		}
		
		
		public override IOrderDetailsService CreateOrderDetailsService() 
		{ 
			return new OrderDetailsDatabaseDirectWrapper(); 
		}
		
		
		public override IOrdersService CreateOrdersService() 
		{ 
			return new OrdersDatabaseDirectWrapper(); 
		}
		
		
		public override IProductsService CreateProductsService() 
		{ 
			return new ProductsDatabaseDirectWrapper(); 
		}
		
		
		public override IRegionService CreateRegionService() 
		{ 
			return new RegionDatabaseDirectWrapper(); 
		}
		
		
		public override IShippersService CreateShippersService() 
		{ 
			return new ShippersDatabaseDirectWrapper(); 
		}
		
		
		public override ISuppliersService CreateSuppliersService() 
		{ 
			return new SuppliersDatabaseDirectWrapper(); 
		}
		
		
		public override ITerritoriesService CreateTerritoriesService() 
		{ 
			return new TerritoriesDatabaseDirectWrapper(); 
		}
		
		
		public override IViewOrderDetailsService CreateViewOrderDetailsService() 
		{ 
			return new ViewOrderDetailsDatabaseDirectWrapper(); 
		}
		
		
	}
}
