using System;
using System.Configuration;

using NorthwindSample.BusinessServiceInterfaces;

namespace NorthwindSample.DataRetrieval
{
	public abstract class DataRetrievalFactory
	{
		public static DataRetrievalFactory GetDataRetrievalFactory() 
		{
			string sType = ConfigurationSettings.AppSettings["ConnectionType"];
			
			if (sType == "SqlConn")
			{
				return new DataRetrievalSqlConnection();
			}
			else
			{
				return new DataRetrievalWebService(ConfigurationSettings.AppSettings["WebServiceRootUrl"]);
			}
		}

	
		public abstract ICategoriesService CreateCategoriesService();
	
		public abstract ICustomerCustomerDemoService CreateCustomerCustomerDemoService();
	
		public abstract ICustomerDemographicsService CreateCustomerDemographicsService();
	
		public abstract ICustomersService CreateCustomersService();
	
		public abstract IEmployeesService CreateEmployeesService();
	
		public abstract IEmployeeTerritoriesService CreateEmployeeTerritoriesService();
	
		public abstract IOrderDetailsService CreateOrderDetailsService();
	
		public abstract IOrdersService CreateOrdersService();
	
		public abstract IProductsService CreateProductsService();
	
		public abstract IRegionService CreateRegionService();
	
		public abstract IShippersService CreateShippersService();
	
		public abstract ISuppliersService CreateSuppliersService();
	
		public abstract ITerritoriesService CreateTerritoriesService();
	
		public abstract IViewOrderDetailsService CreateViewOrderDetailsService();
	
	}
}
