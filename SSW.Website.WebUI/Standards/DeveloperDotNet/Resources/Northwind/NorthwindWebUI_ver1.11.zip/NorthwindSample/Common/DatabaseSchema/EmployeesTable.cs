using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Employees table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwEmployees")]
	public enum EmployeesTable
	{
		/// <summary>
		/// EmployeeID Column 
		/// </summary>
		[DatabaseColumn("EmployeeID", DbType.Int32, AllowDBNull=false)]
		EmployeeID,
		
		/// <summary>
		/// LastName Column 
		/// </summary>
		[DatabaseColumn("LastName", DbType.String, Length=20, AllowDBNull=false)]
		LastName,
		
		/// <summary>
		/// FirstName Column 
		/// </summary>
		[DatabaseColumn("FirstName", DbType.String, Length=10, AllowDBNull=false)]
		FirstName,
		
		/// <summary>
		/// Title Column 
		/// </summary>
		[DatabaseColumn("Title", DbType.String, Length=30)]
		Title,
		
		/// <summary>
		/// TitleOfCourtesy Column 
		/// </summary>
		[DatabaseColumn("TitleOfCourtesy", DbType.String, Length=25)]
		TitleOfCourtesy,
		
		/// <summary>
		/// BirthDate Column 
		/// </summary>
		[DatabaseColumn("BirthDate", DbType.DateTime)]
		BirthDate,
		
		/// <summary>
		/// HireDate Column 
		/// </summary>
		[DatabaseColumn("HireDate", DbType.DateTime)]
		HireDate,
		
		/// <summary>
		/// Address Column 
		/// </summary>
		[DatabaseColumn("Address", DbType.String, Length=60)]
		Address,
		
		/// <summary>
		/// City Column 
		/// </summary>
		[DatabaseColumn("City", DbType.String, Length=15)]
		City,
		
		/// <summary>
		/// Region Column 
		/// </summary>
		[DatabaseColumn("Region", DbType.String, Length=15)]
		Region,
		
		/// <summary>
		/// PostalCode Column 
		/// </summary>
		[DatabaseColumn("PostalCode", DbType.String, Length=10)]
		PostalCode,
		
		/// <summary>
		/// Country Column 
		/// </summary>
		[DatabaseColumn("Country", DbType.String, Length=15)]
		Country,
		
		/// <summary>
		/// HomePhone Column 
		/// </summary>
		[DatabaseColumn("HomePhone", DbType.String, Length=24)]
		HomePhone,
		
		/// <summary>
		/// Extension Column 
		/// </summary>
		[DatabaseColumn("Extension", DbType.String, Length=4)]
		Extension,
		
		/// <summary>
		/// Photo Column 
		/// </summary>
		[DatabaseColumn("Photo", DbType.Binary)]
		Photo,
		
		/// <summary>
		/// Notes Column 
		/// </summary>
		[DatabaseColumn("Notes", DbType.String)]
		Notes,
		
		/// <summary>
		/// ReportsTo Column 
		/// </summary>
		[DatabaseColumn("ReportsTo", DbType.Int32)]
		ReportsTo,
		
		/// <summary>
		/// PhotoPath Column 
		/// </summary>
		[DatabaseColumn("PhotoPath", DbType.String, Length=255)]
		PhotoPath

	}
}
