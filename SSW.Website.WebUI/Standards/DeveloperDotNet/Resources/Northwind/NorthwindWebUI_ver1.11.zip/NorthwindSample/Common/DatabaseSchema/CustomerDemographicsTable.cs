using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the CustomerDemographics table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwCustomerDemographics")]
	public enum CustomerDemographicsTable
	{
		/// <summary>
		/// CustomerTypeID Column 
		/// </summary>
		[DatabaseColumn("CustomerTypeID", DbType.StringFixedLength, Length=10, AllowDBNull=false)]
		CustomerTypeID,
		
		/// <summary>
		/// CustomerDesc Column 
		/// </summary>
		[DatabaseColumn("CustomerDesc", DbType.String)]
		CustomerDesc

	}
}
