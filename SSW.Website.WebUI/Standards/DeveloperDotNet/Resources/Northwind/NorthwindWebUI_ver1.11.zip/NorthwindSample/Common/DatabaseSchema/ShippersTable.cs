using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Shippers table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwShippers")]
	public enum ShippersTable
	{
		/// <summary>
		/// ShipperID Column 
		/// </summary>
		[DatabaseColumn("ShipperID", DbType.Int32, AllowDBNull=false)]
		ShipperID,
		
		/// <summary>
		/// CompanyName Column 
		/// </summary>
		[DatabaseColumn("CompanyName", DbType.String, Length=40, AllowDBNull=false)]
		CompanyName,
		
		/// <summary>
		/// Phone Column 
		/// </summary>
		[DatabaseColumn("Phone", DbType.String, Length=24)]
		Phone

	}
}
