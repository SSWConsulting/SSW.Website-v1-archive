using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Customers table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwCustomers")]
	public enum CustomersTable
	{
		/// <summary>
		/// CustomerID Column 
		/// </summary>
		[DatabaseColumn("CustomerID", DbType.StringFixedLength, Length=5, AllowDBNull=false)]
		CustomerID,
		
		/// <summary>
		/// CompanyName Column 
		/// </summary>
		[DatabaseColumn("CompanyName", DbType.String, Length=40, AllowDBNull=false)]
		CompanyName,
		
		/// <summary>
		/// ContactName Column 
		/// </summary>
		[DatabaseColumn("ContactName", DbType.String, Length=30)]
		ContactName,
		
		/// <summary>
		/// ContactTitle Column 
		/// </summary>
		[DatabaseColumn("ContactTitle", DbType.String, Length=30)]
		ContactTitle,
		
		/// <summary>
		/// Address Column 
		/// </summary>
		[DatabaseColumn("Address", DbType.String, Length=60)]
		Address,
		
		/// <summary>
		/// City Column 
		/// </summary>
		[DatabaseColumn("City", DbType.String, Length=15)]
		City,
		
		/// <summary>
		/// Region Column 
		/// </summary>
		[DatabaseColumn("Region", DbType.String, Length=15)]
		Region,
		
		/// <summary>
		/// PostalCode Column 
		/// </summary>
		[DatabaseColumn("PostalCode", DbType.String, Length=10)]
		PostalCode,
		
		/// <summary>
		/// Country Column 
		/// </summary>
		[DatabaseColumn("Country", DbType.String, Length=15)]
		Country,
		
		/// <summary>
		/// Phone Column 
		/// </summary>
		[DatabaseColumn("Phone", DbType.String, Length=24)]
		Phone,
		
		/// <summary>
		/// Fax Column 
		/// </summary>
		[DatabaseColumn("Fax", DbType.String, Length=24)]
		Fax

	}
}
