using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the EmployeeTerritories table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwEmployeeTerritories")]
	public enum EmployeeTerritoriesTable
	{
		/// <summary>
		/// EmployeeID Column 
		/// </summary>
		[DatabaseColumn("EmployeeID", DbType.Int32, AllowDBNull=false)]
		EmployeeID,
		
		/// <summary>
		/// TerritoryID Column 
		/// </summary>
		[DatabaseColumn("TerritoryID", DbType.String, Length=20, AllowDBNull=false)]
		TerritoryID

	}
}
