using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Orders table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwOrders")]
	public enum OrdersTable
	{
		/// <summary>
		/// OrderID Column 
		/// </summary>
		[DatabaseColumn("OrderID", DbType.Int32, AllowDBNull=false)]
		OrderID,
		
		/// <summary>
		/// CustomerID Column 
		/// </summary>
		[DatabaseColumn("CustomerID", DbType.StringFixedLength, Length=5)]
		CustomerID,
		
		/// <summary>
		/// EmployeeID Column 
		/// </summary>
		[DatabaseColumn("EmployeeID", DbType.Int32)]
		EmployeeID,
		
		/// <summary>
		/// OrderDate Column 
		/// </summary>
		[DatabaseColumn("OrderDate", DbType.DateTime)]
		OrderDate,
		
		/// <summary>
		/// RequiredDate Column 
		/// </summary>
		[DatabaseColumn("RequiredDate", DbType.DateTime)]
		RequiredDate,
		
		/// <summary>
		/// ShippedDate Column 
		/// </summary>
		[DatabaseColumn("ShippedDate", DbType.DateTime)]
		ShippedDate,
		
		/// <summary>
		/// ShipVia Column 
		/// </summary>
		[DatabaseColumn("ShipVia", DbType.Int32)]
		ShipVia,
		
		/// <summary>
		/// Freight Column 
		/// </summary>
		[DatabaseColumn("Freight", DbType.Currency)]
		Freight,
		
		/// <summary>
		/// ShipName Column 
		/// </summary>
		[DatabaseColumn("ShipName", DbType.String, Length=40)]
		ShipName,
		
		/// <summary>
		/// ShipAddress Column 
		/// </summary>
		[DatabaseColumn("ShipAddress", DbType.String, Length=60)]
		ShipAddress,
		
		/// <summary>
		/// ShipCity Column 
		/// </summary>
		[DatabaseColumn("ShipCity", DbType.String, Length=15)]
		ShipCity,
		
		/// <summary>
		/// ShipRegion Column 
		/// </summary>
		[DatabaseColumn("ShipRegion", DbType.String, Length=15)]
		ShipRegion,
		
		/// <summary>
		/// ShipPostalCode Column 
		/// </summary>
		[DatabaseColumn("ShipPostalCode", DbType.String, Length=10)]
		ShipPostalCode,
		
		/// <summary>
		/// ShipCountry Column 
		/// </summary>
		[DatabaseColumn("ShipCountry", DbType.String, Length=15)]
		ShipCountry

	}
}
