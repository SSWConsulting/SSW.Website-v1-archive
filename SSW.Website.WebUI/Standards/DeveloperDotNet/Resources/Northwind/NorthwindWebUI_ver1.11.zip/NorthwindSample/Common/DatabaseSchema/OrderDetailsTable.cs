using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Order Details table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwOrderDetails")]
	public enum OrderDetailsTable
	{
		/// <summary>
		/// OrderID Column 
		/// </summary>
		[DatabaseColumn("OrderID", DbType.Int32, AllowDBNull=false)]
		OrderID,
		
		/// <summary>
		/// ProductID Column 
		/// </summary>
		[DatabaseColumn("ProductID", DbType.Int32, AllowDBNull=false)]
		ProductID,
		
		/// <summary>
		/// UnitPrice Column 
		/// </summary>
		[DatabaseColumn("UnitPrice", DbType.Currency, AllowDBNull=false)]
		UnitPrice,
		
		/// <summary>
		/// Quantity Column 
		/// </summary>
		[DatabaseColumn("Quantity", DbType.Int16, AllowDBNull=false)]
		Quantity,
		
		/// <summary>
		/// Discount Column 
		/// </summary>
		[DatabaseColumn("Discount", DbType.Single, AllowDBNull=false)]
		Discount

	}
}
