using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Products table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwProducts")]
	public enum ProductsTable
	{
		/// <summary>
		/// ProductID Column 
		/// </summary>
		[DatabaseColumn("ProductID", DbType.Int32, AllowDBNull=false)]
		ProductID,
		
		/// <summary>
		/// ProductName Column 
		/// </summary>
		[DatabaseColumn("ProductName", DbType.String, Length=40, AllowDBNull=false)]
		ProductName,
		
		/// <summary>
		/// SupplierID Column 
		/// </summary>
		[DatabaseColumn("SupplierID", DbType.Int32)]
		SupplierID,
		
		/// <summary>
		/// CategoryID Column 
		/// </summary>
		[DatabaseColumn("CategoryID", DbType.Int32)]
		CategoryID,
		
		/// <summary>
		/// QuantityPerUnit Column 
		/// </summary>
		[DatabaseColumn("QuantityPerUnit", DbType.String, Length=20)]
		QuantityPerUnit,
		
		/// <summary>
		/// UnitPrice Column 
		/// </summary>
		[DatabaseColumn("UnitPrice", DbType.Currency)]
		UnitPrice,
		
		/// <summary>
		/// UnitsInStock Column 
		/// </summary>
		[DatabaseColumn("UnitsInStock", DbType.Int16)]
		UnitsInStock,
		
		/// <summary>
		/// UnitsOnOrder Column 
		/// </summary>
		[DatabaseColumn("UnitsOnOrder", DbType.Int16)]
		UnitsOnOrder,
		
		/// <summary>
		/// ReorderLevel Column 
		/// </summary>
		[DatabaseColumn("ReorderLevel", DbType.Int16)]
		ReorderLevel,
		
		/// <summary>
		/// Discontinued Column 
		/// </summary>
		[DatabaseColumn("Discontinued", DbType.Boolean, AllowDBNull=false)]
		Discontinued

	}
}
