using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Region table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwRegion")]
	public enum RegionTable
	{
		/// <summary>
		/// RegionID Column 
		/// </summary>
		[DatabaseColumn("RegionID", DbType.Int32, AllowDBNull=false)]
		RegionID,
		
		/// <summary>
		/// RegionDescription Column 
		/// </summary>
		[DatabaseColumn("RegionDescription", DbType.StringFixedLength, Length=50, AllowDBNull=false)]
		RegionDescription

	}
}
