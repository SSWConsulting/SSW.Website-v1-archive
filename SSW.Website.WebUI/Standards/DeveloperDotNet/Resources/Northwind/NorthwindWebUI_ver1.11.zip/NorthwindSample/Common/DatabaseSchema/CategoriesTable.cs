using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Categories table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwCategories")]
	public enum CategoriesTable
	{
		/// <summary>
		/// CategoryID Column 
		/// </summary>
		[DatabaseColumn("CategoryID", DbType.Int32, AllowDBNull=false)]
		CategoryID,
		
		/// <summary>
		/// CategoryName Column 
		/// </summary>
		[DatabaseColumn("CategoryName", DbType.String, Length=15, AllowDBNull=false)]
		CategoryName,
		
		/// <summary>
		/// Description Column 
		/// </summary>
		[DatabaseColumn("Description", DbType.String)]
		Description,
		
		/// <summary>
		/// Picture Column 
		/// </summary>
		[DatabaseColumn("Picture", DbType.Binary)]
		Picture

	}
}
