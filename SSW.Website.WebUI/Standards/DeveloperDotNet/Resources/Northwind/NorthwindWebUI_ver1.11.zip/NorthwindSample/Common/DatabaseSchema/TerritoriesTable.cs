using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Territories table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwTerritories")]
	public enum TerritoriesTable
	{
		/// <summary>
		/// TerritoryID Column 
		/// </summary>
		[DatabaseColumn("TerritoryID", DbType.String, Length=20, AllowDBNull=false)]
		TerritoryID,
		
		/// <summary>
		/// TerritoryDescription Column 
		/// </summary>
		[DatabaseColumn("TerritoryDescription", DbType.StringFixedLength, Length=50, AllowDBNull=false)]
		TerritoryDescription,
		
		/// <summary>
		/// RegionID Column 
		/// </summary>
		[DatabaseColumn("RegionID", DbType.Int32, AllowDBNull=false)]
		RegionID

	}
}
