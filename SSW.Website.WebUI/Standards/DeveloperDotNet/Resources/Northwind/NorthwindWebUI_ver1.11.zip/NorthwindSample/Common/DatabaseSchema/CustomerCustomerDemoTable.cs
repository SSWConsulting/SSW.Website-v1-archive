using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace NorthwindSample.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the CustomerCustomerDemo table for use with the Query objects
	/// </summary>
	[DatabaseTable("gvwCustomerCustomerDemo")]
	public enum CustomerCustomerDemoTable
	{
		/// <summary>
		/// CustomerID Column 
		/// </summary>
		[DatabaseColumn("CustomerID", DbType.StringFixedLength, Length=5, AllowDBNull=false)]
		CustomerID,
		
		/// <summary>
		/// CustomerTypeID Column 
		/// </summary>
		[DatabaseColumn("CustomerTypeID", DbType.StringFixedLength, Length=10, AllowDBNull=false)]
		CustomerTypeID

	}
}
