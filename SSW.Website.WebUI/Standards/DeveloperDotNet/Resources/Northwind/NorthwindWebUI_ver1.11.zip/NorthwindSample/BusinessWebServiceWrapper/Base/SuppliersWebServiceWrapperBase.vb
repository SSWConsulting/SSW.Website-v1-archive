Imports System

Imports RAD.AppFramework.QueryObjects

Imports NorthwindSample.BusinessServiceInterfaces.Base

Imports NorthwindSample.Data
Imports NorthwindSample.WebServiceWrapper.SuppliersWebService

Namespace Base

	Public Class SuppliersWebServiceWrapperBase 
		Implements ISuppliersServiceBase


#Region "Fields"

		Protected m_UrlBase As String
		Private m_ServiceInstance As SuppliersService

#End Region


#Region "Constructors"

		Public Sub New(ByVal urlBase As String) 

			m_UrlBase = urlBase
			m_ServiceInstance = CreateServiceInstance()
			
		End Sub

#End Region


#Region "Protected Properties"

		Protected ReadOnly Property ServiceInstance() As SuppliersService
			Get
				Return m_ServiceInstance
			End Get
		End Property

#End Region


#Region "Protected Methods"

		Protected Overridable Function CreateServiceInstance() As SuppliersService

			Dim instance As New SuppliersService()
			instance.Url = m_UrlBase & "SuppliersService.asmx"

			InitializeInstance(instance)

			Return instance
			
		End Function
		

		'
		' InitializeInstance can be used to set security credentials
		'
		Protected Overridable Sub InitializeInstance(ByVal instance As SuppliersService)

		End Sub
		
		
#End Region


#Region "Public Methods"

		Public Function GetAll(ByVal dataSetFill As SuppliersDataSet) As Integer _
			Implements ISuppliersServiceBase.GetAll

			Dim resultsTable As DataTable = ServiceInstance.GetAll().Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function


		Public Function GetByQuery(ByVal dataSetFill As DataSet, ByVal queryDefinition As Query) As Integer _
			Implements ISuppliersServiceBase.GetByQuery

			Dim resultsTable As DataTable = ServiceInstance.GetByQuery(queryDefinition).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function
		
		
		Public Function UpdateDataSet(ByVal dataSetUpdate As SuppliersDataSet) As Integer _
			Implements ISuppliersServiceBase.UpdateDataSet

			Dim returnedDataSet As DataSet = ServiceInstance.UpdateDataSet(dataSetUpdate)

			Dim recordCount As Integer = returnedDataSet.Tables(0).Rows.Count

			If recordCount > 0 Then

				'
				' Need to clear the dataset as Merge does not work with new rows 
				' that have a primary key assigned automatically
				'
				dataSetUpdate.Clear()
                dataSetUpdate.Merge(returnedDataSet)

            End If

            Return recordCount

        End Function
			
		Public Function GetBySupplierID(ByVal dataSetFill As SuppliersDataSet, ByVal SupplierID As Int32) As Integer _
			Implements ISuppliersServiceBase.GetBySupplierID

			Dim resultsTable As DataTable = ServiceInstance.GetBySupplierID(SupplierID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	

		
#End Region
		
	End Class
	
End Namespace
