Imports System

Imports RAD.AppFramework.QueryObjects

Imports NorthwindSample.BusinessServiceInterfaces.Base

Imports NorthwindSample.Data
Imports NorthwindSample.WebServiceWrapper.ProductsWebService

Namespace Base

	Public Class ProductsWebServiceWrapperBase 
		Implements IProductsServiceBase


#Region "Fields"

		Protected m_UrlBase As String
		Private m_ServiceInstance As ProductsService

#End Region


#Region "Constructors"

		Public Sub New(ByVal urlBase As String) 

			m_UrlBase = urlBase
			m_ServiceInstance = CreateServiceInstance()
			
		End Sub

#End Region


#Region "Protected Properties"

		Protected ReadOnly Property ServiceInstance() As ProductsService
			Get
				Return m_ServiceInstance
			End Get
		End Property

#End Region


#Region "Protected Methods"

		Protected Overridable Function CreateServiceInstance() As ProductsService

			Dim instance As New ProductsService()
			instance.Url = m_UrlBase & "ProductsService.asmx"

			InitializeInstance(instance)

			Return instance
			
		End Function
		

		'
		' InitializeInstance can be used to set security credentials
		'
		Protected Overridable Sub InitializeInstance(ByVal instance As ProductsService)

		End Sub
		
		
#End Region


#Region "Public Methods"

		Public Function GetAll(ByVal dataSetFill As ProductsDataSet) As Integer _
			Implements IProductsServiceBase.GetAll

			Dim resultsTable As DataTable = ServiceInstance.GetAll().Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function


		Public Function GetByQuery(ByVal dataSetFill As DataSet, ByVal queryDefinition As Query) As Integer _
			Implements IProductsServiceBase.GetByQuery

			Dim resultsTable As DataTable = ServiceInstance.GetByQuery(queryDefinition).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function
		
		
		Public Function UpdateDataSet(ByVal dataSetUpdate As ProductsDataSet) As Integer _
			Implements IProductsServiceBase.UpdateDataSet

			Dim returnedDataSet As DataSet = ServiceInstance.UpdateDataSet(dataSetUpdate)

			Dim recordCount As Integer = returnedDataSet.Tables(0).Rows.Count

			If recordCount > 0 Then

				'
				' Need to clear the dataset as Merge does not work with new rows 
				' that have a primary key assigned automatically
				'
				dataSetUpdate.Clear()
                dataSetUpdate.Merge(returnedDataSet)

            End If

            Return recordCount

        End Function
			
		Public Function GetByProductID(ByVal dataSetFill As ProductsDataSet, ByVal ProductID As Int32) As Integer _
			Implements IProductsServiceBase.GetByProductID

			Dim resultsTable As DataTable = ServiceInstance.GetByProductID(ProductID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	
		
		Public Function GetByCategoryID(ByVal dataSetFill As ProductsDataSet, ByVal CategoryID As Int32) As Integer _
			Implements IProductsServiceBase.GetByCategoryID

			Dim resultsTable As DataTable = ServiceInstance.GetByCategoryID(CategoryID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	
		
		Public Function GetBySupplierID(ByVal dataSetFill As ProductsDataSet, ByVal SupplierID As Int32) As Integer _
			Implements IProductsServiceBase.GetBySupplierID

			Dim resultsTable As DataTable = ServiceInstance.GetBySupplierID(SupplierID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	

		
#End Region
		
	End Class
	
End Namespace
