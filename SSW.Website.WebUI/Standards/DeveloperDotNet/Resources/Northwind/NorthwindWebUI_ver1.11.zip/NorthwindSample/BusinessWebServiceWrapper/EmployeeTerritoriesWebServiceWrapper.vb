Imports System
Imports System.Data
Imports System.Xml
Imports System.Web.Services

Imports RAD.AppFramework.QueryObjects
Imports NorthwindSample.BusinessServiceInterfaces

Imports NorthwindSample.Data
Imports NorthwindSample.WebServiceWrapper.Base

Imports NorthwindSample.WebServiceWrapper.EmployeeTerritoriesWebService

Public Class EmployeeTerritoriesWebServiceWrapper 
	Inherits EmployeeTerritoriesWebServiceWrapperBase
		Implements IEmployeeTerritoriesService 

	
#Region "Fields"


#End Region


#Region "Constructors"

	Public Sub New(ByVal urlBase As String)
	
		MyBase.New(urlBase)
		
	End Sub
		

#End Region


#Region "Public Properties"



#End Region


#Region "Private Methods"



#End Region


#Region "Public Methods"



#End Region


End Class
