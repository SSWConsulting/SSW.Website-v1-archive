Imports System

Imports RAD.AppFramework.QueryObjects

Imports NorthwindSample.BusinessServiceInterfaces.Base

Imports NorthwindSample.Data
Imports NorthwindSample.WebServiceWrapper.OrderDetailsWebService

Namespace Base

	Public Class OrderDetailsWebServiceWrapperBase 
		Implements IOrderDetailsServiceBase


#Region "Fields"

		Protected m_UrlBase As String
		Private m_ServiceInstance As OrderDetailsService

#End Region


#Region "Constructors"

		Public Sub New(ByVal urlBase As String) 

			m_UrlBase = urlBase
			m_ServiceInstance = CreateServiceInstance()
			
		End Sub

#End Region


#Region "Protected Properties"

		Protected ReadOnly Property ServiceInstance() As OrderDetailsService
			Get
				Return m_ServiceInstance
			End Get
		End Property

#End Region


#Region "Protected Methods"

		Protected Overridable Function CreateServiceInstance() As OrderDetailsService

			Dim instance As New OrderDetailsService()
			instance.Url = m_UrlBase & "OrderDetailsService.asmx"

			InitializeInstance(instance)

			Return instance
			
		End Function
		

		'
		' InitializeInstance can be used to set security credentials
		'
		Protected Overridable Sub InitializeInstance(ByVal instance As OrderDetailsService)

		End Sub
		
		
#End Region


#Region "Public Methods"

		Public Function GetAll(ByVal dataSetFill As OrderDetailsDataSet) As Integer _
			Implements IOrderDetailsServiceBase.GetAll

			Dim resultsTable As DataTable = ServiceInstance.GetAll().Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function


		Public Function GetByQuery(ByVal dataSetFill As DataSet, ByVal queryDefinition As Query) As Integer _
			Implements IOrderDetailsServiceBase.GetByQuery

			Dim resultsTable As DataTable = ServiceInstance.GetByQuery(queryDefinition).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function
		
		
		Public Function UpdateDataSet(ByVal dataSetUpdate As OrderDetailsDataSet) As Integer _
			Implements IOrderDetailsServiceBase.UpdateDataSet

			Dim returnedDataSet As DataSet = ServiceInstance.UpdateDataSet(dataSetUpdate)

			Dim recordCount As Integer = returnedDataSet.Tables(0).Rows.Count

			If recordCount > 0 Then

				'
				' Need to clear the dataset as Merge does not work with new rows 
				' that have a primary key assigned automatically
				'
				dataSetUpdate.Clear()
                dataSetUpdate.Merge(returnedDataSet)

            End If

            Return recordCount

        End Function
			
		Public Function GetByOrderIDAndProductID(ByVal dataSetFill As OrderDetailsDataSet, ByVal OrderID As Int32, ByVal ProductID As Int32) As Integer _
			Implements IOrderDetailsServiceBase.GetByOrderIDAndProductID

			Dim resultsTable As DataTable = ServiceInstance.GetByOrderIDAndProductID(OrderID, ProductID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	
		
		Public Function GetByOrderID(ByVal dataSetFill As OrderDetailsDataSet, ByVal OrderID As Int32) As Integer _
			Implements IOrderDetailsServiceBase.GetByOrderID

			Dim resultsTable As DataTable = ServiceInstance.GetByOrderID(OrderID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	
		
		Public Function GetByProductID(ByVal dataSetFill As OrderDetailsDataSet, ByVal ProductID As Int32) As Integer _
			Implements IOrderDetailsServiceBase.GetByProductID

			Dim resultsTable As DataTable = ServiceInstance.GetByProductID(ProductID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	

		
#End Region
		
	End Class
	
End Namespace
