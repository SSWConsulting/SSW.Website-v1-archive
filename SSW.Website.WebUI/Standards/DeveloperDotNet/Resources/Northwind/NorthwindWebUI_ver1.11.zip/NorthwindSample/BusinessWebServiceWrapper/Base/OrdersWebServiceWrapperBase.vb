Imports System

Imports RAD.AppFramework.QueryObjects

Imports NorthwindSample.BusinessServiceInterfaces.Base

Imports NorthwindSample.Data
Imports NorthwindSample.WebServiceWrapper.OrdersWebService

Namespace Base

	Public Class OrdersWebServiceWrapperBase 
		Implements IOrdersServiceBase


#Region "Fields"

		Protected m_UrlBase As String
		Private m_ServiceInstance As OrdersService

#End Region


#Region "Constructors"

		Public Sub New(ByVal urlBase As String) 

			m_UrlBase = urlBase
			m_ServiceInstance = CreateServiceInstance()
			
		End Sub

#End Region


#Region "Protected Properties"

		Protected ReadOnly Property ServiceInstance() As OrdersService
			Get
				Return m_ServiceInstance
			End Get
		End Property

#End Region


#Region "Protected Methods"

		Protected Overridable Function CreateServiceInstance() As OrdersService

			Dim instance As New OrdersService()
			instance.Url = m_UrlBase & "OrdersService.asmx"

			InitializeInstance(instance)

			Return instance
			
		End Function
		

		'
		' InitializeInstance can be used to set security credentials
		'
		Protected Overridable Sub InitializeInstance(ByVal instance As OrdersService)

		End Sub
		
		
#End Region


#Region "Public Methods"

		Public Function GetAll(ByVal dataSetFill As OrdersDataSet) As Integer _
			Implements IOrdersServiceBase.GetAll

			Dim resultsTable As DataTable = ServiceInstance.GetAll().Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function


		Public Function GetByQuery(ByVal dataSetFill As DataSet, ByVal queryDefinition As Query) As Integer _
			Implements IOrdersServiceBase.GetByQuery

			Dim resultsTable As DataTable = ServiceInstance.GetByQuery(queryDefinition).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function
		
		
		Public Function UpdateDataSet(ByVal dataSetUpdate As OrdersDataSet) As Integer _
			Implements IOrdersServiceBase.UpdateDataSet

			Dim returnedDataSet As DataSet = ServiceInstance.UpdateDataSet(dataSetUpdate)

			Dim recordCount As Integer = returnedDataSet.Tables(0).Rows.Count

			If recordCount > 0 Then

				'
				' Need to clear the dataset as Merge does not work with new rows 
				' that have a primary key assigned automatically
				'
				dataSetUpdate.Clear()
                dataSetUpdate.Merge(returnedDataSet)

            End If

            Return recordCount

        End Function
			
		Public Function GetByOrderID(ByVal dataSetFill As OrdersDataSet, ByVal OrderID As Int32) As Integer _
			Implements IOrdersServiceBase.GetByOrderID

			Dim resultsTable As DataTable = ServiceInstance.GetByOrderID(OrderID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	
		
		Public Function GetByCustomerID(ByVal dataSetFill As OrdersDataSet, ByVal CustomerID As String) As Integer _
			Implements IOrdersServiceBase.GetByCustomerID

			Dim resultsTable As DataTable = ServiceInstance.GetByCustomerID(CustomerID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	
		
		Public Function GetByEmployeeID(ByVal dataSetFill As OrdersDataSet, ByVal EmployeeID As Int32) As Integer _
			Implements IOrdersServiceBase.GetByEmployeeID

			Dim resultsTable As DataTable = ServiceInstance.GetByEmployeeID(EmployeeID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	
		
		Public Function GetByShipVia(ByVal dataSetFill As OrdersDataSet, ByVal ShipVia As Int32) As Integer _
			Implements IOrdersServiceBase.GetByShipVia

			Dim resultsTable As DataTable = ServiceInstance.GetByShipVia(ShipVia).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	

		
#End Region
		
	End Class
	
End Namespace
