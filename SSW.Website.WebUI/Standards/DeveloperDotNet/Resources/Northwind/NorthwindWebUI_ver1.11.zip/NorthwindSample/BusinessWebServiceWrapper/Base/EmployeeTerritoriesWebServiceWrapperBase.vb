Imports System

Imports RAD.AppFramework.QueryObjects

Imports NorthwindSample.BusinessServiceInterfaces.Base

Imports NorthwindSample.Data
Imports NorthwindSample.WebServiceWrapper.EmployeeTerritoriesWebService

Namespace Base

	Public Class EmployeeTerritoriesWebServiceWrapperBase 
		Implements IEmployeeTerritoriesServiceBase


#Region "Fields"

		Protected m_UrlBase As String
		Private m_ServiceInstance As EmployeeTerritoriesService

#End Region


#Region "Constructors"

		Public Sub New(ByVal urlBase As String) 

			m_UrlBase = urlBase
			m_ServiceInstance = CreateServiceInstance()
			
		End Sub

#End Region


#Region "Protected Properties"

		Protected ReadOnly Property ServiceInstance() As EmployeeTerritoriesService
			Get
				Return m_ServiceInstance
			End Get
		End Property

#End Region


#Region "Protected Methods"

		Protected Overridable Function CreateServiceInstance() As EmployeeTerritoriesService

			Dim instance As New EmployeeTerritoriesService()
			instance.Url = m_UrlBase & "EmployeeTerritoriesService.asmx"

			InitializeInstance(instance)

			Return instance
			
		End Function
		

		'
		' InitializeInstance can be used to set security credentials
		'
		Protected Overridable Sub InitializeInstance(ByVal instance As EmployeeTerritoriesService)

		End Sub
		
		
#End Region


#Region "Public Methods"

		Public Function GetAll(ByVal dataSetFill As EmployeeTerritoriesDataSet) As Integer _
			Implements IEmployeeTerritoriesServiceBase.GetAll

			Dim resultsTable As DataTable = ServiceInstance.GetAll().Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function


		Public Function GetByQuery(ByVal dataSetFill As DataSet, ByVal queryDefinition As Query) As Integer _
			Implements IEmployeeTerritoriesServiceBase.GetByQuery

			Dim resultsTable As DataTable = ServiceInstance.GetByQuery(queryDefinition).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
		
		End Function
		
		
		Public Function UpdateDataSet(ByVal dataSetUpdate As EmployeeTerritoriesDataSet) As Integer _
			Implements IEmployeeTerritoriesServiceBase.UpdateDataSet

			Dim returnedDataSet As DataSet = ServiceInstance.UpdateDataSet(dataSetUpdate)

			Dim recordCount As Integer = returnedDataSet.Tables(0).Rows.Count

			If recordCount > 0 Then

				'
				' Need to clear the dataset as Merge does not work with new rows 
				' that have a primary key assigned automatically
				'
				dataSetUpdate.Clear()
                dataSetUpdate.Merge(returnedDataSet)

            End If

            Return recordCount

        End Function
			
		Public Function GetByEmployeeIDAndTerritoryID(ByVal dataSetFill As EmployeeTerritoriesDataSet, ByVal EmployeeID As Int32, ByVal TerritoryID As String) As Integer _
			Implements IEmployeeTerritoriesServiceBase.GetByEmployeeIDAndTerritoryID

			Dim resultsTable As DataTable = ServiceInstance.GetByEmployeeIDAndTerritoryID(EmployeeID, TerritoryID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	
		
		Public Function GetByEmployeeID(ByVal dataSetFill As EmployeeTerritoriesDataSet, ByVal EmployeeID As Int32) As Integer _
			Implements IEmployeeTerritoriesServiceBase.GetByEmployeeID

			Dim resultsTable As DataTable = ServiceInstance.GetByEmployeeID(EmployeeID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	
		
		Public Function GetByTerritoryID(ByVal dataSetFill As EmployeeTerritoriesDataSet, ByVal TerritoryID As String) As Integer _
			Implements IEmployeeTerritoriesServiceBase.GetByTerritoryID

			Dim resultsTable As DataTable = ServiceInstance.GetByTerritoryID(TerritoryID).Tables(0)
			dataSetFill.Merge(resultsTable)
			Return resultsTable.Rows.Count
			
		End Function
	

		
#End Region
		
	End Class
	
End Namespace
