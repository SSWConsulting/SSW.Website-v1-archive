using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the CustomerCustomerDemo table
	/// </summary>
	public class CustomerCustomerDemo_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("CustomerID", CustomerID);
			CriteriaCount += LoadSearchString("CustomerTypeID", CustomerTypeID);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "CustomerCustomerDemo Search";

				if (CriteriaCount > 0)
				{
					CustomerCustomerDemoGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void CustomerCustomerDemoGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(string.Format(
						"CustomerCustomerDemo.aspx?{0}={1}&{2}={3}", 
						"CustomerID", e.Item.Cells[1].Text, 
						"CustomerTypeID", e.Item.Cells[2].Text)
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void CustomerCustomerDemoGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			CustomerCustomerDemoGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void CustomerCustomerDemoGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the CustomerCustomerDemo table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_CustomerCustomerDemoQuery = CommonFactory.CreateQuery();

			AddToQuery(m_CustomerCustomerDemoQuery, CustomerCustomerDemoTable.CustomerID, Comparison.EqualTo, CustomerID);
			AddToQuery(m_CustomerCustomerDemoQuery, CustomerCustomerDemoTable.CustomerTypeID, Comparison.EqualTo, CustomerTypeID);
			

			AddSortToQuery(m_CustomerCustomerDemoQuery, typeof(CustomerCustomerDemoTable));
			
			ICustomerCustomerDemoService CustomerCustomerDemoLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCustomerCustomerDemoService();
			int ResultCount = CustomerCustomerDemoLogic.GetByQuery(m_CustomerCustomerDemoDataSet, m_CustomerCustomerDemoQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				CustomerCustomerDemoGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.CustomerCustomerDemoDataSet m_CustomerCustomerDemoDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid CustomerCustomerDemoGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText CustomerID;
		protected System.Web.UI.HtmlControls.HtmlInputText CustomerTypeID;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_CustomerCustomerDemoDataSet = new NorthwindSample.Data.CustomerCustomerDemoDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_CustomerCustomerDemoDataSet)).BeginInit();
			this.CustomerCustomerDemoGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.CustomerCustomerDemoGrid_ItemCommand);
			this.CustomerCustomerDemoGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.CustomerCustomerDemoGrid_PageIndexChanged);
			this.CustomerCustomerDemoGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.CustomerCustomerDemoGrid_SortCommand);
			// 
			// m_CustomerCustomerDemoDataSet
			// 
			this.m_CustomerCustomerDemoDataSet.DataSetName = "CustomerCustomerDemoDataSet";
			this.m_CustomerCustomerDemoDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_CustomerCustomerDemoDataSet)).EndInit();

		}
		
		#endregion

	}
}
