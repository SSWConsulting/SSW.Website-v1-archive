using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the Orders table
	/// </summary>
	public class Orders_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("OrderID", OrderID);
			CriteriaCount += LoadSearchString("CustomerID", CustomerID);
			CriteriaCount += LoadSearchString("EmployeeID", EmployeeID);
			CriteriaCount += LoadSearchBetween("OrderDate", OrderDateBegin, OrderDateEnd);
			CriteriaCount += LoadSearchBetween("RequiredDate", RequiredDateBegin, RequiredDateEnd);
			CriteriaCount += LoadSearchBetween("ShippedDate", ShippedDateBegin, ShippedDateEnd);
			CriteriaCount += LoadSearchBetween("ShipVia", ShipViaBegin, ShipViaEnd);
			CriteriaCount += LoadSearchBetween("Freight", FreightBegin, FreightEnd);
			CriteriaCount += LoadSearchString("ShipName", ShipName);
			CriteriaCount += LoadSearchString("ShipAddress", ShipAddress);
			CriteriaCount += LoadSearchString("ShipCity", ShipCity);
			CriteriaCount += LoadSearchString("ShipRegion", ShipRegion);
			CriteriaCount += LoadSearchString("ShipPostalCode", ShipPostalCode);
			CriteriaCount += LoadSearchString("ShipCountry", ShipCountry);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "Orders Search";

				if (CriteriaCount > 0)
				{
					OrdersGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void OrdersGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(
						string.Format("Orders.aspx?{0}={1}", "OrderID", OrdersGrid.DataKeys[e.Item.ItemIndex].ToString())
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void OrdersGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			OrdersGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void OrdersGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the Orders table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_OrdersQuery = CommonFactory.CreateQuery();

			AddToQuery(m_OrdersQuery, OrdersTable.OrderID, Comparison.EqualTo, OrderID);
			AddToQuery(m_OrdersQuery, OrdersTable.CustomerID, Comparison.EqualTo, CustomerID);
			AddToQuery(m_OrdersQuery, OrdersTable.EmployeeID, Comparison.EqualTo, EmployeeID);
			AddToQuery(m_OrdersQuery, OrdersTable.OrderDate, OrderDateBegin, OrderDateEnd);
			AddToQuery(m_OrdersQuery, OrdersTable.RequiredDate, RequiredDateBegin, RequiredDateEnd);
			AddToQuery(m_OrdersQuery, OrdersTable.ShippedDate, ShippedDateBegin, ShippedDateEnd);
			AddToQuery(m_OrdersQuery, OrdersTable.ShipVia, ShipViaBegin, ShipViaEnd);
			AddToQuery(m_OrdersQuery, OrdersTable.Freight, FreightBegin, FreightEnd);
			AddToQuery(m_OrdersQuery, OrdersTable.ShipName, Comparison.Contains, ShipName);
			AddToQuery(m_OrdersQuery, OrdersTable.ShipAddress, Comparison.Contains, ShipAddress);
			AddToQuery(m_OrdersQuery, OrdersTable.ShipCity, Comparison.Contains, ShipCity);
			AddToQuery(m_OrdersQuery, OrdersTable.ShipRegion, Comparison.Contains, ShipRegion);
			AddToQuery(m_OrdersQuery, OrdersTable.ShipPostalCode, Comparison.Contains, ShipPostalCode);
			AddToQuery(m_OrdersQuery, OrdersTable.ShipCountry, Comparison.Contains, ShipCountry);
			

			AddSortToQuery(m_OrdersQuery, typeof(OrdersTable));
			
			IOrdersService OrdersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateOrdersService();
			int ResultCount = OrdersLogic.GetByQuery(m_OrdersDataSet, m_OrdersQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				OrdersGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.OrdersDataSet m_OrdersDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid OrdersGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText OrderID;
		protected System.Web.UI.HtmlControls.HtmlInputText CustomerID;
		protected System.Web.UI.HtmlControls.HtmlInputText EmployeeID;
		protected System.Web.UI.HtmlControls.HtmlInputText OrderDateBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText OrderDateEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText RequiredDateBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText RequiredDateEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText ShippedDateBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText ShippedDateEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText ShipViaBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText ShipViaEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText FreightBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText FreightEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText ShipName;
		protected System.Web.UI.HtmlControls.HtmlInputText ShipAddress;
		protected System.Web.UI.HtmlControls.HtmlInputText ShipCity;
		protected System.Web.UI.HtmlControls.HtmlInputText ShipRegion;
		protected System.Web.UI.HtmlControls.HtmlInputText ShipPostalCode;
		protected System.Web.UI.HtmlControls.HtmlInputText ShipCountry;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_OrdersDataSet = new NorthwindSample.Data.OrdersDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_OrdersDataSet)).BeginInit();
			this.OrdersGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.OrdersGrid_ItemCommand);
			this.OrdersGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.OrdersGrid_PageIndexChanged);
			this.OrdersGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.OrdersGrid_SortCommand);
			// 
			// m_OrdersDataSet
			// 
			this.m_OrdersDataSet.DataSetName = "OrdersDataSet";
			this.m_OrdersDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_OrdersDataSet)).EndInit();

		}
		
		#endregion

	}
}
