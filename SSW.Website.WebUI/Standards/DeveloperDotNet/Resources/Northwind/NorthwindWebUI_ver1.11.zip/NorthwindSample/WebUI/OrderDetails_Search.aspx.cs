using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the Order Details table
	/// </summary>
	public class OrderDetails_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("OrderID", OrderID);
			CriteriaCount += LoadSearchString("ProductID", ProductID);
			CriteriaCount += LoadSearchBetween("UnitPrice", UnitPriceBegin, UnitPriceEnd);
			CriteriaCount += LoadSearchBetween("Quantity", QuantityBegin, QuantityEnd);
			CriteriaCount += LoadSearchBetween("Discount", DiscountBegin, DiscountEnd);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "Order Details Search";

				if (CriteriaCount > 0)
				{
					OrderDetailsGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void OrderDetailsGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(string.Format(
						"OrderDetails.aspx?{0}={1}&{2}={3}", 
						"OrderID", e.Item.Cells[1].Text, 
						"ProductID", e.Item.Cells[2].Text)
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void OrderDetailsGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			OrderDetailsGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void OrderDetailsGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the Order Details table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_OrderDetailsQuery = CommonFactory.CreateQuery();

			AddToQuery(m_OrderDetailsQuery, OrderDetailsTable.OrderID, Comparison.EqualTo, OrderID);
			AddToQuery(m_OrderDetailsQuery, OrderDetailsTable.ProductID, Comparison.EqualTo, ProductID);
			AddToQuery(m_OrderDetailsQuery, OrderDetailsTable.UnitPrice, UnitPriceBegin, UnitPriceEnd);
			AddToQuery(m_OrderDetailsQuery, OrderDetailsTable.Quantity, QuantityBegin, QuantityEnd);
			AddToQuery(m_OrderDetailsQuery, OrderDetailsTable.Discount, DiscountBegin, DiscountEnd);
			

			AddSortToQuery(m_OrderDetailsQuery, typeof(OrderDetailsTable));
			
			IOrderDetailsService OrderDetailsLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateOrderDetailsService();
			int ResultCount = OrderDetailsLogic.GetByQuery(m_OrderDetailsDataSet, m_OrderDetailsQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				OrderDetailsGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.OrderDetailsDataSet m_OrderDetailsDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid OrderDetailsGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText OrderID;
		protected System.Web.UI.HtmlControls.HtmlInputText ProductID;
		protected System.Web.UI.HtmlControls.HtmlInputText UnitPriceBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText UnitPriceEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText QuantityBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText QuantityEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText DiscountBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText DiscountEnd;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_OrderDetailsDataSet = new NorthwindSample.Data.OrderDetailsDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_OrderDetailsDataSet)).BeginInit();
			this.OrderDetailsGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.OrderDetailsGrid_ItemCommand);
			this.OrderDetailsGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.OrderDetailsGrid_PageIndexChanged);
			this.OrderDetailsGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.OrderDetailsGrid_SortCommand);
			// 
			// m_OrderDetailsDataSet
			// 
			this.m_OrderDetailsDataSet.DataSetName = "OrderDetailsDataSet";
			this.m_OrderDetailsDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_OrderDetailsDataSet)).EndInit();

		}
		
		#endregion

	}
}
