using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Code-behind file for the Products.aspx Page
	/// </summary>
	public class Products : EditablePage
	{
		#region Constants


		#endregion


		#region Fields

		private Int32 m_ProductIDCurrent;
		

		#endregion

				
		#region Page Events

		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			//
			// Find primary key values to use to populate the form
			//
			if (HasQueryStringParameter("ProductID"))
			{
				m_ProductIDCurrent = Convert.ToInt32(Request.QueryString["ProductID"]);
				
				DataEntryMode = PageDataEntryMode.EditRow;

				PageTitle = string.Format("Products - Editing {0}: {1}", "ProductID", m_ProductIDCurrent);
			}
			else
			{
				DataEntryMode = PageDataEntryMode.AddRow;

				PageTitle = "Products - Adding a new entry";
				lblMessage.Text = "Adding a new entry";
			}

			if (Page.IsPostBack)
			{
			
			}
			else
			{
				//
				// Initial Page Request
				//
				PopulateControls();

				if (DataEntryMode == PageDataEntryMode.EditRow || DataEntryMode == PageDataEntryMode.ViewRow)
				{
					if (!LoadData())
					{
						//
						// Could not load the row from the database
						//
						lblMessage.Text = "Error loading Products";

						DataEntryMode = PageDataEntryMode.ErrorOccurred;
						
						DisableDataEntryControls(this.Controls);
					}
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Apply the changes and return to the previous screen
		/// </summary>
		private void btnOK_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				Response.Redirect(UrlPrevious.ToString());
			}
		}


		/// <summary>
		/// Apply the changes and remain on this page
		/// </summary>
		private void btnApply_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				//
				// Redirect back to this page in Edit mode
				//
				if (DataEntryMode == PageDataEntryMode.AddRow)
				{	
					UriBuilder EditUri = new UriBuilder(Request.Url);
					EditUri.Query += string.Format("{0}={1}", "ProductID", m_ProductIDCurrent);

					//
					// Redirect back to this page 
					// with the primary key information in the query string
					//
					Response.Redirect(EditUri.ToString());
							
				}
				else
				{
					lblMessage.Text = "Products saved";

					LoadData();
				}
			}
			else
			{
				lblMessage.Text = "Error saving Products";
				DataEntryMode = PageDataEntryMode.ErrorOccurred;
			}
		}
		
		
		/// <summary>
		/// return to the previous screen
		/// </summary>
		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(UrlPrevious.ToString());
		}
		
		#endregion


		#region Private Methods
		
		/// <summary>
		/// Loads data from the database for drop down lists
		/// </summary>
		private void PopulateControls()
		{
			
			//
			// Populate the SupplierID Drop Down List
			//
			SuppliersDataSet SuppliersDS = new SuppliersDataSet();
			ISuppliersService SuppliersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateSuppliersService();
			
			if (SuppliersLogic.GetAll(SuppliersDS) > 0)
			{
				ListItem SuppliersListItemNew;
				foreach (SuppliersDataSet.SuppliersRow SuppliersCurrent in SuppliersDS.Suppliers.Rows)
				{
					SuppliersListItemNew = new ListItem();
					SuppliersListItemNew.Value = SuppliersCurrent.SupplierID.ToString();
					SuppliersListItemNew.Text = SuppliersCurrent.SupplierID.ToString();

					ctlSupplierID.Items.Add(SuppliersListItemNew);
				}
			}
			
			//
			// Populate the CategoryID Drop Down List
			//
			CategoriesDataSet CategoriesDS = new CategoriesDataSet();
			ICategoriesService CategoriesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCategoriesService();
			
			if (CategoriesLogic.GetAll(CategoriesDS) > 0)
			{
				ListItem CategoriesListItemNew;
				foreach (CategoriesDataSet.CategoriesRow CategoriesCurrent in CategoriesDS.Categories.Rows)
				{
					CategoriesListItemNew = new ListItem();
					CategoriesListItemNew.Value = CategoriesCurrent.CategoryID.ToString();
					CategoriesListItemNew.Text = CategoriesCurrent.CategoryID.ToString();

					ctlCategoryID.Items.Add(CategoriesListItemNew);
				}
			}
			
		}
		
		/// <summary>
		/// Loads a row from the Products table for viewing or editing
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool LoadData()
		{
			if ((DataEntryMode != PageDataEntryMode.EditRow) && (DataEntryMode != PageDataEntryMode.ViewRow))
			{
				return true;
			}
			
			ProductsDataSet ProductsDS = new ProductsDataSet();
			IProductsService ProductsLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateProductsService();
			
			if (ProductsLogic.GetByProductID(ProductsDS, m_ProductIDCurrent) == 0)
			{
				//
				// Products Row not found
				//
				return false;
			}

			ProductsDataSet.ProductsRow ProductsRowCurrent = ProductsDS.Products[0];
			ListItem SelectedListItem;
			
			//
			// Populate the Page controls from the DataRow
			//
			ctlProductID.Text = ProductsRowCurrent.ProductID.ToString();
			ctlProductName.Text = ProductsRowCurrent.ProductName;
			
			if (!ProductsRowCurrent.IsSupplierIDNull())
			{
				SelectedListItem = ctlSupplierID.Items.FindByValue(ProductsRowCurrent.SupplierID.ToString());
				if (SelectedListItem != null)
				{
					ctlSupplierID.ClearSelection();
					SelectedListItem.Selected = true;
				}
			}
			
			if (!ProductsRowCurrent.IsCategoryIDNull())
			{
				SelectedListItem = ctlCategoryID.Items.FindByValue(ProductsRowCurrent.CategoryID.ToString());
				if (SelectedListItem != null)
				{
					ctlCategoryID.ClearSelection();
					SelectedListItem.Selected = true;
				}
			}
			ctlQuantityPerUnit.Text = (ProductsRowCurrent.IsQuantityPerUnitNull()) ? string.Empty : ProductsRowCurrent.QuantityPerUnit;
			ctlUnitPrice.Text = (ProductsRowCurrent.IsUnitPriceNull()) ? string.Empty : ProductsRowCurrent.UnitPrice.ToString("0.00");
			ctlUnitsInStock.Text = (ProductsRowCurrent.IsUnitsInStockNull()) ? string.Empty : ProductsRowCurrent.UnitsInStock.ToString();
			ctlUnitsOnOrder.Text = (ProductsRowCurrent.IsUnitsOnOrderNull()) ? string.Empty : ProductsRowCurrent.UnitsOnOrder.ToString();
			ctlReorderLevel.Text = (ProductsRowCurrent.IsReorderLevelNull()) ? string.Empty : ProductsRowCurrent.ReorderLevel.ToString();
			ctlDiscontinued.Checked = ProductsRowCurrent.Discontinued;
			
			
			return true;
		}
		
		
		/// <summary>
		/// Adds or updates the row in the Database
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool SaveData()
		{
			//
			// Check that the Form has passed validation
			//
			Page.Validate();
			
			if (!Page.IsValid)
			{
				// Validation failed
				return false;
			}
			
			ProductsDataSet ProductsDS = new ProductsDataSet();
			IProductsService ProductsLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateProductsService();
			ProductsDataSet.ProductsRow ProductsRowCurrent;
			
			
			switch (DataEntryMode)
			{
				case PageDataEntryMode.AddRow:
					//
					// Create a New Row
					//
					ProductsRowCurrent = ProductsDS.Products.NewProductsRow();
					break;
					
				case PageDataEntryMode.EditRow:
					//
					// Update existing Row
					//
					if (ProductsLogic.GetByProductID(ProductsDS, m_ProductIDCurrent) == 0)
					{
						//
						// Products Row not found
						//
						return false;
					}
					else
					{
						ProductsRowCurrent = ProductsDS.Products[0];
					}
					break;
					
				default:
					return false;
			}

			//
			// Set the DataRow values from the Page Controls
			//
			
			// ProductName
			ProductsRowCurrent.ProductName = ctlProductName.Text;
			// SupplierID
			
			
			if (ctlSupplierID.SelectedIndex == 0)
			{
				ProductsRowCurrent.SetSupplierIDNull();	
			}
			else
			{
				ProductsRowCurrent.SupplierID = Convert.ToInt32(ctlSupplierID.SelectedItem.Value);
			}
			
			// CategoryID
			
			
			if (ctlCategoryID.SelectedIndex == 0)
			{
				ProductsRowCurrent.SetCategoryIDNull();	
			}
			else
			{
				ProductsRowCurrent.CategoryID = Convert.ToInt32(ctlCategoryID.SelectedItem.Value);
			}
			
			// QuantityPerUnit
			if (ctlQuantityPerUnit.Text.Length == 0)
			{
				ProductsRowCurrent.SetQuantityPerUnitNull();
			}
			else
			{
				ProductsRowCurrent.QuantityPerUnit = ctlQuantityPerUnit.Text;
			}
						
			// UnitPrice
			if (ctlUnitPrice.Text.Length == 0)
			{
				ProductsRowCurrent.SetUnitPriceNull();
			}
			else
			{
				ProductsRowCurrent.UnitPrice = Convert.ToDecimal(ctlUnitPrice.Text);
			}
						
			// UnitsInStock
			if (ctlUnitsInStock.Text.Length == 0)
			{
				ProductsRowCurrent.SetUnitsInStockNull();
			}
			else
			{
				ProductsRowCurrent.UnitsInStock = Convert.ToInt16(ctlUnitsInStock.Text);
			}
						
			// UnitsOnOrder
			if (ctlUnitsOnOrder.Text.Length == 0)
			{
				ProductsRowCurrent.SetUnitsOnOrderNull();
			}
			else
			{
				ProductsRowCurrent.UnitsOnOrder = Convert.ToInt16(ctlUnitsOnOrder.Text);
			}
						
			// ReorderLevel
			if (ctlReorderLevel.Text.Length == 0)
			{
				ProductsRowCurrent.SetReorderLevelNull();
			}
			else
			{
				ProductsRowCurrent.ReorderLevel = Convert.ToInt16(ctlReorderLevel.Text);
			}
						
			// Discontinued
			ProductsRowCurrent.Discontinued = ctlDiscontinued.Checked;
			
			if (DataEntryMode == PageDataEntryMode.AddRow)
			{
				//
				// Add the new Row to the DataSet
				//
				ProductsDS.Products.Rows.Add(ProductsRowCurrent);
			}

			//
			// Save the changes to the database
			//
			ProductsLogic.UpdateDataSet(ProductsDS);
			
			//
			// Update the primary key values
			//
			m_ProductIDCurrent = ProductsRowCurrent.ProductID;
			
			
			return true;
		}
		
		
		#endregion

		
		#region Web Form Designer generated code
		
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.ValidationSummary ctlValidationSummary;
		protected System.Web.UI.WebControls.Button btnOK;
		protected System.Web.UI.WebControls.Button btnApply;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.Label ctlProductID;
		protected System.Web.UI.WebControls.TextBox ctlProductName;
		protected System.Web.UI.WebControls.DropDownList ctlSupplierID;
		protected System.Web.UI.WebControls.DropDownList ctlCategoryID;
		protected System.Web.UI.WebControls.TextBox ctlQuantityPerUnit;
		protected System.Web.UI.WebControls.TextBox ctlUnitPrice;
		protected System.Web.UI.WebControls.TextBox ctlUnitsInStock;
		protected System.Web.UI.WebControls.TextBox ctlUnitsOnOrder;
		protected System.Web.UI.WebControls.TextBox ctlReorderLevel;
		protected System.Web.UI.WebControls.CheckBox ctlDiscontinued;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			
		}
		
		#endregion
	}
}
