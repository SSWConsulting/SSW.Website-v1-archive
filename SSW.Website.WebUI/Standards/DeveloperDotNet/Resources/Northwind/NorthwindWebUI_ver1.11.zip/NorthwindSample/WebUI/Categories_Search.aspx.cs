using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the Categories table
	/// </summary>
	public class Categories_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("CategoryID", CategoryID);
			CriteriaCount += LoadSearchString("CategoryName", CategoryName);
			CriteriaCount += LoadSearchString("Description", Description);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "Categories Search";

				if (CriteriaCount > 0)
				{
					CategoriesGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void CategoriesGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(
						string.Format("Categories.aspx?{0}={1}", "CategoryID", CategoriesGrid.DataKeys[e.Item.ItemIndex].ToString())
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void CategoriesGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			CategoriesGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void CategoriesGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the Categories table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_CategoriesQuery = CommonFactory.CreateQuery();

			AddToQuery(m_CategoriesQuery, CategoriesTable.CategoryID, Comparison.EqualTo, CategoryID);
			AddToQuery(m_CategoriesQuery, CategoriesTable.CategoryName, Comparison.Contains, CategoryName);
			AddToQuery(m_CategoriesQuery, CategoriesTable.Description, Comparison.Contains, Description);
			

			AddSortToQuery(m_CategoriesQuery, typeof(CategoriesTable));
			
			ICategoriesService CategoriesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCategoriesService();
			int ResultCount = CategoriesLogic.GetByQuery(m_CategoriesDataSet, m_CategoriesQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				CategoriesGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.CategoriesDataSet m_CategoriesDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid CategoriesGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText CategoryID;
		protected System.Web.UI.HtmlControls.HtmlInputText CategoryName;
		protected System.Web.UI.HtmlControls.HtmlInputText Description;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_CategoriesDataSet = new NorthwindSample.Data.CategoriesDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_CategoriesDataSet)).BeginInit();
			this.CategoriesGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.CategoriesGrid_ItemCommand);
			this.CategoriesGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.CategoriesGrid_PageIndexChanged);
			this.CategoriesGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.CategoriesGrid_SortCommand);
			// 
			// m_CategoriesDataSet
			// 
			this.m_CategoriesDataSet.DataSetName = "CategoriesDataSet";
			this.m_CategoriesDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_CategoriesDataSet)).EndInit();

		}
		
		#endregion

	}
}
