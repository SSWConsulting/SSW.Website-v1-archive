using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the CustomerDemographics table
	/// </summary>
	public class CustomerDemographics_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("CustomerTypeID", CustomerTypeID);
			CriteriaCount += LoadSearchString("CustomerDesc", CustomerDesc);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "CustomerDemographics Search";

				if (CriteriaCount > 0)
				{
					CustomerDemographicsGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void CustomerDemographicsGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(
						string.Format("CustomerDemographics.aspx?{0}={1}", "CustomerTypeID", CustomerDemographicsGrid.DataKeys[e.Item.ItemIndex].ToString())
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void CustomerDemographicsGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			CustomerDemographicsGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void CustomerDemographicsGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the CustomerDemographics table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_CustomerDemographicsQuery = CommonFactory.CreateQuery();

			AddToQuery(m_CustomerDemographicsQuery, CustomerDemographicsTable.CustomerTypeID, Comparison.EqualTo, CustomerTypeID);
			AddToQuery(m_CustomerDemographicsQuery, CustomerDemographicsTable.CustomerDesc, Comparison.Contains, CustomerDesc);
			

			AddSortToQuery(m_CustomerDemographicsQuery, typeof(CustomerDemographicsTable));
			
			ICustomerDemographicsService CustomerDemographicsLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCustomerDemographicsService();
			int ResultCount = CustomerDemographicsLogic.GetByQuery(m_CustomerDemographicsDataSet, m_CustomerDemographicsQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				CustomerDemographicsGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.CustomerDemographicsDataSet m_CustomerDemographicsDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid CustomerDemographicsGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText CustomerTypeID;
		protected System.Web.UI.HtmlControls.HtmlInputText CustomerDesc;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_CustomerDemographicsDataSet = new NorthwindSample.Data.CustomerDemographicsDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_CustomerDemographicsDataSet)).BeginInit();
			this.CustomerDemographicsGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.CustomerDemographicsGrid_ItemCommand);
			this.CustomerDemographicsGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.CustomerDemographicsGrid_PageIndexChanged);
			this.CustomerDemographicsGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.CustomerDemographicsGrid_SortCommand);
			// 
			// m_CustomerDemographicsDataSet
			// 
			this.m_CustomerDemographicsDataSet.DataSetName = "CustomerDemographicsDataSet";
			this.m_CustomerDemographicsDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_CustomerDemographicsDataSet)).EndInit();

		}
		
		#endregion

	}
}
