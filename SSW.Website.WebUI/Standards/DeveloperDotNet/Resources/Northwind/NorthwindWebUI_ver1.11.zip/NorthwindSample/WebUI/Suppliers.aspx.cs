using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Code-behind file for the Suppliers.aspx Page
	/// </summary>
	public class Suppliers : EditablePage
	{
		#region Constants


		#endregion


		#region Fields

		private Int32 m_SupplierIDCurrent;
		

		#endregion

				
		#region Page Events

		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			//
			// Find primary key values to use to populate the form
			//
			if (HasQueryStringParameter("SupplierID"))
			{
				m_SupplierIDCurrent = Convert.ToInt32(Request.QueryString["SupplierID"]);
				
				DataEntryMode = PageDataEntryMode.EditRow;

				PageTitle = string.Format("Suppliers - Editing {0}: {1}", "SupplierID", m_SupplierIDCurrent);
			}
			else
			{
				DataEntryMode = PageDataEntryMode.AddRow;

				PageTitle = "Suppliers - Adding a new entry";
				lblMessage.Text = "Adding a new entry";
			}

			if (Page.IsPostBack)
			{
			
			}
			else
			{
				//
				// Initial Page Request
				//
				PopulateControls();

				if (DataEntryMode == PageDataEntryMode.EditRow || DataEntryMode == PageDataEntryMode.ViewRow)
				{
					if (!LoadData())
					{
						//
						// Could not load the row from the database
						//
						lblMessage.Text = "Error loading Suppliers";

						DataEntryMode = PageDataEntryMode.ErrorOccurred;
						
						DisableDataEntryControls(this.Controls);
					}
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Apply the changes and return to the previous screen
		/// </summary>
		private void btnOK_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				Response.Redirect(UrlPrevious.ToString());
			}
		}


		/// <summary>
		/// Apply the changes and remain on this page
		/// </summary>
		private void btnApply_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				//
				// Redirect back to this page in Edit mode
				//
				if (DataEntryMode == PageDataEntryMode.AddRow)
				{	
					UriBuilder EditUri = new UriBuilder(Request.Url);
					EditUri.Query += string.Format("{0}={1}", "SupplierID", m_SupplierIDCurrent);

					//
					// Redirect back to this page 
					// with the primary key information in the query string
					//
					Response.Redirect(EditUri.ToString());
							
				}
				else
				{
					lblMessage.Text = "Suppliers saved";

					LoadData();
				}
			}
			else
			{
				lblMessage.Text = "Error saving Suppliers";
				DataEntryMode = PageDataEntryMode.ErrorOccurred;
			}
		}
		
		
		/// <summary>
		/// return to the previous screen
		/// </summary>
		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(UrlPrevious.ToString());
		}
		
		#endregion


		#region Private Methods
		
		/// <summary>
		/// Loads data from the database for drop down lists
		/// </summary>
		private void PopulateControls()
		{
			
		}
		
		/// <summary>
		/// Loads a row from the Suppliers table for viewing or editing
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool LoadData()
		{
			if ((DataEntryMode != PageDataEntryMode.EditRow) && (DataEntryMode != PageDataEntryMode.ViewRow))
			{
				return true;
			}
			
			SuppliersDataSet SuppliersDS = new SuppliersDataSet();
			ISuppliersService SuppliersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateSuppliersService();
			
			if (SuppliersLogic.GetBySupplierID(SuppliersDS, m_SupplierIDCurrent) == 0)
			{
				//
				// Suppliers Row not found
				//
				return false;
			}

			SuppliersDataSet.SuppliersRow SuppliersRowCurrent = SuppliersDS.Suppliers[0];
			ListItem SelectedListItem;
			
			//
			// Populate the Page controls from the DataRow
			//
			ctlSupplierID.Text = SuppliersRowCurrent.SupplierID.ToString();
			ctlCompanyName.Text = SuppliersRowCurrent.CompanyName;
			ctlContactName.Text = (SuppliersRowCurrent.IsContactNameNull()) ? string.Empty : SuppliersRowCurrent.ContactName;
			ctlContactTitle.Text = (SuppliersRowCurrent.IsContactTitleNull()) ? string.Empty : SuppliersRowCurrent.ContactTitle;
			ctlAddress.Text = (SuppliersRowCurrent.IsAddressNull()) ? string.Empty : SuppliersRowCurrent.Address;
			ctlCity.Text = (SuppliersRowCurrent.IsCityNull()) ? string.Empty : SuppliersRowCurrent.City;
			ctlRegion.Text = (SuppliersRowCurrent.IsRegionNull()) ? string.Empty : SuppliersRowCurrent.Region;
			ctlPostalCode.Text = (SuppliersRowCurrent.IsPostalCodeNull()) ? string.Empty : SuppliersRowCurrent.PostalCode;
			ctlCountry.Text = (SuppliersRowCurrent.IsCountryNull()) ? string.Empty : SuppliersRowCurrent.Country;
			ctlPhone.Text = (SuppliersRowCurrent.IsPhoneNull()) ? string.Empty : SuppliersRowCurrent.Phone;
			ctlFax.Text = (SuppliersRowCurrent.IsFaxNull()) ? string.Empty : SuppliersRowCurrent.Fax;
			ctlHomePage.Text = (SuppliersRowCurrent.IsHomePageNull()) ? string.Empty : SuppliersRowCurrent.HomePage;
			
			
			return true;
		}
		
		
		/// <summary>
		/// Adds or updates the row in the Database
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool SaveData()
		{
			//
			// Check that the Form has passed validation
			//
			Page.Validate();
			
			if (!Page.IsValid)
			{
				// Validation failed
				return false;
			}
			
			SuppliersDataSet SuppliersDS = new SuppliersDataSet();
			ISuppliersService SuppliersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateSuppliersService();
			SuppliersDataSet.SuppliersRow SuppliersRowCurrent;
			
			
			switch (DataEntryMode)
			{
				case PageDataEntryMode.AddRow:
					//
					// Create a New Row
					//
					SuppliersRowCurrent = SuppliersDS.Suppliers.NewSuppliersRow();
					break;
					
				case PageDataEntryMode.EditRow:
					//
					// Update existing Row
					//
					if (SuppliersLogic.GetBySupplierID(SuppliersDS, m_SupplierIDCurrent) == 0)
					{
						//
						// Suppliers Row not found
						//
						return false;
					}
					else
					{
						SuppliersRowCurrent = SuppliersDS.Suppliers[0];
					}
					break;
					
				default:
					return false;
			}

			//
			// Set the DataRow values from the Page Controls
			//
			
			// CompanyName
			SuppliersRowCurrent.CompanyName = ctlCompanyName.Text;
			// ContactName
			if (ctlContactName.Text.Length == 0)
			{
				SuppliersRowCurrent.SetContactNameNull();
			}
			else
			{
				SuppliersRowCurrent.ContactName = ctlContactName.Text;
			}
						
			// ContactTitle
			if (ctlContactTitle.Text.Length == 0)
			{
				SuppliersRowCurrent.SetContactTitleNull();
			}
			else
			{
				SuppliersRowCurrent.ContactTitle = ctlContactTitle.Text;
			}
						
			// Address
			if (ctlAddress.Text.Length == 0)
			{
				SuppliersRowCurrent.SetAddressNull();
			}
			else
			{
				SuppliersRowCurrent.Address = ctlAddress.Text;
			}
						
			// City
			if (ctlCity.Text.Length == 0)
			{
				SuppliersRowCurrent.SetCityNull();
			}
			else
			{
				SuppliersRowCurrent.City = ctlCity.Text;
			}
						
			// Region
			if (ctlRegion.Text.Length == 0)
			{
				SuppliersRowCurrent.SetRegionNull();
			}
			else
			{
				SuppliersRowCurrent.Region = ctlRegion.Text;
			}
						
			// PostalCode
			if (ctlPostalCode.Text.Length == 0)
			{
				SuppliersRowCurrent.SetPostalCodeNull();
			}
			else
			{
				SuppliersRowCurrent.PostalCode = ctlPostalCode.Text;
			}
						
			// Country
			if (ctlCountry.Text.Length == 0)
			{
				SuppliersRowCurrent.SetCountryNull();
			}
			else
			{
				SuppliersRowCurrent.Country = ctlCountry.Text;
			}
						
			// Phone
			if (ctlPhone.Text.Length == 0)
			{
				SuppliersRowCurrent.SetPhoneNull();
			}
			else
			{
				SuppliersRowCurrent.Phone = ctlPhone.Text;
			}
						
			// Fax
			if (ctlFax.Text.Length == 0)
			{
				SuppliersRowCurrent.SetFaxNull();
			}
			else
			{
				SuppliersRowCurrent.Fax = ctlFax.Text;
			}
						
			// HomePage
			if (ctlHomePage.Text.Length == 0)
			{
				SuppliersRowCurrent.SetHomePageNull();
			}
			else
			{
				SuppliersRowCurrent.HomePage = ctlHomePage.Text;
			}
						
			
			if (DataEntryMode == PageDataEntryMode.AddRow)
			{
				//
				// Add the new Row to the DataSet
				//
				SuppliersDS.Suppliers.Rows.Add(SuppliersRowCurrent);
			}

			//
			// Save the changes to the database
			//
			SuppliersLogic.UpdateDataSet(SuppliersDS);
			
			//
			// Update the primary key values
			//
			m_SupplierIDCurrent = SuppliersRowCurrent.SupplierID;
			
			
			return true;
		}
		
		
		#endregion

		
		#region Web Form Designer generated code
		
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.ValidationSummary ctlValidationSummary;
		protected System.Web.UI.WebControls.Button btnOK;
		protected System.Web.UI.WebControls.Button btnApply;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.Label ctlSupplierID;
		protected System.Web.UI.WebControls.TextBox ctlCompanyName;
		protected System.Web.UI.WebControls.TextBox ctlContactName;
		protected System.Web.UI.WebControls.TextBox ctlContactTitle;
		protected System.Web.UI.WebControls.TextBox ctlAddress;
		protected System.Web.UI.WebControls.TextBox ctlCity;
		protected System.Web.UI.WebControls.TextBox ctlRegion;
		protected System.Web.UI.WebControls.TextBox ctlPostalCode;
		protected System.Web.UI.WebControls.TextBox ctlCountry;
		protected System.Web.UI.WebControls.TextBox ctlPhone;
		protected System.Web.UI.WebControls.TextBox ctlFax;
		protected System.Web.UI.WebControls.TextBox ctlHomePage;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			
		}
		
		#endregion
	}
}
