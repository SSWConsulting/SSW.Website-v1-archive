using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the Employees table
	/// </summary>
	public class Employees_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("EmployeeID", EmployeeID);
			CriteriaCount += LoadSearchString("LastName", LastName);
			CriteriaCount += LoadSearchString("FirstName", FirstName);
			CriteriaCount += LoadSearchString("Title", Title);
			CriteriaCount += LoadSearchString("TitleOfCourtesy", TitleOfCourtesy);
			CriteriaCount += LoadSearchBetween("BirthDate", BirthDateBegin, BirthDateEnd);
			CriteriaCount += LoadSearchBetween("HireDate", HireDateBegin, HireDateEnd);
			CriteriaCount += LoadSearchString("Address", Address);
			CriteriaCount += LoadSearchString("City", City);
			CriteriaCount += LoadSearchString("Region", Region);
			CriteriaCount += LoadSearchString("PostalCode", PostalCode);
			CriteriaCount += LoadSearchString("Country", Country);
			CriteriaCount += LoadSearchString("HomePhone", HomePhone);
			CriteriaCount += LoadSearchString("Extension", Extension);
			CriteriaCount += LoadSearchString("Notes", Notes);
			CriteriaCount += LoadSearchBetween("ReportsTo", ReportsToBegin, ReportsToEnd);
			CriteriaCount += LoadSearchString("PhotoPath", PhotoPath);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "Employees Search";

				if (CriteriaCount > 0)
				{
					EmployeesGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void EmployeesGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(
						string.Format("Employees.aspx?{0}={1}", "EmployeeID", EmployeesGrid.DataKeys[e.Item.ItemIndex].ToString())
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void EmployeesGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			EmployeesGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void EmployeesGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the Employees table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_EmployeesQuery = CommonFactory.CreateQuery();

			AddToQuery(m_EmployeesQuery, EmployeesTable.EmployeeID, Comparison.EqualTo, EmployeeID);
			AddToQuery(m_EmployeesQuery, EmployeesTable.LastName, Comparison.Contains, LastName);
			AddToQuery(m_EmployeesQuery, EmployeesTable.FirstName, Comparison.Contains, FirstName);
			AddToQuery(m_EmployeesQuery, EmployeesTable.Title, Comparison.Contains, Title);
			AddToQuery(m_EmployeesQuery, EmployeesTable.TitleOfCourtesy, Comparison.Contains, TitleOfCourtesy);
			AddToQuery(m_EmployeesQuery, EmployeesTable.BirthDate, BirthDateBegin, BirthDateEnd);
			AddToQuery(m_EmployeesQuery, EmployeesTable.HireDate, HireDateBegin, HireDateEnd);
			AddToQuery(m_EmployeesQuery, EmployeesTable.Address, Comparison.Contains, Address);
			AddToQuery(m_EmployeesQuery, EmployeesTable.City, Comparison.Contains, City);
			AddToQuery(m_EmployeesQuery, EmployeesTable.Region, Comparison.Contains, Region);
			AddToQuery(m_EmployeesQuery, EmployeesTable.PostalCode, Comparison.Contains, PostalCode);
			AddToQuery(m_EmployeesQuery, EmployeesTable.Country, Comparison.Contains, Country);
			AddToQuery(m_EmployeesQuery, EmployeesTable.HomePhone, Comparison.Contains, HomePhone);
			AddToQuery(m_EmployeesQuery, EmployeesTable.Extension, Comparison.Contains, Extension);
			AddToQuery(m_EmployeesQuery, EmployeesTable.Notes, Comparison.Contains, Notes);
			AddToQuery(m_EmployeesQuery, EmployeesTable.ReportsTo, ReportsToBegin, ReportsToEnd);
			AddToQuery(m_EmployeesQuery, EmployeesTable.PhotoPath, Comparison.Contains, PhotoPath);
			

			AddSortToQuery(m_EmployeesQuery, typeof(EmployeesTable));
			
			IEmployeesService EmployeesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateEmployeesService();
			int ResultCount = EmployeesLogic.GetByQuery(m_EmployeesDataSet, m_EmployeesQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				EmployeesGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.EmployeesDataSet m_EmployeesDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid EmployeesGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText EmployeeID;
		protected System.Web.UI.HtmlControls.HtmlInputText LastName;
		protected System.Web.UI.HtmlControls.HtmlInputText FirstName;
		protected System.Web.UI.HtmlControls.HtmlInputText Title;
		protected System.Web.UI.HtmlControls.HtmlInputText TitleOfCourtesy;
		protected System.Web.UI.HtmlControls.HtmlInputText BirthDateBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText BirthDateEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText HireDateBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText HireDateEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText Address;
		protected System.Web.UI.HtmlControls.HtmlInputText City;
		protected System.Web.UI.HtmlControls.HtmlInputText Region;
		protected System.Web.UI.HtmlControls.HtmlInputText PostalCode;
		protected System.Web.UI.HtmlControls.HtmlInputText Country;
		protected System.Web.UI.HtmlControls.HtmlInputText HomePhone;
		protected System.Web.UI.HtmlControls.HtmlInputText Extension;
		protected System.Web.UI.HtmlControls.HtmlInputText Notes;
		protected System.Web.UI.HtmlControls.HtmlInputText ReportsToBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText ReportsToEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText PhotoPath;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_EmployeesDataSet = new NorthwindSample.Data.EmployeesDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_EmployeesDataSet)).BeginInit();
			this.EmployeesGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.EmployeesGrid_ItemCommand);
			this.EmployeesGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.EmployeesGrid_PageIndexChanged);
			this.EmployeesGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.EmployeesGrid_SortCommand);
			// 
			// m_EmployeesDataSet
			// 
			this.m_EmployeesDataSet.DataSetName = "EmployeesDataSet";
			this.m_EmployeesDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_EmployeesDataSet)).EndInit();

		}
		
		#endregion

	}
}
