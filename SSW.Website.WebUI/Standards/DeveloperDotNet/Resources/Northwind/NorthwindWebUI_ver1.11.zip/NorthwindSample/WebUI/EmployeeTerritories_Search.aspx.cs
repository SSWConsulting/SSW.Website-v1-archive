using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the EmployeeTerritories table
	/// </summary>
	public class EmployeeTerritories_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("EmployeeID", EmployeeID);
			CriteriaCount += LoadSearchString("TerritoryID", TerritoryID);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "EmployeeTerritories Search";

				if (CriteriaCount > 0)
				{
					EmployeeTerritoriesGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void EmployeeTerritoriesGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(string.Format(
						"EmployeeTerritories.aspx?{0}={1}&{2}={3}", 
						"EmployeeID", e.Item.Cells[1].Text, 
						"TerritoryID", e.Item.Cells[2].Text)
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void EmployeeTerritoriesGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			EmployeeTerritoriesGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void EmployeeTerritoriesGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the EmployeeTerritories table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_EmployeeTerritoriesQuery = CommonFactory.CreateQuery();

			AddToQuery(m_EmployeeTerritoriesQuery, EmployeeTerritoriesTable.EmployeeID, Comparison.EqualTo, EmployeeID);
			AddToQuery(m_EmployeeTerritoriesQuery, EmployeeTerritoriesTable.TerritoryID, Comparison.EqualTo, TerritoryID);
			

			AddSortToQuery(m_EmployeeTerritoriesQuery, typeof(EmployeeTerritoriesTable));
			
			IEmployeeTerritoriesService EmployeeTerritoriesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateEmployeeTerritoriesService();
			int ResultCount = EmployeeTerritoriesLogic.GetByQuery(m_EmployeeTerritoriesDataSet, m_EmployeeTerritoriesQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				EmployeeTerritoriesGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.EmployeeTerritoriesDataSet m_EmployeeTerritoriesDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid EmployeeTerritoriesGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText EmployeeID;
		protected System.Web.UI.HtmlControls.HtmlInputText TerritoryID;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_EmployeeTerritoriesDataSet = new NorthwindSample.Data.EmployeeTerritoriesDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_EmployeeTerritoriesDataSet)).BeginInit();
			this.EmployeeTerritoriesGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.EmployeeTerritoriesGrid_ItemCommand);
			this.EmployeeTerritoriesGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.EmployeeTerritoriesGrid_PageIndexChanged);
			this.EmployeeTerritoriesGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.EmployeeTerritoriesGrid_SortCommand);
			// 
			// m_EmployeeTerritoriesDataSet
			// 
			this.m_EmployeeTerritoriesDataSet.DataSetName = "EmployeeTerritoriesDataSet";
			this.m_EmployeeTerritoriesDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_EmployeeTerritoriesDataSet)).EndInit();

		}
		
		#endregion

	}
}
