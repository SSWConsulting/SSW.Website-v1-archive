using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the Products table
	/// </summary>
	public class Products_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("ProductID", ProductID);
			CriteriaCount += LoadSearchString("ProductName", ProductName);
			CriteriaCount += LoadSearchString("SupplierID", SupplierID);
			CriteriaCount += LoadSearchString("CategoryID", CategoryID);
			CriteriaCount += LoadSearchString("QuantityPerUnit", QuantityPerUnit);
			CriteriaCount += LoadSearchBetween("UnitPrice", UnitPriceBegin, UnitPriceEnd);
			CriteriaCount += LoadSearchBetween("UnitsInStock", UnitsInStockBegin, UnitsInStockEnd);
			CriteriaCount += LoadSearchBetween("UnitsOnOrder", UnitsOnOrderBegin, UnitsOnOrderEnd);
			CriteriaCount += LoadSearchBetween("ReorderLevel", ReorderLevelBegin, ReorderLevelEnd);
			CriteriaCount += LoadSearchBoolean("Discontinued", Discontinued);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "Products Search";

				if (CriteriaCount > 0)
				{
					ProductsGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void ProductsGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(
						string.Format("Products.aspx?{0}={1}", "ProductID", ProductsGrid.DataKeys[e.Item.ItemIndex].ToString())
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void ProductsGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			ProductsGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void ProductsGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the Products table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_ProductsQuery = CommonFactory.CreateQuery();

			AddToQuery(m_ProductsQuery, ProductsTable.ProductID, Comparison.EqualTo, ProductID);
			AddToQuery(m_ProductsQuery, ProductsTable.ProductName, Comparison.Contains, ProductName);
			AddToQuery(m_ProductsQuery, ProductsTable.SupplierID, Comparison.EqualTo, SupplierID);
			AddToQuery(m_ProductsQuery, ProductsTable.CategoryID, Comparison.EqualTo, CategoryID);
			AddToQuery(m_ProductsQuery, ProductsTable.QuantityPerUnit, Comparison.Contains, QuantityPerUnit);
			AddToQuery(m_ProductsQuery, ProductsTable.UnitPrice, UnitPriceBegin, UnitPriceEnd);
			AddToQuery(m_ProductsQuery, ProductsTable.UnitsInStock, UnitsInStockBegin, UnitsInStockEnd);
			AddToQuery(m_ProductsQuery, ProductsTable.UnitsOnOrder, UnitsOnOrderBegin, UnitsOnOrderEnd);
			AddToQuery(m_ProductsQuery, ProductsTable.ReorderLevel, ReorderLevelBegin, ReorderLevelEnd);
			AddToQuery(m_ProductsQuery, ProductsTable.Discontinued, Comparison.EqualTo, Discontinued);
			

			AddSortToQuery(m_ProductsQuery, typeof(ProductsTable));
			
			IProductsService ProductsLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateProductsService();
			int ResultCount = ProductsLogic.GetByQuery(m_ProductsDataSet, m_ProductsQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				ProductsGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.ProductsDataSet m_ProductsDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid ProductsGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText ProductID;
		protected System.Web.UI.HtmlControls.HtmlInputText ProductName;
		protected System.Web.UI.HtmlControls.HtmlInputText SupplierID;
		protected System.Web.UI.HtmlControls.HtmlInputText CategoryID;
		protected System.Web.UI.HtmlControls.HtmlInputText QuantityPerUnit;
		protected System.Web.UI.HtmlControls.HtmlInputText UnitPriceBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText UnitPriceEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText UnitsInStockBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText UnitsInStockEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText UnitsOnOrderBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText UnitsOnOrderEnd;
		protected System.Web.UI.HtmlControls.HtmlInputText ReorderLevelBegin;
		protected System.Web.UI.HtmlControls.HtmlInputText ReorderLevelEnd;
		protected System.Web.UI.HtmlControls.HtmlSelect Discontinued;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_ProductsDataSet = new NorthwindSample.Data.ProductsDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_ProductsDataSet)).BeginInit();
			this.ProductsGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.ProductsGrid_ItemCommand);
			this.ProductsGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.ProductsGrid_PageIndexChanged);
			this.ProductsGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.ProductsGrid_SortCommand);
			// 
			// m_ProductsDataSet
			// 
			this.m_ProductsDataSet.DataSetName = "ProductsDataSet";
			this.m_ProductsDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_ProductsDataSet)).EndInit();

		}
		
		#endregion

	}
}
