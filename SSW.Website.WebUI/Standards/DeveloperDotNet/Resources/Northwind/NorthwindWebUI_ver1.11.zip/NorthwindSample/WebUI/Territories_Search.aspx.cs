using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the Territories table
	/// </summary>
	public class Territories_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("TerritoryID", TerritoryID);
			CriteriaCount += LoadSearchString("TerritoryDescription", TerritoryDescription);
			CriteriaCount += LoadSearchString("RegionID", RegionID);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "Territories Search";

				if (CriteriaCount > 0)
				{
					TerritoriesGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void TerritoriesGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(
						string.Format("Territories.aspx?{0}={1}", "TerritoryID", TerritoriesGrid.DataKeys[e.Item.ItemIndex].ToString())
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void TerritoriesGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			TerritoriesGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void TerritoriesGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the Territories table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_TerritoriesQuery = CommonFactory.CreateQuery();

			AddToQuery(m_TerritoriesQuery, TerritoriesTable.TerritoryID, Comparison.EqualTo, TerritoryID);
			AddToQuery(m_TerritoriesQuery, TerritoriesTable.TerritoryDescription, Comparison.Contains, TerritoryDescription);
			AddToQuery(m_TerritoriesQuery, TerritoriesTable.RegionID, Comparison.EqualTo, RegionID);
			

			AddSortToQuery(m_TerritoriesQuery, typeof(TerritoriesTable));
			
			ITerritoriesService TerritoriesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateTerritoriesService();
			int ResultCount = TerritoriesLogic.GetByQuery(m_TerritoriesDataSet, m_TerritoriesQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				TerritoriesGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.TerritoriesDataSet m_TerritoriesDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid TerritoriesGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText TerritoryID;
		protected System.Web.UI.HtmlControls.HtmlInputText TerritoryDescription;
		protected System.Web.UI.HtmlControls.HtmlInputText RegionID;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_TerritoriesDataSet = new NorthwindSample.Data.TerritoriesDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_TerritoriesDataSet)).BeginInit();
			this.TerritoriesGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.TerritoriesGrid_ItemCommand);
			this.TerritoriesGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.TerritoriesGrid_PageIndexChanged);
			this.TerritoriesGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.TerritoriesGrid_SortCommand);
			// 
			// m_TerritoriesDataSet
			// 
			this.m_TerritoriesDataSet.DataSetName = "TerritoriesDataSet";
			this.m_TerritoriesDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_TerritoriesDataSet)).EndInit();

		}
		
		#endregion

	}
}
