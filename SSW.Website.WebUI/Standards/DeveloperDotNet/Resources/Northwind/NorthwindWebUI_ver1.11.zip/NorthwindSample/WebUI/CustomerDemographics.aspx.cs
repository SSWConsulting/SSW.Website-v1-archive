using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Code-behind file for the CustomerDemographics.aspx Page
	/// </summary>
	public class CustomerDemographics : EditablePage
	{
		#region Constants


		#endregion


		#region Fields

		private String m_CustomerTypeIDCurrent;
		

		#endregion

				
		#region Page Events

		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			//
			// Find primary key values to use to populate the form
			//
			if (HasQueryStringParameter("CustomerTypeID"))
			{
				m_CustomerTypeIDCurrent = Convert.ToString(Request.QueryString["CustomerTypeID"]);
				
				DataEntryMode = PageDataEntryMode.EditRow;

				PageTitle = string.Format("Customer Demographics - Editing {0}: {1}", "CustomerTypeID", m_CustomerTypeIDCurrent);
			}
			else
			{
				DataEntryMode = PageDataEntryMode.AddRow;

				PageTitle = "Customer Demographics - Adding a new entry";
				lblMessage.Text = "Adding a new entry";
			}

			if (Page.IsPostBack)
			{
			
			}
			else
			{
				//
				// Initial Page Request
				//
				PopulateControls();

				if (DataEntryMode == PageDataEntryMode.EditRow || DataEntryMode == PageDataEntryMode.ViewRow)
				{
					if (!LoadData())
					{
						//
						// Could not load the row from the database
						//
						lblMessage.Text = "Error loading CustomerDemographics";

						DataEntryMode = PageDataEntryMode.ErrorOccurred;
						
						DisableDataEntryControls(this.Controls);
					}
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Apply the changes and return to the previous screen
		/// </summary>
		private void btnOK_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				Response.Redirect(UrlPrevious.ToString());
			}
		}


		/// <summary>
		/// Apply the changes and remain on this page
		/// </summary>
		private void btnApply_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				//
				// Redirect back to this page in Edit mode
				//
				if (DataEntryMode == PageDataEntryMode.AddRow)
				{	
					UriBuilder EditUri = new UriBuilder(Request.Url);
					EditUri.Query += string.Format("{0}={1}", "CustomerTypeID", m_CustomerTypeIDCurrent);

					//
					// Redirect back to this page 
					// with the primary key information in the query string
					//
					Response.Redirect(EditUri.ToString());
							
				}
				else
				{
					lblMessage.Text = "Customer Demographics saved";

					LoadData();
				}
			}
			else
			{
				lblMessage.Text = "Error saving Customer Demographics";
				DataEntryMode = PageDataEntryMode.ErrorOccurred;
			}
		}
		
		
		/// <summary>
		/// return to the previous screen
		/// </summary>
		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(UrlPrevious.ToString());
		}
		
		#endregion


		#region Private Methods
		
		/// <summary>
		/// Loads data from the database for drop down lists
		/// </summary>
		private void PopulateControls()
		{
			
		}
		
		/// <summary>
		/// Loads a row from the CustomerDemographics table for viewing or editing
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool LoadData()
		{
			if ((DataEntryMode != PageDataEntryMode.EditRow) && (DataEntryMode != PageDataEntryMode.ViewRow))
			{
				return true;
			}
			
			CustomerDemographicsDataSet CustomerDemographicsDS = new CustomerDemographicsDataSet();
			ICustomerDemographicsService CustomerDemographicsLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCustomerDemographicsService();
			
			if (CustomerDemographicsLogic.GetByCustomerTypeID(CustomerDemographicsDS, m_CustomerTypeIDCurrent) == 0)
			{
				//
				// CustomerDemographics Row not found
				//
				return false;
			}

			CustomerDemographicsDataSet.CustomerDemographicsRow CustomerDemographicsRowCurrent = CustomerDemographicsDS.CustomerDemographics[0];
			ListItem SelectedListItem;
			
			//
			// Populate the Page controls from the DataRow
			//
			ctlCustomerTypeID.Text = CustomerDemographicsRowCurrent.CustomerTypeID;
			ctlCustomerDesc.Text = (CustomerDemographicsRowCurrent.IsCustomerDescNull()) ? string.Empty : CustomerDemographicsRowCurrent.CustomerDesc;
			
			
			return true;
		}
		
		
		/// <summary>
		/// Adds or updates the row in the Database
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool SaveData()
		{
			//
			// Check that the Form has passed validation
			//
			Page.Validate();
			
			if (!Page.IsValid)
			{
				// Validation failed
				return false;
			}
			
			CustomerDemographicsDataSet CustomerDemographicsDS = new CustomerDemographicsDataSet();
			ICustomerDemographicsService CustomerDemographicsLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCustomerDemographicsService();
			CustomerDemographicsDataSet.CustomerDemographicsRow CustomerDemographicsRowCurrent;
			
			
			switch (DataEntryMode)
			{
				case PageDataEntryMode.AddRow:
					//
					// Create a New Row
					//
					CustomerDemographicsRowCurrent = CustomerDemographicsDS.CustomerDemographics.NewCustomerDemographicsRow();
					break;
					
				case PageDataEntryMode.EditRow:
					//
					// Update existing Row
					//
					if (CustomerDemographicsLogic.GetByCustomerTypeID(CustomerDemographicsDS, m_CustomerTypeIDCurrent) == 0)
					{
						//
						// CustomerDemographics Row not found
						//
						return false;
					}
					else
					{
						CustomerDemographicsRowCurrent = CustomerDemographicsDS.CustomerDemographics[0];
					}
					break;
					
				default:
					return false;
			}

			//
			// Set the DataRow values from the Page Controls
			//
			
			// CustomerTypeID
			CustomerDemographicsRowCurrent.CustomerTypeID = ctlCustomerTypeID.Text;
			// CustomerDesc
			if (ctlCustomerDesc.Text.Length == 0)
			{
				CustomerDemographicsRowCurrent.SetCustomerDescNull();
			}
			else
			{
				CustomerDemographicsRowCurrent.CustomerDesc = ctlCustomerDesc.Text;
			}
						
			
			if (DataEntryMode == PageDataEntryMode.AddRow)
			{
				//
				// Add the new Row to the DataSet
				//
				CustomerDemographicsDS.CustomerDemographics.Rows.Add(CustomerDemographicsRowCurrent);
			}

			//
			// Save the changes to the database
			//
			CustomerDemographicsLogic.UpdateDataSet(CustomerDemographicsDS);
			
			//
			// Update the primary key values
			//
			m_CustomerTypeIDCurrent = CustomerDemographicsRowCurrent.CustomerTypeID;
			
			
			return true;
		}
		
		
		#endregion

		
		#region Web Form Designer generated code
		
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.ValidationSummary ctlValidationSummary;
		protected System.Web.UI.WebControls.Button btnOK;
		protected System.Web.UI.WebControls.Button btnApply;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.TextBox ctlCustomerTypeID;
		protected System.Web.UI.WebControls.TextBox ctlCustomerDesc;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			
		}
		
		#endregion
	}
}
