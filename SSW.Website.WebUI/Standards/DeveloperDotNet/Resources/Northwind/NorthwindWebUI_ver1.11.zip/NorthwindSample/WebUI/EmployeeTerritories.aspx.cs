using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Code-behind file for the EmployeeTerritories.aspx Page
	/// </summary>
	public class EmployeeTerritories : EditablePage
	{
		#region Constants


		#endregion


		#region Fields

		private Int32 m_EmployeeIDCurrent;
		private String m_TerritoryIDCurrent;
		

		#endregion

				
		#region Page Events

		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			//
			// Find primary key values to use to populate the form
			//
			if (HasQueryStringParameter("EmployeeID") && HasQueryStringParameter("TerritoryID"))
			{
				m_EmployeeIDCurrent = Convert.ToInt32(Request.QueryString["EmployeeID"]);
				m_TerritoryIDCurrent = Convert.ToString(Request.QueryString["TerritoryID"]);
				
				DataEntryMode = PageDataEntryMode.EditRow;

				PageTitle = string.Format("Employee Territories - Editing {0}: {1}, {2}: {3}", "EmployeeID", m_EmployeeIDCurrent, "TerritoryID", m_TerritoryIDCurrent);
			}
			else
			{
				DataEntryMode = PageDataEntryMode.AddRow;

				PageTitle = "Employee Territories - Adding a new entry";
				lblMessage.Text = "Adding a new entry";
			}

			if (Page.IsPostBack)
			{
			
			}
			else
			{
				//
				// Initial Page Request
				//
				PopulateControls();

				if (DataEntryMode == PageDataEntryMode.EditRow || DataEntryMode == PageDataEntryMode.ViewRow)
				{
					if (!LoadData())
					{
						//
						// Could not load the row from the database
						//
						lblMessage.Text = "Error loading EmployeeTerritories";

						DataEntryMode = PageDataEntryMode.ErrorOccurred;
						
						DisableDataEntryControls(this.Controls);
					}
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Apply the changes and return to the previous screen
		/// </summary>
		private void btnOK_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				Response.Redirect(UrlPrevious.ToString());
			}
		}


		/// <summary>
		/// Apply the changes and remain on this page
		/// </summary>
		private void btnApply_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				//
				// Redirect back to this page in Edit mode
				//
				if (DataEntryMode == PageDataEntryMode.AddRow)
				{	
					UriBuilder EditUri = new UriBuilder(Request.Url);
					EditUri.Query += string.Format("{0}={1}&{2}={3}", "EmployeeID", m_EmployeeIDCurrent, "TerritoryID", m_TerritoryIDCurrent);

					//
					// Redirect back to this page 
					// with the primary key information in the query string
					//
					Response.Redirect(EditUri.ToString());
							
				}
				else
				{
					lblMessage.Text = "Employee Territories saved";

					LoadData();
				}
			}
			else
			{
				lblMessage.Text = "Error saving Employee Territories";
				DataEntryMode = PageDataEntryMode.ErrorOccurred;
			}
		}
		
		
		/// <summary>
		/// return to the previous screen
		/// </summary>
		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(UrlPrevious.ToString());
		}
		
		#endregion


		#region Private Methods
		
		/// <summary>
		/// Loads data from the database for drop down lists
		/// </summary>
		private void PopulateControls()
		{
			
			//
			// Populate the EmployeeID Drop Down List
			//
			EmployeesDataSet EmployeesDS = new EmployeesDataSet();
			IEmployeesService EmployeesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateEmployeesService();
			
			if (EmployeesLogic.GetAll(EmployeesDS) > 0)
			{
				ListItem EmployeesListItemNew;
				foreach (EmployeesDataSet.EmployeesRow EmployeesCurrent in EmployeesDS.Employees.Rows)
				{
					EmployeesListItemNew = new ListItem();
					EmployeesListItemNew.Value = EmployeesCurrent.EmployeeID.ToString();
					EmployeesListItemNew.Text = EmployeesCurrent.EmployeeID.ToString();

					ctlEmployeeID.Items.Add(EmployeesListItemNew);
				}
			}
			
			//
			// Populate the TerritoryID Drop Down List
			//
			TerritoriesDataSet TerritoriesDS = new TerritoriesDataSet();
			ITerritoriesService TerritoriesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateTerritoriesService();
			
			if (TerritoriesLogic.GetAll(TerritoriesDS) > 0)
			{
				ListItem TerritoriesListItemNew;
				foreach (TerritoriesDataSet.TerritoriesRow TerritoriesCurrent in TerritoriesDS.Territories.Rows)
				{
					TerritoriesListItemNew = new ListItem();
					TerritoriesListItemNew.Value = TerritoriesCurrent.TerritoryID.ToString();
					TerritoriesListItemNew.Text = TerritoriesCurrent.TerritoryID.ToString();

					ctlTerritoryID.Items.Add(TerritoriesListItemNew);
				}
			}
			
		}
		
		/// <summary>
		/// Loads a row from the EmployeeTerritories table for viewing or editing
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool LoadData()
		{
			if ((DataEntryMode != PageDataEntryMode.EditRow) && (DataEntryMode != PageDataEntryMode.ViewRow))
			{
				return true;
			}
			
			EmployeeTerritoriesDataSet EmployeeTerritoriesDS = new EmployeeTerritoriesDataSet();
			IEmployeeTerritoriesService EmployeeTerritoriesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateEmployeeTerritoriesService();
			
			if (EmployeeTerritoriesLogic.GetByEmployeeIDAndTerritoryID(EmployeeTerritoriesDS, m_EmployeeIDCurrent, m_TerritoryIDCurrent) == 0)
			{
				//
				// EmployeeTerritories Row not found
				//
				return false;
			}

			EmployeeTerritoriesDataSet.EmployeeTerritoriesRow EmployeeTerritoriesRowCurrent = EmployeeTerritoriesDS.EmployeeTerritories[0];
			ListItem SelectedListItem;
			
			//
			// Populate the Page controls from the DataRow
			//
			SelectedListItem = ctlEmployeeID.Items.FindByValue(EmployeeTerritoriesRowCurrent.EmployeeID.ToString());
			if (SelectedListItem != null)
			{
				ctlEmployeeID.ClearSelection();
				SelectedListItem.Selected = true;
			}
			SelectedListItem = ctlTerritoryID.Items.FindByValue(EmployeeTerritoriesRowCurrent.TerritoryID.ToString());
			if (SelectedListItem != null)
			{
				ctlTerritoryID.ClearSelection();
				SelectedListItem.Selected = true;
			}
			
			
			return true;
		}
		
		
		/// <summary>
		/// Adds or updates the row in the Database
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool SaveData()
		{
			//
			// Check that the Form has passed validation
			//
			Page.Validate();
			
			if (!Page.IsValid)
			{
				// Validation failed
				return false;
			}
			
			EmployeeTerritoriesDataSet EmployeeTerritoriesDS = new EmployeeTerritoriesDataSet();
			IEmployeeTerritoriesService EmployeeTerritoriesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateEmployeeTerritoriesService();
			EmployeeTerritoriesDataSet.EmployeeTerritoriesRow EmployeeTerritoriesRowCurrent;
			
			
			switch (DataEntryMode)
			{
				case PageDataEntryMode.AddRow:
					//
					// Create a New Row
					//
					EmployeeTerritoriesRowCurrent = EmployeeTerritoriesDS.EmployeeTerritories.NewEmployeeTerritoriesRow();
					break;
					
				case PageDataEntryMode.EditRow:
					//
					// Update existing Row
					//
					if (EmployeeTerritoriesLogic.GetByEmployeeIDAndTerritoryID(EmployeeTerritoriesDS, m_EmployeeIDCurrent, m_TerritoryIDCurrent) == 0)
					{
						//
						// EmployeeTerritories Row not found
						//
						return false;
					}
					else
					{
						EmployeeTerritoriesRowCurrent = EmployeeTerritoriesDS.EmployeeTerritories[0];
					}
					break;
					
				default:
					return false;
			}

			//
			// Set the DataRow values from the Page Controls
			//
			
			// EmployeeID
			EmployeeTerritoriesRowCurrent.EmployeeID = Convert.ToInt32(ctlEmployeeID.SelectedItem.Value);
			// TerritoryID
			EmployeeTerritoriesRowCurrent.TerritoryID = ctlTerritoryID.SelectedItem.Value;
			
			if (DataEntryMode == PageDataEntryMode.AddRow)
			{
				//
				// Add the new Row to the DataSet
				//
				EmployeeTerritoriesDS.EmployeeTerritories.Rows.Add(EmployeeTerritoriesRowCurrent);
			}

			//
			// Save the changes to the database
			//
			EmployeeTerritoriesLogic.UpdateDataSet(EmployeeTerritoriesDS);
			
			//
			// Update the primary key values
			//
			m_EmployeeIDCurrent = EmployeeTerritoriesRowCurrent.EmployeeID;
			m_TerritoryIDCurrent = EmployeeTerritoriesRowCurrent.TerritoryID;
			
			
			return true;
		}
		
		
		#endregion

		
		#region Web Form Designer generated code
		
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.ValidationSummary ctlValidationSummary;
		protected System.Web.UI.WebControls.Button btnOK;
		protected System.Web.UI.WebControls.Button btnApply;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.DropDownList ctlEmployeeID;
		protected System.Web.UI.WebControls.DropDownList ctlTerritoryID;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			
		}
		
		#endregion
	}
}
