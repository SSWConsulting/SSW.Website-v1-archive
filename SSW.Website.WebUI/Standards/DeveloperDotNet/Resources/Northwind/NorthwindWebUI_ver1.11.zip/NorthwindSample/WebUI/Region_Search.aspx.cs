using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the Region table
	/// </summary>
	public class Region_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("RegionID", RegionID);
			CriteriaCount += LoadSearchString("RegionDescription", RegionDescription);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "Region Search";

				if (CriteriaCount > 0)
				{
					RegionGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void RegionGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(
						string.Format("Region.aspx?{0}={1}", "RegionID", RegionGrid.DataKeys[e.Item.ItemIndex].ToString())
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void RegionGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			RegionGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void RegionGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the Region table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_RegionQuery = CommonFactory.CreateQuery();

			AddToQuery(m_RegionQuery, RegionTable.RegionID, Comparison.EqualTo, RegionID);
			AddToQuery(m_RegionQuery, RegionTable.RegionDescription, Comparison.Contains, RegionDescription);
			

			AddSortToQuery(m_RegionQuery, typeof(RegionTable));
			
			IRegionService RegionLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateRegionService();
			int ResultCount = RegionLogic.GetByQuery(m_RegionDataSet, m_RegionQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				RegionGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.RegionDataSet m_RegionDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid RegionGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText RegionID;
		protected System.Web.UI.HtmlControls.HtmlInputText RegionDescription;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_RegionDataSet = new NorthwindSample.Data.RegionDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_RegionDataSet)).BeginInit();
			this.RegionGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.RegionGrid_ItemCommand);
			this.RegionGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.RegionGrid_PageIndexChanged);
			this.RegionGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.RegionGrid_SortCommand);
			// 
			// m_RegionDataSet
			// 
			this.m_RegionDataSet.DataSetName = "RegionDataSet";
			this.m_RegionDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_RegionDataSet)).EndInit();

		}
		
		#endregion

	}
}
