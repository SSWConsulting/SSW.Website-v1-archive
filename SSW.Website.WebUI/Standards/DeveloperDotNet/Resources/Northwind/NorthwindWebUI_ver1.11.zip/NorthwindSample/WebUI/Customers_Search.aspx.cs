using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the Customers table
	/// </summary>
	public class Customers_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("CustomerID", CustomerID);
			CriteriaCount += LoadSearchString("CompanyName", CompanyName);
			CriteriaCount += LoadSearchString("ContactName", ContactName);
			CriteriaCount += LoadSearchString("ContactTitle", ContactTitle);
			CriteriaCount += LoadSearchString("Address", Address);
			CriteriaCount += LoadSearchString("City", City);
			CriteriaCount += LoadSearchString("Region", Region);
			CriteriaCount += LoadSearchString("PostalCode", PostalCode);
			CriteriaCount += LoadSearchString("Country", Country);
			CriteriaCount += LoadSearchString("Phone", Phone);
			CriteriaCount += LoadSearchString("Fax", Fax);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "Customers Search";

				if (CriteriaCount > 0)
				{
					CustomersGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void CustomersGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(
						string.Format("Customers.aspx?{0}={1}", "CustomerID", CustomersGrid.DataKeys[e.Item.ItemIndex].ToString())
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void CustomersGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			CustomersGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void CustomersGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the Customers table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_CustomersQuery = CommonFactory.CreateQuery();

			AddToQuery(m_CustomersQuery, CustomersTable.CustomerID, Comparison.EqualTo, CustomerID);
			AddToQuery(m_CustomersQuery, CustomersTable.CompanyName, Comparison.Contains, CompanyName);
			AddToQuery(m_CustomersQuery, CustomersTable.ContactName, Comparison.Contains, ContactName);
			AddToQuery(m_CustomersQuery, CustomersTable.ContactTitle, Comparison.Contains, ContactTitle);
			AddToQuery(m_CustomersQuery, CustomersTable.Address, Comparison.Contains, Address);
			AddToQuery(m_CustomersQuery, CustomersTable.City, Comparison.Contains, City);
			AddToQuery(m_CustomersQuery, CustomersTable.Region, Comparison.Contains, Region);
			AddToQuery(m_CustomersQuery, CustomersTable.PostalCode, Comparison.Contains, PostalCode);
			AddToQuery(m_CustomersQuery, CustomersTable.Country, Comparison.Contains, Country);
			AddToQuery(m_CustomersQuery, CustomersTable.Phone, Comparison.Contains, Phone);
			AddToQuery(m_CustomersQuery, CustomersTable.Fax, Comparison.Contains, Fax);
			

			AddSortToQuery(m_CustomersQuery, typeof(CustomersTable));
			
			ICustomersService CustomersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCustomersService();
			int ResultCount = CustomersLogic.GetByQuery(m_CustomersDataSet, m_CustomersQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				CustomersGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.CustomersDataSet m_CustomersDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid CustomersGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText CustomerID;
		protected System.Web.UI.HtmlControls.HtmlInputText CompanyName;
		protected System.Web.UI.HtmlControls.HtmlInputText ContactName;
		protected System.Web.UI.HtmlControls.HtmlInputText ContactTitle;
		protected System.Web.UI.HtmlControls.HtmlInputText Address;
		protected System.Web.UI.HtmlControls.HtmlInputText City;
		protected System.Web.UI.HtmlControls.HtmlInputText Region;
		protected System.Web.UI.HtmlControls.HtmlInputText PostalCode;
		protected System.Web.UI.HtmlControls.HtmlInputText Country;
		protected System.Web.UI.HtmlControls.HtmlInputText Phone;
		protected System.Web.UI.HtmlControls.HtmlInputText Fax;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_CustomersDataSet = new NorthwindSample.Data.CustomersDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_CustomersDataSet)).BeginInit();
			this.CustomersGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.CustomersGrid_ItemCommand);
			this.CustomersGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.CustomersGrid_PageIndexChanged);
			this.CustomersGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.CustomersGrid_SortCommand);
			// 
			// m_CustomersDataSet
			// 
			this.m_CustomersDataSet.DataSetName = "CustomersDataSet";
			this.m_CustomersDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_CustomersDataSet)).EndInit();

		}
		
		#endregion

	}
}
