using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Code-behind file for the Customers.aspx Page
	/// </summary>
	public class Customers : EditablePage
	{
		#region Constants


		#endregion


		#region Fields

		private String m_CustomerIDCurrent;
		

		#endregion

				
		#region Page Events

		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			//
			// Find primary key values to use to populate the form
			//
			if (HasQueryStringParameter("CustomerID"))
			{
				m_CustomerIDCurrent = Convert.ToString(Request.QueryString["CustomerID"]);
				
				DataEntryMode = PageDataEntryMode.EditRow;

				PageTitle = string.Format("Customers - Editing {0}: {1}", "CustomerID", m_CustomerIDCurrent);
			}
			else
			{
				DataEntryMode = PageDataEntryMode.AddRow;

				PageTitle = "Customers - Adding a new entry";
				lblMessage.Text = "Adding a new entry";
			}

			if (Page.IsPostBack)
			{
			
			}
			else
			{
				//
				// Initial Page Request
				//
				PopulateControls();

				if (DataEntryMode == PageDataEntryMode.EditRow || DataEntryMode == PageDataEntryMode.ViewRow)
				{
					if (!LoadData())
					{
						//
						// Could not load the row from the database
						//
						lblMessage.Text = "Error loading Customers";

						DataEntryMode = PageDataEntryMode.ErrorOccurred;
						
						DisableDataEntryControls(this.Controls);
					}
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Apply the changes and return to the previous screen
		/// </summary>
		private void btnOK_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				Response.Redirect(UrlPrevious.ToString());
			}
		}


		/// <summary>
		/// Apply the changes and remain on this page
		/// </summary>
		private void btnApply_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				//
				// Redirect back to this page in Edit mode
				//
				if (DataEntryMode == PageDataEntryMode.AddRow)
				{	
					UriBuilder EditUri = new UriBuilder(Request.Url);
					EditUri.Query += string.Format("{0}={1}", "CustomerID", m_CustomerIDCurrent);

					//
					// Redirect back to this page 
					// with the primary key information in the query string
					//
					Response.Redirect(EditUri.ToString());
							
				}
				else
				{
					lblMessage.Text = "Customers saved";

					LoadData();
				}
			}
			else
			{
				lblMessage.Text = "Error saving Customers";
				DataEntryMode = PageDataEntryMode.ErrorOccurred;
			}
		}
		
		
		/// <summary>
		/// return to the previous screen
		/// </summary>
		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(UrlPrevious.ToString());
		}
		
		#endregion


		#region Private Methods
		
		/// <summary>
		/// Loads data from the database for drop down lists
		/// </summary>
		private void PopulateControls()
		{
			
		}
		
		/// <summary>
		/// Loads a row from the Customers table for viewing or editing
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool LoadData()
		{
			if ((DataEntryMode != PageDataEntryMode.EditRow) && (DataEntryMode != PageDataEntryMode.ViewRow))
			{
				return true;
			}
			
			CustomersDataSet CustomersDS = new CustomersDataSet();
			ICustomersService CustomersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCustomersService();
			
			if (CustomersLogic.GetByCustomerID(CustomersDS, m_CustomerIDCurrent) == 0)
			{
				//
				// Customers Row not found
				//
				return false;
			}

			CustomersDataSet.CustomersRow CustomersRowCurrent = CustomersDS.Customers[0];
			ListItem SelectedListItem;
			
			//
			// Populate the Page controls from the DataRow
			//
			ctlCustomerID.Text = CustomersRowCurrent.CustomerID;
			ctlCompanyName.Text = CustomersRowCurrent.CompanyName;
			ctlContactName.Text = (CustomersRowCurrent.IsContactNameNull()) ? string.Empty : CustomersRowCurrent.ContactName;
			ctlContactTitle.Text = (CustomersRowCurrent.IsContactTitleNull()) ? string.Empty : CustomersRowCurrent.ContactTitle;
			ctlAddress.Text = (CustomersRowCurrent.IsAddressNull()) ? string.Empty : CustomersRowCurrent.Address;
			ctlCity.Text = (CustomersRowCurrent.IsCityNull()) ? string.Empty : CustomersRowCurrent.City;
			ctlRegion.Text = (CustomersRowCurrent.IsRegionNull()) ? string.Empty : CustomersRowCurrent.Region;
			ctlPostalCode.Text = (CustomersRowCurrent.IsPostalCodeNull()) ? string.Empty : CustomersRowCurrent.PostalCode;
			ctlCountry.Text = (CustomersRowCurrent.IsCountryNull()) ? string.Empty : CustomersRowCurrent.Country;
			ctlPhone.Text = (CustomersRowCurrent.IsPhoneNull()) ? string.Empty : CustomersRowCurrent.Phone;
			ctlFax.Text = (CustomersRowCurrent.IsFaxNull()) ? string.Empty : CustomersRowCurrent.Fax;
			
			
			return true;
		}
		
		
		/// <summary>
		/// Adds or updates the row in the Database
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool SaveData()
		{
			//
			// Check that the Form has passed validation
			//
			Page.Validate();
			
			if (!Page.IsValid)
			{
				// Validation failed
				return false;
			}
			
			CustomersDataSet CustomersDS = new CustomersDataSet();
			ICustomersService CustomersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCustomersService();
			CustomersDataSet.CustomersRow CustomersRowCurrent;
			
			
			switch (DataEntryMode)
			{
				case PageDataEntryMode.AddRow:
					//
					// Create a New Row
					//
					CustomersRowCurrent = CustomersDS.Customers.NewCustomersRow();
					break;
					
				case PageDataEntryMode.EditRow:
					//
					// Update existing Row
					//
					if (CustomersLogic.GetByCustomerID(CustomersDS, m_CustomerIDCurrent) == 0)
					{
						//
						// Customers Row not found
						//
						return false;
					}
					else
					{
						CustomersRowCurrent = CustomersDS.Customers[0];
					}
					break;
					
				default:
					return false;
			}

			//
			// Set the DataRow values from the Page Controls
			//
			
			// CustomerID
			CustomersRowCurrent.CustomerID = ctlCustomerID.Text;
			// CompanyName
			CustomersRowCurrent.CompanyName = ctlCompanyName.Text;
			// ContactName
			if (ctlContactName.Text.Length == 0)
			{
				CustomersRowCurrent.SetContactNameNull();
			}
			else
			{
				CustomersRowCurrent.ContactName = ctlContactName.Text;
			}
						
			// ContactTitle
			if (ctlContactTitle.Text.Length == 0)
			{
				CustomersRowCurrent.SetContactTitleNull();
			}
			else
			{
				CustomersRowCurrent.ContactTitle = ctlContactTitle.Text;
			}
						
			// Address
			if (ctlAddress.Text.Length == 0)
			{
				CustomersRowCurrent.SetAddressNull();
			}
			else
			{
				CustomersRowCurrent.Address = ctlAddress.Text;
			}
						
			// City
			if (ctlCity.Text.Length == 0)
			{
				CustomersRowCurrent.SetCityNull();
			}
			else
			{
				CustomersRowCurrent.City = ctlCity.Text;
			}
						
			// Region
			if (ctlRegion.Text.Length == 0)
			{
				CustomersRowCurrent.SetRegionNull();
			}
			else
			{
				CustomersRowCurrent.Region = ctlRegion.Text;
			}
						
			// PostalCode
			if (ctlPostalCode.Text.Length == 0)
			{
				CustomersRowCurrent.SetPostalCodeNull();
			}
			else
			{
				CustomersRowCurrent.PostalCode = ctlPostalCode.Text;
			}
						
			// Country
			if (ctlCountry.Text.Length == 0)
			{
				CustomersRowCurrent.SetCountryNull();
			}
			else
			{
				CustomersRowCurrent.Country = ctlCountry.Text;
			}
						
			// Phone
			if (ctlPhone.Text.Length == 0)
			{
				CustomersRowCurrent.SetPhoneNull();
			}
			else
			{
				CustomersRowCurrent.Phone = ctlPhone.Text;
			}
						
			// Fax
			if (ctlFax.Text.Length == 0)
			{
				CustomersRowCurrent.SetFaxNull();
			}
			else
			{
				CustomersRowCurrent.Fax = ctlFax.Text;
			}
						
			
			if (DataEntryMode == PageDataEntryMode.AddRow)
			{
				//
				// Add the new Row to the DataSet
				//
				CustomersDS.Customers.Rows.Add(CustomersRowCurrent);
			}

			//
			// Save the changes to the database
			//
			CustomersLogic.UpdateDataSet(CustomersDS);
			
			//
			// Update the primary key values
			//
			m_CustomerIDCurrent = CustomersRowCurrent.CustomerID;
			
			
			return true;
		}
		
		
		#endregion

		
		#region Web Form Designer generated code
		
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.ValidationSummary ctlValidationSummary;
		protected System.Web.UI.WebControls.Button btnOK;
		protected System.Web.UI.WebControls.Button btnApply;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.TextBox ctlCustomerID;
		protected System.Web.UI.WebControls.TextBox ctlCompanyName;
		protected System.Web.UI.WebControls.TextBox ctlContactName;
		protected System.Web.UI.WebControls.TextBox ctlContactTitle;
		protected System.Web.UI.WebControls.TextBox ctlAddress;
		protected System.Web.UI.WebControls.TextBox ctlCity;
		protected System.Web.UI.WebControls.TextBox ctlRegion;
		protected System.Web.UI.WebControls.TextBox ctlPostalCode;
		protected System.Web.UI.WebControls.TextBox ctlCountry;
		protected System.Web.UI.WebControls.TextBox ctlPhone;
		protected System.Web.UI.WebControls.TextBox ctlFax;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			
		}
		
		#endregion
	}
}
