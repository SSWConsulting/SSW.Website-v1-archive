using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.DatabaseSchema;

using RAD.AppFramework.QueryObjects;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Code-behind file for the Orders.aspx Page
	/// </summary>
	public class Orders : EditablePage
	{
		#region Constants


		#endregion


		#region Fields

		private Int32 m_OrderIDCurrent;
		

		#endregion

				
		#region Page Events

		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			//
			// Find primary key values to use to populate the form
			//
			if (HasQueryStringParameter("OrderID"))
			{
				m_OrderIDCurrent = Convert.ToInt32(Request.QueryString["OrderID"]);
				
				DataEntryMode = PageDataEntryMode.EditRow;

				PageTitle = string.Format("Orders - Editing {0}: {1}", "OrderID", m_OrderIDCurrent);
			}
			else
			{
				DataEntryMode = PageDataEntryMode.AddRow;

				PageTitle = "Orders - Adding a new entry";
				lblMessage.Text = "Adding a new entry";
			}

			if (Page.IsPostBack)
			{
			
			}
			else
			{
				//
				// Initial Page Request
				//
				PopulateControls();

				if (DataEntryMode == PageDataEntryMode.EditRow || DataEntryMode == PageDataEntryMode.ViewRow)
				{
					if (!LoadData())
					{
						//
						// Could not load the row from the database
						//
						lblMessage.Text = "Error loading Orders";

						DataEntryMode = PageDataEntryMode.ErrorOccurred;
						
						DisableDataEntryControls(this.Controls);
					}
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Apply the changes and return to the previous screen
		/// </summary>
		private void btnOK_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				Response.Redirect(UrlPrevious.ToString());
			}
		}


		/// <summary>
		/// Apply the changes and remain on this page
		/// </summary>
		private void btnApply_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				//
				// Redirect back to this page in Edit mode
				//
				if (DataEntryMode == PageDataEntryMode.AddRow)
				{	
					UriBuilder EditUri = new UriBuilder(Request.Url);
					EditUri.Query += string.Format("{0}={1}", "OrderID", m_OrderIDCurrent);

					//
					// Redirect back to this page 
					// with the primary key information in the query string
					//
					Response.Redirect(EditUri.ToString());
							
				}
				else
				{
					lblMessage.Text = "Orders saved";

					LoadData();
				}
			}
			else
			{
				lblMessage.Text = "Error saving Orders";
				DataEntryMode = PageDataEntryMode.ErrorOccurred;
			}
		}
		
		
		/// <summary>
		/// return to the previous screen
		/// </summary>
		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(UrlPrevious.ToString());
		}
		
		#endregion


		#region Private Methods
		
		/// <summary>
		/// Loads data from the database for drop down lists
		/// </summary>
		private void PopulateControls()
		{
			
			//
			// Populate the CustomerID Drop Down List
			//
			CustomersDataSet CustomersDS = new CustomersDataSet();
			ICustomersService CustomersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateCustomersService();
			
			if (CustomersLogic.GetAll(CustomersDS) > 0)
			{
				ListItem CustomersListItemNew;
				foreach (CustomersDataSet.CustomersRow CustomersCurrent in CustomersDS.Customers.Rows)
				{
					CustomersListItemNew = new ListItem();
					CustomersListItemNew.Value = CustomersCurrent.CustomerID.ToString();
					CustomersListItemNew.Text = CustomersCurrent.CustomerID.ToString();
					ctlCustomerID.Items.Add(CustomersListItemNew);
				}
			}
			
			//
			// Populate the EmployeeID Drop Down List
			//
			EmployeesDataSet EmployeesDS = new EmployeesDataSet();
			IEmployeesService EmployeesLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateEmployeesService();
			
			if (EmployeesLogic.GetAll(EmployeesDS) > 0)
			{
				ListItem EmployeesListItemNew;
				foreach (EmployeesDataSet.EmployeesRow EmployeesCurrent in EmployeesDS.Employees.Rows)
				{
					EmployeesListItemNew = new ListItem();
					EmployeesListItemNew.Value = EmployeesCurrent.EmployeeID.ToString();
					EmployeesListItemNew.Text = 
						String.Format("{0} {1}", EmployeesCurrent.FirstName, EmployeesCurrent.LastName);

					ctlEmployeeID.Items.Add(EmployeesListItemNew);
				}
			}
			
			//
			// Populate the ShipVia Drop Down List
			//
			ShippersDataSet ShippersDS = new ShippersDataSet();
			IShippersService ShippersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateShippersService();
			
			if (ShippersLogic.GetAll(ShippersDS) > 0)
			{
				ListItem ShippersListItemNew;
				foreach (ShippersDataSet.ShippersRow ShippersCurrent in ShippersDS.Shippers.Rows)
				{
					ShippersListItemNew = new ListItem();
					ShippersListItemNew.Value = ShippersCurrent.ShipperID.ToString();
					ShippersListItemNew.Text = ShippersCurrent.CompanyName;

					ctlShipVia.Items.Add(ShippersListItemNew);
				}
			}
		}
		
		/// <summary>
		/// Loads a row from the Orders table for viewing or editing
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool LoadData()
		{
			if ((DataEntryMode != PageDataEntryMode.EditRow) && (DataEntryMode != PageDataEntryMode.ViewRow))
			{
				return true;
			}
			
			OrdersDataSet OrdersDS = new OrdersDataSet();
			IOrdersService OrdersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateOrdersService();
			
			if (OrdersLogic.GetByOrderID(OrdersDS, m_OrderIDCurrent) == 0)
			{
				//
				// Orders Row not found
				//
				return false;
			}

			OrdersDataSet.OrdersRow OrdersRowCurrent = OrdersDS.Orders[0];
			ListItem SelectedListItem;
			
			//
			// Populate the Page controls from the DataRow
			//
			ctlOrderID.Text = OrdersRowCurrent.OrderID.ToString();
			
			if (!OrdersRowCurrent.IsCustomerIDNull())
			{
				SelectedListItem = ctlCustomerID.Items.FindByValue(OrdersRowCurrent.CustomerID.ToString());
				if (SelectedListItem != null)
				{
					ctlCustomerID.ClearSelection();
					SelectedListItem.Selected = true;
				}
			}
			
			if (!OrdersRowCurrent.IsEmployeeIDNull())
			{
				SelectedListItem = ctlEmployeeID.Items.FindByValue(OrdersRowCurrent.EmployeeID.ToString());
				if (SelectedListItem != null)
				{
					ctlEmployeeID.ClearSelection();
					SelectedListItem.Selected = true;
				}
			}
			ctlOrderDate.Text = (OrdersRowCurrent.IsOrderDateNull()) ? string.Empty : OrdersRowCurrent.OrderDate.ToString();
			ctlRequiredDate.Text = (OrdersRowCurrent.IsRequiredDateNull()) ? string.Empty : OrdersRowCurrent.RequiredDate.ToString();
			ctlShippedDate.Text = (OrdersRowCurrent.IsShippedDateNull()) ? string.Empty : OrdersRowCurrent.ShippedDate.ToString();
			
			if (!OrdersRowCurrent.IsShipViaNull())
			{
				SelectedListItem = ctlShipVia.Items.FindByValue(OrdersRowCurrent.ShipVia.ToString());
				if (SelectedListItem != null)
				{
					ctlShipVia.ClearSelection();
					SelectedListItem.Selected = true;
				}
			}
			ctlFreight.Text = (OrdersRowCurrent.IsFreightNull()) ? string.Empty : OrdersRowCurrent.Freight.ToString("0.00");
			ctlShipName.Text = (OrdersRowCurrent.IsShipNameNull()) ? string.Empty : OrdersRowCurrent.ShipName;
			ctlShipAddress.Text = (OrdersRowCurrent.IsShipAddressNull()) ? string.Empty : OrdersRowCurrent.ShipAddress;
			ctlShipCity.Text = (OrdersRowCurrent.IsShipCityNull()) ? string.Empty : OrdersRowCurrent.ShipCity;
			ctlShipRegion.Text = (OrdersRowCurrent.IsShipRegionNull()) ? string.Empty : OrdersRowCurrent.ShipRegion;
			ctlShipPostalCode.Text = (OrdersRowCurrent.IsShipPostalCodeNull()) ? string.Empty : OrdersRowCurrent.ShipPostalCode;
			ctlShipCountry.Text = (OrdersRowCurrent.IsShipCountryNull()) ? string.Empty : OrdersRowCurrent.ShipCountry;
			
			//
			// 1. ML - Populate the OrderDetails
			//

			IViewOrderDetailsService ViewOrderDetailsLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateViewOrderDetailsService();
			Query qry = Common.CommonFactory.CreateQuery();
			qry.And( Criteria.EqualTo(ViewOrderDetailsTable.OrderID, m_OrderIDCurrent));

			ViewOrderDetailsLogic.GetByQuery( m_ViewOrderDetailsDataSet, qry);
			OrderDetailsGrid.DataBind();

			
			return true;
		}
		
		
		/// <summary>
		/// Adds or updates the row in the Database
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool SaveData()
		{
			//
			// Check that the Form has passed validation
			//
			Page.Validate();
			
			if (!Page.IsValid)
			{
				// Validation failed
				return false;
			}
			
			OrdersDataSet OrdersDS = new OrdersDataSet();
			IOrdersService OrdersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateOrdersService();
			OrdersDataSet.OrdersRow OrdersRowCurrent;
			
			
			switch (DataEntryMode)
			{
				case PageDataEntryMode.AddRow:
					//
					// Create a New Row
					//
					OrdersRowCurrent = OrdersDS.Orders.NewOrdersRow();
					break;
					
				case PageDataEntryMode.EditRow:
					//
					// Update existing Row
					//
					if (OrdersLogic.GetByOrderID(OrdersDS, m_OrderIDCurrent) == 0)
					{
						//
						// Orders Row not found
						//
						return false;
					}
					else
					{
						OrdersRowCurrent = OrdersDS.Orders[0];
					}
					break;
					
				default:
					return false;
			}

			//
			// Set the DataRow values from the Page Controls
			//
			
			// CustomerID
			
			
			if (ctlCustomerID.SelectedIndex == 0)
			{
				OrdersRowCurrent.SetCustomerIDNull();	
			}
			else
			{
				OrdersRowCurrent.CustomerID = ctlCustomerID.SelectedItem.Value;
			}
			
			// EmployeeID
			
			
			if (ctlEmployeeID.SelectedIndex == 0)
			{
				OrdersRowCurrent.SetEmployeeIDNull();	
			}
			else
			{
				OrdersRowCurrent.EmployeeID = Convert.ToInt32(ctlEmployeeID.SelectedItem.Value);
			}
			
			// OrderDate
			if (ctlOrderDate.Text.Length == 0)
			{
				OrdersRowCurrent.SetOrderDateNull();
			}
			else
			{
				OrdersRowCurrent.OrderDate = Convert.ToDateTime(ctlOrderDate.Text);
			}
						
			// RequiredDate
			if (ctlRequiredDate.Text.Length == 0)
			{
				OrdersRowCurrent.SetRequiredDateNull();
			}
			else
			{
				OrdersRowCurrent.RequiredDate = Convert.ToDateTime(ctlRequiredDate.Text);
			}
						
			// ShippedDate
			if (ctlShippedDate.Text.Length == 0)
			{
				OrdersRowCurrent.SetShippedDateNull();
			}
			else
			{
				OrdersRowCurrent.ShippedDate = Convert.ToDateTime(ctlShippedDate.Text);
			}
						
			// ShipVia
			
			
			if (ctlShipVia.SelectedIndex == 0)
			{
				OrdersRowCurrent.SetShipViaNull();	
			}
			else
			{
				OrdersRowCurrent.ShipVia = Convert.ToInt32(ctlShipVia.SelectedItem.Value);
			}
			
			// Freight
			if (ctlFreight.Text.Length == 0)
			{
				OrdersRowCurrent.SetFreightNull();
			}
			else
			{
				OrdersRowCurrent.Freight = Convert.ToDecimal(ctlFreight.Text);
			}
						
			// ShipName
			if (ctlShipName.Text.Length == 0)
			{
				OrdersRowCurrent.SetShipNameNull();
			}
			else
			{
				OrdersRowCurrent.ShipName = ctlShipName.Text;
			}
						
			// ShipAddress
			if (ctlShipAddress.Text.Length == 0)
			{
				OrdersRowCurrent.SetShipAddressNull();
			}
			else
			{
				OrdersRowCurrent.ShipAddress = ctlShipAddress.Text;
			}
						
			// ShipCity
			if (ctlShipCity.Text.Length == 0)
			{
				OrdersRowCurrent.SetShipCityNull();
			}
			else
			{
				OrdersRowCurrent.ShipCity = ctlShipCity.Text;
			}
						
			// ShipRegion
			if (ctlShipRegion.Text.Length == 0)
			{
				OrdersRowCurrent.SetShipRegionNull();
			}
			else
			{
				OrdersRowCurrent.ShipRegion = ctlShipRegion.Text;
			}
						
			// ShipPostalCode
			if (ctlShipPostalCode.Text.Length == 0)
			{
				OrdersRowCurrent.SetShipPostalCodeNull();
			}
			else
			{
				OrdersRowCurrent.ShipPostalCode = ctlShipPostalCode.Text;
			}
						
			// ShipCountry
			if (ctlShipCountry.Text.Length == 0)
			{
				OrdersRowCurrent.SetShipCountryNull();
			}
			else
			{
				OrdersRowCurrent.ShipCountry = ctlShipCountry.Text;
			}
						
			
			if (DataEntryMode == PageDataEntryMode.AddRow)
			{
				//
				// Add the new Row to the DataSet
				//
				OrdersDS.Orders.Rows.Add(OrdersRowCurrent);
			}

			//
			// Save the changes to the database
			//
			OrdersLogic.UpdateDataSet(OrdersDS);
			
			//
			// Update the primary key values
			//
			m_OrderIDCurrent = OrdersRowCurrent.OrderID;
			
			
			return true;
		}
		
		
		#endregion

		
		#region Web Form Designer generated code
		
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.ValidationSummary ctlValidationSummary;
		protected System.Web.UI.WebControls.Button btnOK;
		protected System.Web.UI.WebControls.Button btnApply;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.Label ctlOrderID;
		protected System.Web.UI.WebControls.DropDownList ctlCustomerID;
		protected System.Web.UI.WebControls.DropDownList ctlEmployeeID;
		protected System.Web.UI.WebControls.TextBox ctlOrderDate;
		protected System.Web.UI.WebControls.TextBox ctlRequiredDate;
		protected System.Web.UI.WebControls.TextBox ctlShippedDate;
		protected System.Web.UI.WebControls.DropDownList ctlShipVia;
		protected System.Web.UI.WebControls.TextBox ctlFreight;
		protected System.Web.UI.WebControls.TextBox ctlShipName;
		protected System.Web.UI.WebControls.TextBox ctlShipAddress;
		protected System.Web.UI.WebControls.TextBox ctlShipCity;
		protected System.Web.UI.WebControls.TextBox ctlShipRegion;
		protected System.Web.UI.WebControls.TextBox ctlShipPostalCode;
		protected System.Web.UI.WebControls.CompareValidator ctlFreightDataTypeCurrency;
		protected System.Web.UI.WebControls.DataGrid OrderDetailsGrid;
		protected NorthwindSample.Data.ViewOrderDetailsDataSet m_ViewOrderDetailsDataSet;
		protected System.Web.UI.WebControls.TextBox ctlShipCountry;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_ViewOrderDetailsDataSet = new NorthwindSample.Data.ViewOrderDetailsDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_ViewOrderDetailsDataSet)).BeginInit();
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
			this.OrderDetailsGrid.ItemDataBound += new System.Web.UI.WebControls.DataGridItemEventHandler(this.OrderDetailsGrid_ItemDataBound);
			// 
			// m_ViewOrderDetailsDataSet
			// 
			this.m_ViewOrderDetailsDataSet.DataSetName = "ViewOrderDetailsDataSet";
			this.m_ViewOrderDetailsDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_ViewOrderDetailsDataSet)).EndInit();

		}
		
		#endregion


		//
		// 2. ML - Bind the Edit hyperlink
		//
		private void OrderDetailsGrid_ItemDataBound(object sender, System.Web.UI.WebControls.DataGridItemEventArgs e)
		{
			if( e.Item.ItemType != ListItemType.Header && e.Item.ItemType != ListItemType.Footer)
			{
				HyperLink link = (HyperLink) e.Item.Cells[0].Controls[0];
				DataRowView rowView = (DataRowView) e.Item.DataItem;
				ViewOrderDetailsDataSet.ViewOrderDetailsRow row = (ViewOrderDetailsDataSet.ViewOrderDetailsRow) rowView.Row;

				link.NavigateUrl = String.Format("OrderDetails.aspx?OrderID={0}&ProductID={1}", row.OrderID, row.ProductID);
			}
		}
	}
}
