using System;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace NorthwindSample.WebUI.Components
{
	/// <summary>
	///	Menu UserControl
	/// </summary>
	public class Menu : System.Web.UI.UserControl
	{
		#region Constants



		#endregion


		#region Fields



		#endregion


		#region Page Events

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (IsPostBack)
			{
			}
			else
			{
			}
		}

		#endregion


		#region Event Handlers for Controls



		#endregion


		#region Private & Protected Methods



		#endregion
		
		
		#region Public Properties
		
		
		
		#endregion
		

		#region Web Form Designer generated code
		
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);
		}
		
		#endregion
	}
}
