using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Code-behind file for the Shippers.aspx Page
	/// </summary>
	public class Shippers : EditablePage
	{
		#region Constants


		#endregion


		#region Fields

		private Int32 m_ShipperIDCurrent;
		

		#endregion

				
		#region Page Events

		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			//
			// Find primary key values to use to populate the form
			//
			if (HasQueryStringParameter("ShipperID"))
			{
				m_ShipperIDCurrent = Convert.ToInt32(Request.QueryString["ShipperID"]);
				
				DataEntryMode = PageDataEntryMode.EditRow;

				PageTitle = string.Format("Shippers - Editing {0}: {1}", "ShipperID", m_ShipperIDCurrent);
			}
			else
			{
				DataEntryMode = PageDataEntryMode.AddRow;

				PageTitle = "Shippers - Adding a new entry";
				lblMessage.Text = "Adding a new entry";
			}

			if (Page.IsPostBack)
			{
			
			}
			else
			{
				//
				// Initial Page Request
				//
				PopulateControls();

				if (DataEntryMode == PageDataEntryMode.EditRow || DataEntryMode == PageDataEntryMode.ViewRow)
				{
					if (!LoadData())
					{
						//
						// Could not load the row from the database
						//
						lblMessage.Text = "Error loading Shippers";

						DataEntryMode = PageDataEntryMode.ErrorOccurred;
						
						DisableDataEntryControls(this.Controls);
					}
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Apply the changes and return to the previous screen
		/// </summary>
		private void btnOK_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				Response.Redirect(UrlPrevious.ToString());
			}
		}


		/// <summary>
		/// Apply the changes and remain on this page
		/// </summary>
		private void btnApply_Click(object sender, System.EventArgs e)
		{
			if (SaveData())
			{
				//
				// Redirect back to this page in Edit mode
				//
				if (DataEntryMode == PageDataEntryMode.AddRow)
				{	
					UriBuilder EditUri = new UriBuilder(Request.Url);
					EditUri.Query += string.Format("{0}={1}", "ShipperID", m_ShipperIDCurrent);

					//
					// Redirect back to this page 
					// with the primary key information in the query string
					//
					Response.Redirect(EditUri.ToString());
							
				}
				else
				{
					lblMessage.Text = "Shippers saved";

					LoadData();
				}
			}
			else
			{
				lblMessage.Text = "Error saving Shippers";
				DataEntryMode = PageDataEntryMode.ErrorOccurred;
			}
		}
		
		
		/// <summary>
		/// return to the previous screen
		/// </summary>
		private void btnCancel_Click(object sender, System.EventArgs e)
		{
			Response.Redirect(UrlPrevious.ToString());
		}
		
		#endregion


		#region Private Methods
		
		/// <summary>
		/// Loads data from the database for drop down lists
		/// </summary>
		private void PopulateControls()
		{
			
		}
		
		/// <summary>
		/// Loads a row from the Shippers table for viewing or editing
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool LoadData()
		{
			if ((DataEntryMode != PageDataEntryMode.EditRow) && (DataEntryMode != PageDataEntryMode.ViewRow))
			{
				return true;
			}
			
			ShippersDataSet ShippersDS = new ShippersDataSet();
			IShippersService ShippersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateShippersService();
			
			if (ShippersLogic.GetByShipperID(ShippersDS, m_ShipperIDCurrent) == 0)
			{
				//
				// Shippers Row not found
				//
				return false;
			}

			ShippersDataSet.ShippersRow ShippersRowCurrent = ShippersDS.Shippers[0];
			ListItem SelectedListItem;
			
			//
			// Populate the Page controls from the DataRow
			//
			ctlShipperID.Text = ShippersRowCurrent.ShipperID.ToString();
			ctlCompanyName.Text = ShippersRowCurrent.CompanyName;
			ctlPhone.Text = (ShippersRowCurrent.IsPhoneNull()) ? string.Empty : ShippersRowCurrent.Phone;
			
			
			return true;
		}
		
		
		/// <summary>
		/// Adds or updates the row in the Database
		/// </summary>
		/// <returns>true on success, false on error</returns>
		private bool SaveData()
		{
			//
			// Check that the Form has passed validation
			//
			Page.Validate();
			
			if (!Page.IsValid)
			{
				// Validation failed
				return false;
			}
			
			ShippersDataSet ShippersDS = new ShippersDataSet();
			IShippersService ShippersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateShippersService();
			ShippersDataSet.ShippersRow ShippersRowCurrent;
			
			
			switch (DataEntryMode)
			{
				case PageDataEntryMode.AddRow:
					//
					// Create a New Row
					//
					ShippersRowCurrent = ShippersDS.Shippers.NewShippersRow();
					break;
					
				case PageDataEntryMode.EditRow:
					//
					// Update existing Row
					//
					if (ShippersLogic.GetByShipperID(ShippersDS, m_ShipperIDCurrent) == 0)
					{
						//
						// Shippers Row not found
						//
						return false;
					}
					else
					{
						ShippersRowCurrent = ShippersDS.Shippers[0];
					}
					break;
					
				default:
					return false;
			}

			//
			// Set the DataRow values from the Page Controls
			//
			
			// CompanyName
			ShippersRowCurrent.CompanyName = ctlCompanyName.Text;
			// Phone
			if (ctlPhone.Text.Length == 0)
			{
				ShippersRowCurrent.SetPhoneNull();
			}
			else
			{
				ShippersRowCurrent.Phone = ctlPhone.Text;
			}
						
			
			if (DataEntryMode == PageDataEntryMode.AddRow)
			{
				//
				// Add the new Row to the DataSet
				//
				ShippersDS.Shippers.Rows.Add(ShippersRowCurrent);
			}

			//
			// Save the changes to the database
			//
			ShippersLogic.UpdateDataSet(ShippersDS);
			
			//
			// Update the primary key values
			//
			m_ShipperIDCurrent = ShippersRowCurrent.ShipperID;
			
			
			return true;
		}
		
		
		#endregion

		
		#region Web Form Designer generated code
		
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.ValidationSummary ctlValidationSummary;
		protected System.Web.UI.WebControls.Button btnOK;
		protected System.Web.UI.WebControls.Button btnApply;
		protected System.Web.UI.WebControls.Button btnCancel;
		protected System.Web.UI.WebControls.Label ctlShipperID;
		protected System.Web.UI.WebControls.TextBox ctlCompanyName;
		protected System.Web.UI.WebControls.TextBox ctlPhone;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
			this.btnApply.Click += new System.EventHandler(this.btnApply_Click);
			this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			
		}
		
		#endregion
	}
}
