using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

using RAD.AppFramework.QueryObjects;

using NorthwindSample.BusinessServiceInterfaces;
using NorthwindSample.Data;
using NorthwindSample.DataRetrieval;
using NorthwindSample.Common;
using NorthwindSample.DatabaseSchema;

namespace NorthwindSample.WebUI
{
	/// <summary>
	/// Searches the Suppliers table
	/// </summary>
	public class Suppliers_Search : SearchPage
	{
		#region Constants



		#endregion


		#region Fields

		

		#endregion


		#region Page Events


		/// <summary>
		/// Event raised when the page is requested
		/// </summary>
		private void Page_Load(object sender, System.EventArgs e)
		{
			// AllowSearchAll = true;

			int CriteriaCount = 0;

			//
			// Load the search criteria from the query string into the controls
			//
			CriteriaCount += LoadSearchString("SupplierID", SupplierID);
			CriteriaCount += LoadSearchString("CompanyName", CompanyName);
			CriteriaCount += LoadSearchString("ContactName", ContactName);
			CriteriaCount += LoadSearchString("ContactTitle", ContactTitle);
			CriteriaCount += LoadSearchString("Address", Address);
			CriteriaCount += LoadSearchString("City", City);
			CriteriaCount += LoadSearchString("Region", Region);
			CriteriaCount += LoadSearchString("PostalCode", PostalCode);
			CriteriaCount += LoadSearchString("Country", Country);
			CriteriaCount += LoadSearchString("Phone", Phone);
			CriteriaCount += LoadSearchString("Fax", Fax);
			CriteriaCount += LoadSearchString("HomePage", HomePage);
			

			if (IsPostBack)
			{
			}
			else
			{
				PageTitle = "Suppliers Search";

				if (CriteriaCount > 0)
				{
					SuppliersGrid.CurrentPageIndex = FirstPage;
					LoadData();
				}
			}
		}

		#endregion


		#region Event Handlers for Controls

		/// <summary>
		/// Event raised when a button is pressed on the grid
		/// </summary>
		private void SuppliersGrid_ItemCommand(object source, DataGridCommandEventArgs e)
		{
			switch (e.CommandName)
			{
				case "Edit":
					Response.Redirect(
						string.Format("Suppliers.aspx?{0}={1}", "SupplierID", SuppliersGrid.DataKeys[e.Item.ItemIndex].ToString())
						);	
					break;
			}
		}

		/// <summary>
		/// Event raised when the next or previous links are clicked on the grid
		/// </summary>
		private void SuppliersGrid_PageIndexChanged(object source, DataGridPageChangedEventArgs e)
		{
			SuppliersGrid.CurrentPageIndex = e.NewPageIndex;

			LoadData();
		}

		/// <summary>
		/// Event raised when a column heading is clicked and sorting is enabled
		/// </summary>
		private void SuppliersGrid_SortCommand(object source, DataGridSortCommandEventArgs e)
		{
			RedirectWithSortExpression(e.SortExpression);
		}

		
		#endregion


		#region Methods - Private

		/// <summary>
		/// Searches the Suppliers table for rows that match 
		/// the criteria entered in the search form
		/// </summary>
		private void LoadData()
		{
			Query m_SuppliersQuery = CommonFactory.CreateQuery();

			AddToQuery(m_SuppliersQuery, SuppliersTable.SupplierID, Comparison.EqualTo, SupplierID);
			AddToQuery(m_SuppliersQuery, SuppliersTable.CompanyName, Comparison.Contains, CompanyName);
			AddToQuery(m_SuppliersQuery, SuppliersTable.ContactName, Comparison.Contains, ContactName);
			AddToQuery(m_SuppliersQuery, SuppliersTable.ContactTitle, Comparison.Contains, ContactTitle);
			AddToQuery(m_SuppliersQuery, SuppliersTable.Address, Comparison.Contains, Address);
			AddToQuery(m_SuppliersQuery, SuppliersTable.City, Comparison.Contains, City);
			AddToQuery(m_SuppliersQuery, SuppliersTable.Region, Comparison.Contains, Region);
			AddToQuery(m_SuppliersQuery, SuppliersTable.PostalCode, Comparison.Contains, PostalCode);
			AddToQuery(m_SuppliersQuery, SuppliersTable.Country, Comparison.Contains, Country);
			AddToQuery(m_SuppliersQuery, SuppliersTable.Phone, Comparison.Contains, Phone);
			AddToQuery(m_SuppliersQuery, SuppliersTable.Fax, Comparison.Contains, Fax);
			AddToQuery(m_SuppliersQuery, SuppliersTable.HomePage, Comparison.Contains, HomePage);
			

			AddSortToQuery(m_SuppliersQuery, typeof(SuppliersTable));
			
			ISuppliersService SuppliersLogic = DataRetrievalFactory.GetDataRetrievalFactory().CreateSuppliersService();
			int ResultCount = SuppliersLogic.GetByQuery(m_SuppliersDataSet, m_SuppliersQuery);

			if (ResultCount > 0)
			{
				lblMessage.Text = string.Format(MatchesFoundMessage, ResultCount);
				SuppliersGrid.DataBind();
			}
			else
			{
				lblMessage.Text = NoMatchesMessage;
			}			
		}


		#endregion


		#region Web Form Designer generated code
		
		protected NorthwindSample.Data.SuppliersDataSet m_SuppliersDataSet;
		protected System.Web.UI.WebControls.Label lblMessage;
		protected System.Web.UI.WebControls.DataGrid SuppliersGrid;
		protected System.Web.UI.HtmlControls.HtmlInputText SupplierID;
		protected System.Web.UI.HtmlControls.HtmlInputText CompanyName;
		protected System.Web.UI.HtmlControls.HtmlInputText ContactName;
		protected System.Web.UI.HtmlControls.HtmlInputText ContactTitle;
		protected System.Web.UI.HtmlControls.HtmlInputText Address;
		protected System.Web.UI.HtmlControls.HtmlInputText City;
		protected System.Web.UI.HtmlControls.HtmlInputText Region;
		protected System.Web.UI.HtmlControls.HtmlInputText PostalCode;
		protected System.Web.UI.HtmlControls.HtmlInputText Country;
		protected System.Web.UI.HtmlControls.HtmlInputText Phone;
		protected System.Web.UI.HtmlControls.HtmlInputText Fax;
		protected System.Web.UI.HtmlControls.HtmlInputText HomePage;
		
		
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.m_SuppliersDataSet = new NorthwindSample.Data.SuppliersDataSet();
			((System.ComponentModel.ISupportInitialize)(this.m_SuppliersDataSet)).BeginInit();
			this.SuppliersGrid.ItemCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.SuppliersGrid_ItemCommand);
			this.SuppliersGrid.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.SuppliersGrid_PageIndexChanged);
			this.SuppliersGrid.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.SuppliersGrid_SortCommand);
			// 
			// m_SuppliersDataSet
			// 
			this.m_SuppliersDataSet.DataSetName = "SuppliersDataSet";
			this.m_SuppliersDataSet.Locale = new System.Globalization.CultureInfo("en-US");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.m_SuppliersDataSet)).EndInit();

		}
		
		#endregion

	}
}
