IF EXISTS( SELECT * FROM sysobjects where id=object_id('ViewOrderDetails') AND xtype='V')
	DROP VIEW ViewOrderDetails
GO

CREATE VIEW ViewOrderDetails
AS
SELECT	
	OrderDetails.OrderID,
	OrderDetails.ProductID,
	Products.ProductName,
	OrderDetails.UnitPrice,
	OrderDetails.Quantity,
	OrderDetails.Discount
FROM	
	[Order Details] AS OrderDetails
INNER JOIN Products
	ON ORderDetails.ProductID = Products.ProductID
GO