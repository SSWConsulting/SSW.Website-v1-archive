Imports DataSets
Imports DataAccess

Public Class OrderDetailsPopupForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents productDiscount As System.Windows.Forms.NumericUpDown
    Friend WithEvents productQuantity As System.Windows.Forms.NumericUpDown
    Friend WithEvents productUnitPrice As System.Windows.Forms.TextBox
    Friend WithEvents productName As System.Windows.Forms.ComboBox
    Friend WithEvents ok As System.Windows.Forms.Button
    Friend WithEvents cancel As System.Windows.Forms.Button
    Friend WithEvents productsList As DataSets.ProductsDataSet
    Friend WithEvents productExtendedPrice As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.productsList = New DataSets.ProductsDataSet
        Me.ok = New System.Windows.Forms.Button
        Me.cancel = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.productExtendedPrice = New System.Windows.Forms.TextBox
        Me.productDiscount = New System.Windows.Forms.NumericUpDown
        Me.productQuantity = New System.Windows.Forms.NumericUpDown
        Me.productUnitPrice = New System.Windows.Forms.TextBox
        Me.productName = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        CType(Me.productsList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.productDiscount, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.productQuantity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'productsList
        '
        Me.productsList.DataSetName = "ProductsDataSet"
        Me.productsList.Locale = New System.Globalization.CultureInfo("en-AU")
        '
        'ok
        '
        Me.ok.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.ok.Location = New System.Drawing.Point(200, 196)
        Me.ok.Name = "ok"
        Me.ok.TabIndex = 5
        Me.ok.Text = "&OK"
        '
        'cancel
        '
        Me.cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cancel.Location = New System.Drawing.Point(284, 196)
        Me.cancel.Name = "cancel"
        Me.cancel.TabIndex = 6
        Me.cancel.Text = "&Cancel"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.productExtendedPrice)
        Me.GroupBox1.Controls.Add(Me.productDiscount)
        Me.GroupBox1.Controls.Add(Me.productQuantity)
        Me.GroupBox1.Controls.Add(Me.productUnitPrice)
        Me.GroupBox1.Controls.Add(Me.productName)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(4, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(356, 184)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Line Item Details"
        '
        'productExtendedPrice
        '
        Me.productExtendedPrice.Location = New System.Drawing.Point(108, 132)
        Me.productExtendedPrice.Name = "productExtendedPrice"
        Me.productExtendedPrice.ReadOnly = True
        Me.productExtendedPrice.TabIndex = 15
        Me.productExtendedPrice.Text = ""
        '
        'productDiscount
        '
        Me.productDiscount.Location = New System.Drawing.Point(108, 104)
        Me.productDiscount.Name = "productDiscount"
        Me.productDiscount.Size = New System.Drawing.Size(44, 20)
        Me.productDiscount.TabIndex = 8
        '
        'productQuantity
        '
        Me.productQuantity.Location = New System.Drawing.Point(108, 76)
        Me.productQuantity.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.productQuantity.Name = "productQuantity"
        Me.productQuantity.Size = New System.Drawing.Size(44, 20)
        Me.productQuantity.TabIndex = 7
        Me.productQuantity.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'productUnitPrice
        '
        Me.productUnitPrice.Location = New System.Drawing.Point(108, 48)
        Me.productUnitPrice.Name = "productUnitPrice"
        Me.productUnitPrice.TabIndex = 6
        Me.productUnitPrice.Text = ""
        '
        'productName
        '
        Me.productName.DataSource = Me.productsList.Products
        Me.productName.DisplayMember = "ProductName"
        Me.productName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.productName.Location = New System.Drawing.Point(108, 20)
        Me.productName.Name = "productName"
        Me.productName.Size = New System.Drawing.Size(236, 21)
        Me.productName.TabIndex = 5
        Me.productName.ValueMember = "ProductID"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(20, 136)
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "Extended Price:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(20, 108)
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "Discount (%):"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(20, 80)
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Quantity:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(20, 52)
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Unit Price:"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(20, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "Product:"
        '
        'OrderDetailsPopupForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(364, 225)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cancel)
        Me.Controls.Add(Me.ok)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Name = "OrderDetailsPopupForm"
        Me.Text = "Order Details"
        CType(Me.productsList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.productDiscount, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.productQuantity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private _orderItem As OrdersDataSet.Order_DetailsRow

    Public Sub New(ByVal orderItem As OrdersDataSet.Order_DetailsRow)
        Me.New()
        _orderItem = orderItem
    End Sub

    Private Sub OrderDetailsPopupForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim productsDA As New ProductsDataAdapter
        productsDA.Adapter.Fill(productsList)

        ' Before a new row is added to a dataset, its state is "detached".
        ' If the state is NOT detached, then it is an existing row and
        ' is being edited.
        ' The next block checks the state, and if not detached, then the
        ' form is populated with the contents of the current row.
        If Not _orderItem.RowState = DataRowState.Detached Then
            Me.productName.SelectedIndex = Me.productName.FindString(_orderItem.ProductName)
            Me.productUnitPrice.Text = Convert.ToDecimal(_orderItem.UnitPrice).ToString
            Me.productQuantity.Value = _orderItem.Quantity
            Me.productDiscount.Value = Convert.ToDecimal(_orderItem.Discount * 100)
            Me.productExtendedPrice.Text = _orderItem.ExtendedPrice.ToString("c")
            Me.productUnitPrice.Text = FormatCurrency(Me.productUnitPrice.Text)
            Me.productExtendedPrice.Text = CalculateExtendedPrice()
        Else
            Me.productName.SelectedIndex = -1
        End If
    End Sub

    Function GetUnitPrice() As String
        Dim productItem As ProductsDataSet.ProductsRow = productsList.Products.FindByProductID(Convert.ToInt32(Me.productName.SelectedValue))
        Return productItem.UnitPrice.ToString("c")
    End Function

    Function CalculateExtendedPrice() As String
        Dim unitPrice As Decimal
        If Not Me.productUnitPrice.Text = "" Then
            unitPrice = Decimal.Parse(Me.productUnitPrice.Text, Globalization.NumberStyles.Currency)
        Else
            unitPrice = 0
        End If
        Dim quantity As Decimal = Me.productQuantity.Value
        Dim discount As Decimal = Me.productDiscount.Value
        Dim extendedPrice As Decimal = unitPrice * quantity * (1 - (discount / 100))
        Return extendedPrice.ToString("c")
    End Function

    Private Sub productName_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles productName.SelectedIndexChanged
        If Not Me.productName.SelectedIndex = -1 Then
            Me.productUnitPrice.Text = GetUnitPrice()
            Me.productExtendedPrice.Text = CalculateExtendedPrice()
        End If
    End Sub

    Function FormatCurrency(ByVal value As String) As String
        Dim currencyValue As Decimal = Decimal.Parse(value, Globalization.NumberStyles.Currency)
        Return currencyValue.ToString("c")
    End Function

    Private Sub productUnitPrice_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles productUnitPrice.Leave
        If System.Text.RegularExpressions.Regex.IsMatch(Me.productUnitPrice.Text, "^\$?([0-9]{1,3},([0-9]{3},)*[0-9]{3}|[0-9]+)(.[0-9]{1,2})?$") Then
            Me.productUnitPrice.Text = FormatCurrency(Me.productUnitPrice.Text)
            Me.productExtendedPrice.Text = CalculateExtendedPrice()
        Else
            MessageBox.Show("The text you entered is invalid. Please enter a number between 1 and 1000.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            productUnitPrice.Focus()
        End If
    End Sub

    Private Sub productQuantity_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles productQuantity.ValueChanged, productQuantity.Leave
        Me.productExtendedPrice.Text = CalculateExtendedPrice()
    End Sub

    Private Sub productDiscount_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles productDiscount.ValueChanged, productDiscount.Leave
        Me.productExtendedPrice.Text = CalculateExtendedPrice()
    End Sub

    Private Sub ok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ok.Click
        ' Set the values in the row to the values entered by the user
        _orderItem.ProductName = Me.productName.Text
        _orderItem.ProductID = Convert.ToInt32(Me.productName.SelectedValue)
        _orderItem.UnitPrice = Decimal.Parse(Me.productUnitPrice.Text, Globalization.NumberStyles.Currency)
        _orderItem.Quantity = Convert.ToInt16(Me.productQuantity.Value)
        _orderItem.Discount = Me.productDiscount.Value / 100
        _orderItem.ExtendedPrice = Decimal.Parse(Me.productExtendedPrice.Text, Globalization.NumberStyles.Currency)
    End Sub

End Class