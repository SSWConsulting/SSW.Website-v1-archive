Imports DataSets
Imports DataAccess
Imports System.Data.SqlClient
Imports System.Configuration

Public Class OrdersForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        startLoadTime = DateTime.Now

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents OrderDetails As System.Windows.Forms.DataGridTableStyle
    Friend WithEvents OrderID As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents ProductID As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents Product As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents UnitPrice As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents Quantity As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents Discount As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents ExtendedPrice As System.Windows.Forms.DataGridTextBoxColumn
    Friend WithEvents orderSalesperson As System.Windows.Forms.ComboBox
    Friend WithEvents orderShipVia As System.Windows.Forms.ComboBox
    Friend WithEvents orderedDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents requiredDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents shippedDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents orderItems As System.Windows.Forms.DataGrid
    Friend WithEvents freight As System.Windows.Forms.TextBox
    Friend WithEvents addItem As System.Windows.Forms.Button
    Friend WithEvents editItem As System.Windows.Forms.Button
    Friend WithEvents deleteItem As System.Windows.Forms.Button
    Friend WithEvents firstRecord As System.Windows.Forms.Button
    Friend WithEvents previousRecord As System.Windows.Forms.Button
    Friend WithEvents nextRecord As System.Windows.Forms.Button
    Friend WithEvents lastRecord As System.Windows.Forms.Button
    Friend WithEvents newRecord As System.Windows.Forms.Button
    Friend WithEvents recordNumber As System.Windows.Forms.TextBox
    Friend WithEvents totalRecords As System.Windows.Forms.Label
    Friend WithEvents shipName As System.Windows.Forms.TextBox
    Friend WithEvents shipAddress As System.Windows.Forms.TextBox
    Friend WithEvents shipCity As System.Windows.Forms.TextBox
    Friend WithEvents shipRegion As System.Windows.Forms.TextBox
    Friend WithEvents shipPostalCode As System.Windows.Forms.TextBox
    Friend WithEvents shipCountry As System.Windows.Forms.TextBox
    Friend WithEvents billName As System.Windows.Forms.ComboBox
    Friend WithEvents ordersList As DataSets.OrdersDataSet
    Friend WithEvents customersList As DataSets.CustomersDataSet
    Friend WithEvents employeesList As DataSets.EmployeesDataSet
    Friend WithEvents shippersList As DataSets.ShippersDataSet
    Friend WithEvents productsList As DataSets.ProductsDataSet
    Friend WithEvents subtotal As System.Windows.Forms.TextBox
    Friend WithEvents total As System.Windows.Forms.TextBox
    Friend WithEvents billAddress As System.Windows.Forms.TextBox
    Friend WithEvents billCity As System.Windows.Forms.TextBox
    Friend WithEvents billRegion As System.Windows.Forms.TextBox
    Friend WithEvents billPostalCode As System.Windows.Forms.TextBox
    Friend WithEvents billCountry As System.Windows.Forms.TextBox
    Friend WithEvents orderOrderID As System.Windows.Forms.TextBox
    Friend WithEvents ordersStatus As System.Windows.Forms.StatusBar
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.billName = New System.Windows.Forms.ComboBox
        Me.ordersList = New DataSets.OrdersDataSet
        Me.customersList = New DataSets.CustomersDataSet
        Me.shipName = New System.Windows.Forms.TextBox
        Me.shipAddress = New System.Windows.Forms.TextBox
        Me.shipCity = New System.Windows.Forms.TextBox
        Me.shipRegion = New System.Windows.Forms.TextBox
        Me.shipPostalCode = New System.Windows.Forms.TextBox
        Me.shipCountry = New System.Windows.Forms.TextBox
        Me.orderSalesperson = New System.Windows.Forms.ComboBox
        Me.employeesList = New DataSets.EmployeesDataSet
        Me.orderShipVia = New System.Windows.Forms.ComboBox
        Me.shippersList = New DataSets.ShippersDataSet
        Me.orderedDate = New System.Windows.Forms.DateTimePicker
        Me.requiredDate = New System.Windows.Forms.DateTimePicker
        Me.shippedDate = New System.Windows.Forms.DateTimePicker
        Me.orderItems = New System.Windows.Forms.DataGrid
        Me.OrderDetails = New System.Windows.Forms.DataGridTableStyle
        Me.OrderID = New System.Windows.Forms.DataGridTextBoxColumn
        Me.ProductID = New System.Windows.Forms.DataGridTextBoxColumn
        Me.Product = New System.Windows.Forms.DataGridTextBoxColumn
        Me.UnitPrice = New System.Windows.Forms.DataGridTextBoxColumn
        Me.Quantity = New System.Windows.Forms.DataGridTextBoxColumn
        Me.Discount = New System.Windows.Forms.DataGridTextBoxColumn
        Me.ExtendedPrice = New System.Windows.Forms.DataGridTextBoxColumn
        Me.freight = New System.Windows.Forms.TextBox
        Me.addItem = New System.Windows.Forms.Button
        Me.editItem = New System.Windows.Forms.Button
        Me.deleteItem = New System.Windows.Forms.Button
        Me.btnOK = New System.Windows.Forms.Button
        Me.firstRecord = New System.Windows.Forms.Button
        Me.previousRecord = New System.Windows.Forms.Button
        Me.nextRecord = New System.Windows.Forms.Button
        Me.lastRecord = New System.Windows.Forms.Button
        Me.newRecord = New System.Windows.Forms.Button
        Me.recordNumber = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.totalRecords = New System.Windows.Forms.Label
        Me.productsList = New DataSets.ProductsDataSet
        Me.subtotal = New System.Windows.Forms.TextBox
        Me.total = New System.Windows.Forms.TextBox
        Me.billAddress = New System.Windows.Forms.TextBox
        Me.billCity = New System.Windows.Forms.TextBox
        Me.billRegion = New System.Windows.Forms.TextBox
        Me.billPostalCode = New System.Windows.Forms.TextBox
        Me.billCountry = New System.Windows.Forms.TextBox
        Me.orderOrderID = New System.Windows.Forms.TextBox
        Me.ordersStatus = New System.Windows.Forms.StatusBar
        Me.btnCancel = New System.Windows.Forms.Button
        CType(Me.ordersList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.customersList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.employeesList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.shippersList, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.orderItems, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.productsList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'billName
        '
        Me.billName.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.ordersList, "Orders.CustomerID"))
        Me.billName.DataSource = Me.customersList.Customers
        Me.billName.DisplayMember = "CompanyName"
        Me.billName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.billName.Location = New System.Drawing.Point(60, 4)
        Me.billName.Name = "billName"
        Me.billName.Size = New System.Drawing.Size(228, 21)
        Me.billName.TabIndex = 1
        Me.billName.ValueMember = "CustomerID"
        '
        'ordersList
        '
        Me.ordersList.DataSetName = "OrdersDataSet"
        Me.ordersList.Locale = New System.Globalization.CultureInfo("en-AU")
        '
        'customersList
        '
        Me.customersList.DataSetName = "CustomersDataSet"
        Me.customersList.Locale = New System.Globalization.CultureInfo("en-AU")
        '
        'shipName
        '
        Me.shipName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.ShipName"))
        Me.shipName.Location = New System.Drawing.Point(356, 4)
        Me.shipName.Name = "shipName"
        Me.shipName.Size = New System.Drawing.Size(228, 20)
        Me.shipName.TabIndex = 2
        Me.shipName.Text = ""
        '
        'shipAddress
        '
        Me.shipAddress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.ShipAddress"))
        Me.shipAddress.Location = New System.Drawing.Point(356, 28)
        Me.shipAddress.Multiline = True
        Me.shipAddress.Name = "shipAddress"
        Me.shipAddress.Size = New System.Drawing.Size(228, 32)
        Me.shipAddress.TabIndex = 3
        Me.shipAddress.Text = ""
        '
        'shipCity
        '
        Me.shipCity.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.ShipCity"))
        Me.shipCity.Location = New System.Drawing.Point(356, 64)
        Me.shipCity.Name = "shipCity"
        Me.shipCity.Size = New System.Drawing.Size(80, 20)
        Me.shipCity.TabIndex = 4
        Me.shipCity.Text = ""
        '
        'shipRegion
        '
        Me.shipRegion.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.ShipRegion"))
        Me.shipRegion.Location = New System.Drawing.Point(440, 64)
        Me.shipRegion.Name = "shipRegion"
        Me.shipRegion.Size = New System.Drawing.Size(76, 20)
        Me.shipRegion.TabIndex = 5
        Me.shipRegion.Text = ""
        '
        'shipPostalCode
        '
        Me.shipPostalCode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.ShipPostalCode"))
        Me.shipPostalCode.Location = New System.Drawing.Point(520, 64)
        Me.shipPostalCode.Name = "shipPostalCode"
        Me.shipPostalCode.Size = New System.Drawing.Size(64, 20)
        Me.shipPostalCode.TabIndex = 6
        Me.shipPostalCode.Text = ""
        '
        'shipCountry
        '
        Me.shipCountry.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.ShipCountry"))
        Me.shipCountry.Location = New System.Drawing.Point(472, 88)
        Me.shipCountry.Name = "shipCountry"
        Me.shipCountry.Size = New System.Drawing.Size(112, 20)
        Me.shipCountry.TabIndex = 7
        Me.shipCountry.Text = ""
        '
        'orderSalesperson
        '
        Me.orderSalesperson.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.ordersList, "Orders.EmployeeID"))
        Me.orderSalesperson.DataSource = Me.employeesList.Employees
        Me.orderSalesperson.DisplayMember = "FullName"
        Me.orderSalesperson.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.orderSalesperson.Location = New System.Drawing.Point(88, 112)
        Me.orderSalesperson.Name = "orderSalesperson"
        Me.orderSalesperson.Size = New System.Drawing.Size(176, 21)
        Me.orderSalesperson.TabIndex = 8
        Me.orderSalesperson.ValueMember = "EmployeeID"
        '
        'employeesList
        '
        Me.employeesList.DataSetName = "EmployeesDataSet"
        Me.employeesList.Locale = New System.Globalization.CultureInfo("en-AU")
        '
        'orderShipVia
        '
        Me.orderShipVia.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.ordersList, "Orders.ShipVia"))
        Me.orderShipVia.DataSource = Me.shippersList.Shippers
        Me.orderShipVia.DisplayMember = "CompanyName"
        Me.orderShipVia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.orderShipVia.Location = New System.Drawing.Point(356, 112)
        Me.orderShipVia.Name = "orderShipVia"
        Me.orderShipVia.Size = New System.Drawing.Size(176, 21)
        Me.orderShipVia.TabIndex = 9
        Me.orderShipVia.ValueMember = "ShipperID"
        '
        'shippersList
        '
        Me.shippersList.DataSetName = "ShippersDataSet"
        Me.shippersList.Locale = New System.Globalization.CultureInfo("en-AU")
        '
        'orderedDate
        '
        Me.orderedDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.OrderDate"))
        Me.orderedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.orderedDate.Location = New System.Drawing.Point(200, 136)
        Me.orderedDate.Name = "orderedDate"
        Me.orderedDate.Size = New System.Drawing.Size(84, 20)
        Me.orderedDate.TabIndex = 10
        '
        'requiredDate
        '
        Me.requiredDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.RequiredDate"))
        Me.requiredDate.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.requiredDate.Location = New System.Drawing.Point(356, 136)
        Me.requiredDate.Name = "requiredDate"
        Me.requiredDate.Size = New System.Drawing.Size(84, 20)
        Me.requiredDate.TabIndex = 11
        '
        'shippedDate
        '
        Me.shippedDate.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.ShippedDate"))
        Me.shippedDate.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.shippedDate.Location = New System.Drawing.Point(500, 136)
        Me.shippedDate.Name = "shippedDate"
        Me.shippedDate.Size = New System.Drawing.Size(84, 20)
        Me.shippedDate.TabIndex = 12
        '
        'orderItems
        '
        Me.orderItems.DataMember = "Orders.OrdersOrder_Details"
        Me.orderItems.DataSource = Me.ordersList
        Me.orderItems.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.orderItems.Location = New System.Drawing.Point(12, 160)
        Me.orderItems.Name = "orderItems"
        Me.orderItems.ReadOnly = True
        Me.orderItems.Size = New System.Drawing.Size(572, 96)
        Me.orderItems.TabIndex = 13
        Me.orderItems.TableStyles.AddRange(New System.Windows.Forms.DataGridTableStyle() {Me.OrderDetails})
        '
        'OrderDetails
        '
        Me.OrderDetails.AllowSorting = False
        Me.OrderDetails.DataGrid = Me.orderItems
        Me.OrderDetails.GridColumnStyles.AddRange(New System.Windows.Forms.DataGridColumnStyle() {Me.OrderID, Me.ProductID, Me.Product, Me.UnitPrice, Me.Quantity, Me.Discount, Me.ExtendedPrice})
        Me.OrderDetails.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.OrderDetails.MappingName = "Order Details"
        '
        'OrderID
        '
        Me.OrderID.Format = ""
        Me.OrderID.FormatInfo = Nothing
        Me.OrderID.MappingName = "OrderID"
        Me.OrderID.Width = 0
        '
        'ProductID
        '
        Me.ProductID.Format = ""
        Me.ProductID.FormatInfo = Nothing
        Me.ProductID.MappingName = "ProductID"
        Me.ProductID.Width = 0
        '
        'Product
        '
        Me.Product.Format = ""
        Me.Product.FormatInfo = Nothing
        Me.Product.HeaderText = "Product:"
        Me.Product.MappingName = "ProductName"
        Me.Product.Width = 195
        '
        'UnitPrice
        '
        Me.UnitPrice.Format = "C"
        Me.UnitPrice.FormatInfo = Nothing
        Me.UnitPrice.HeaderText = "Unit Price:"
        Me.UnitPrice.MappingName = "UnitPrice"
        Me.UnitPrice.NullText = "$0.00"
        Me.UnitPrice.Width = 75
        '
        'Quantity
        '
        Me.Quantity.Format = ""
        Me.Quantity.FormatInfo = Nothing
        Me.Quantity.HeaderText = "Quantity:"
        Me.Quantity.MappingName = "Quantity"
        Me.Quantity.NullText = "0"
        Me.Quantity.Width = 75
        '
        'Discount
        '
        Me.Discount.Format = "P"
        Me.Discount.FormatInfo = Nothing
        Me.Discount.HeaderText = "Discount:"
        Me.Discount.MappingName = "Discount"
        Me.Discount.NullText = "0.00 %"
        Me.Discount.Width = 75
        '
        'ExtendedPrice
        '
        Me.ExtendedPrice.Format = "C"
        Me.ExtendedPrice.FormatInfo = Nothing
        Me.ExtendedPrice.HeaderText = "Extended Price:"
        Me.ExtendedPrice.MappingName = "ExtendedPrice"
        Me.ExtendedPrice.NullText = "$0.00"
        Me.ExtendedPrice.Width = 97
        '
        'freight
        '
        Me.freight.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.Freight"))
        Me.freight.Location = New System.Drawing.Point(472, 284)
        Me.freight.Name = "freight"
        Me.freight.Size = New System.Drawing.Size(96, 20)
        Me.freight.TabIndex = 14
        Me.freight.Text = ""
        Me.freight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'addItem
        '
        Me.addItem.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.addItem.Location = New System.Drawing.Point(12, 260)
        Me.addItem.Name = "addItem"
        Me.addItem.TabIndex = 23
        Me.addItem.Text = "&Add Item"
        '
        'editItem
        '
        Me.editItem.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.editItem.Location = New System.Drawing.Point(92, 260)
        Me.editItem.Name = "editItem"
        Me.editItem.TabIndex = 24
        Me.editItem.Text = "&Edit Item"
        '
        'deleteItem
        '
        Me.deleteItem.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.deleteItem.Location = New System.Drawing.Point(172, 260)
        Me.deleteItem.Name = "deleteItem"
        Me.deleteItem.Size = New System.Drawing.Size(80, 23)
        Me.deleteItem.TabIndex = 25
        Me.deleteItem.Text = "&Delete Item"
        '
        'btnOK
        '
        Me.btnOK.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnOK.Location = New System.Drawing.Point(432, 336)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(72, 23)
        Me.btnOK.TabIndex = 26
        Me.btnOK.Text = "&Save"
        '
        'firstRecord
        '
        Me.firstRecord.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.firstRecord.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.firstRecord.Location = New System.Drawing.Point(48, 344)
        Me.firstRecord.Name = "firstRecord"
        Me.firstRecord.Size = New System.Drawing.Size(20, 20)
        Me.firstRecord.TabIndex = 27
        Me.firstRecord.Text = "|<"
        '
        'previousRecord
        '
        Me.previousRecord.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.previousRecord.Location = New System.Drawing.Point(68, 344)
        Me.previousRecord.Name = "previousRecord"
        Me.previousRecord.Size = New System.Drawing.Size(20, 20)
        Me.previousRecord.TabIndex = 28
        Me.previousRecord.Text = "&<"
        '
        'nextRecord
        '
        Me.nextRecord.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.nextRecord.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.nextRecord.Location = New System.Drawing.Point(160, 344)
        Me.nextRecord.Name = "nextRecord"
        Me.nextRecord.Size = New System.Drawing.Size(20, 20)
        Me.nextRecord.TabIndex = 29
        Me.nextRecord.Text = "&>"
        '
        'lastRecord
        '
        Me.lastRecord.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.lastRecord.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lastRecord.Location = New System.Drawing.Point(180, 344)
        Me.lastRecord.Name = "lastRecord"
        Me.lastRecord.Size = New System.Drawing.Size(20, 20)
        Me.lastRecord.TabIndex = 30
        Me.lastRecord.Text = ">|"
        '
        'newRecord
        '
        Me.newRecord.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.newRecord.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.newRecord.Location = New System.Drawing.Point(200, 344)
        Me.newRecord.Name = "newRecord"
        Me.newRecord.Size = New System.Drawing.Size(20, 20)
        Me.newRecord.TabIndex = 31
        Me.newRecord.Text = ">*"
        '
        'recordNumber
        '
        Me.recordNumber.Location = New System.Drawing.Point(92, 344)
        Me.recordNumber.Name = "recordNumber"
        Me.recordNumber.Size = New System.Drawing.Size(64, 20)
        Me.recordNumber.TabIndex = 32
        Me.recordNumber.Text = "1"
        Me.recordNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 16)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "Bill To:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 116)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 16)
        Me.Label2.TabIndex = 34
        Me.Label2.Text = "Salesperson:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 140)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 16)
        Me.Label3.TabIndex = 35
        Me.Label3.Text = "Order ID:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(148, 140)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 16)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "Ordered:"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(296, 8)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 16)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "Ship To:"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(296, 116)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 16)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "Ship Via:"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(300, 140)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(56, 16)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "Required:"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(448, 140)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(52, 16)
        Me.Label8.TabIndex = 40
        Me.Label8.Text = "Shipped:"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(412, 264)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 16)
        Me.Label9.TabIndex = 41
        Me.Label9.Text = "Subtotal:"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(412, 288)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(52, 16)
        Me.Label10.TabIndex = 42
        Me.Label10.Tag = ""
        Me.Label10.Text = "Freight:"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(412, 312)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(52, 16)
        Me.Label11.TabIndex = 43
        Me.Label11.Text = "Total:"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(0, 348)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(44, 16)
        Me.Label12.TabIndex = 44
        Me.Label12.Text = "Record:"
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(224, 348)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(16, 16)
        Me.Label13.TabIndex = 45
        Me.Label13.Text = "of"
        '
        'totalRecords
        '
        Me.totalRecords.Location = New System.Drawing.Point(240, 348)
        Me.totalRecords.Name = "totalRecords"
        Me.totalRecords.Size = New System.Drawing.Size(68, 16)
        Me.totalRecords.TabIndex = 46
        '
        'productsList
        '
        Me.productsList.DataSetName = "ProductsDataSet"
        Me.productsList.Locale = New System.Globalization.CultureInfo("en-AU")
        '
        'subtotal
        '
        Me.subtotal.Location = New System.Drawing.Point(472, 260)
        Me.subtotal.Name = "subtotal"
        Me.subtotal.ReadOnly = True
        Me.subtotal.Size = New System.Drawing.Size(96, 20)
        Me.subtotal.TabIndex = 47
        Me.subtotal.Text = ""
        Me.subtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'total
        '
        Me.total.Location = New System.Drawing.Point(472, 308)
        Me.total.Name = "total"
        Me.total.ReadOnly = True
        Me.total.Size = New System.Drawing.Size(96, 20)
        Me.total.TabIndex = 48
        Me.total.Text = ""
        Me.total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'billAddress
        '
        Me.billAddress.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.customersList, "Customers.Address"))
        Me.billAddress.Location = New System.Drawing.Point(60, 28)
        Me.billAddress.Multiline = True
        Me.billAddress.Name = "billAddress"
        Me.billAddress.ReadOnly = True
        Me.billAddress.Size = New System.Drawing.Size(228, 32)
        Me.billAddress.TabIndex = 49
        Me.billAddress.Text = ""
        '
        'billCity
        '
        Me.billCity.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.customersList, "Customers.City"))
        Me.billCity.Location = New System.Drawing.Point(60, 64)
        Me.billCity.Name = "billCity"
        Me.billCity.ReadOnly = True
        Me.billCity.Size = New System.Drawing.Size(80, 20)
        Me.billCity.TabIndex = 50
        Me.billCity.Text = ""
        '
        'billRegion
        '
        Me.billRegion.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.customersList, "Customers.Region"))
        Me.billRegion.Location = New System.Drawing.Point(144, 64)
        Me.billRegion.Name = "billRegion"
        Me.billRegion.ReadOnly = True
        Me.billRegion.Size = New System.Drawing.Size(76, 20)
        Me.billRegion.TabIndex = 51
        Me.billRegion.Text = ""
        '
        'billPostalCode
        '
        Me.billPostalCode.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.customersList, "Customers.PostalCode"))
        Me.billPostalCode.Location = New System.Drawing.Point(224, 64)
        Me.billPostalCode.Name = "billPostalCode"
        Me.billPostalCode.ReadOnly = True
        Me.billPostalCode.Size = New System.Drawing.Size(64, 20)
        Me.billPostalCode.TabIndex = 52
        Me.billPostalCode.Text = ""
        '
        'billCountry
        '
        Me.billCountry.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.customersList, "Customers.Country"))
        Me.billCountry.Location = New System.Drawing.Point(176, 88)
        Me.billCountry.Name = "billCountry"
        Me.billCountry.ReadOnly = True
        Me.billCountry.Size = New System.Drawing.Size(112, 20)
        Me.billCountry.TabIndex = 53
        Me.billCountry.Text = ""
        '
        'orderOrderID
        '
        Me.orderOrderID.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ordersList, "Orders.OrderID"))
        Me.orderOrderID.Location = New System.Drawing.Point(64, 136)
        Me.orderOrderID.Name = "orderOrderID"
        Me.orderOrderID.ReadOnly = True
        Me.orderOrderID.Size = New System.Drawing.Size(48, 20)
        Me.orderOrderID.TabIndex = 54
        Me.orderOrderID.Text = ""
        '
        'ordersStatus
        '
        Me.ordersStatus.Location = New System.Drawing.Point(0, 369)
        Me.ordersStatus.Name = "ordersStatus"
        Me.ordersStatus.ShowPanels = True
        Me.ordersStatus.Size = New System.Drawing.Size(596, 22)
        Me.ordersStatus.SizingGrip = False
        Me.ordersStatus.TabIndex = 55
        '
        'btnCancel
        '
        Me.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnCancel.Location = New System.Drawing.Point(508, 336)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.TabIndex = 56
        Me.btnCancel.Text = "&Close"
        '
        'OrdersForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.btnCancel
        Me.ClientSize = New System.Drawing.Size(596, 391)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.ordersStatus)
        Me.Controls.Add(Me.orderOrderID)
        Me.Controls.Add(Me.billCountry)
        Me.Controls.Add(Me.billPostalCode)
        Me.Controls.Add(Me.billRegion)
        Me.Controls.Add(Me.billCity)
        Me.Controls.Add(Me.billAddress)
        Me.Controls.Add(Me.total)
        Me.Controls.Add(Me.subtotal)
        Me.Controls.Add(Me.recordNumber)
        Me.Controls.Add(Me.freight)
        Me.Controls.Add(Me.shipCountry)
        Me.Controls.Add(Me.shipPostalCode)
        Me.Controls.Add(Me.shipRegion)
        Me.Controls.Add(Me.shipCity)
        Me.Controls.Add(Me.shipAddress)
        Me.Controls.Add(Me.shipName)
        Me.Controls.Add(Me.totalRecords)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.newRecord)
        Me.Controls.Add(Me.lastRecord)
        Me.Controls.Add(Me.nextRecord)
        Me.Controls.Add(Me.previousRecord)
        Me.Controls.Add(Me.firstRecord)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.deleteItem)
        Me.Controls.Add(Me.editItem)
        Me.Controls.Add(Me.addItem)
        Me.Controls.Add(Me.orderItems)
        Me.Controls.Add(Me.shippedDate)
        Me.Controls.Add(Me.requiredDate)
        Me.Controls.Add(Me.orderedDate)
        Me.Controls.Add(Me.orderShipVia)
        Me.Controls.Add(Me.orderSalesperson)
        Me.Controls.Add(Me.billName)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "OrdersForm"
        Me.Text = "Orders"
        CType(Me.ordersList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.customersList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.employeesList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.shippersList, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.orderItems, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.productsList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private startLoadTime As DateTime

    Private WithEvents _ordersManager As BindingManagerBase
    Private _movingRecords As Boolean
    Private _business As New Business.Orders


    Private _ordersDA As New OrdersDataAdapter
    Private _orderDetailsDA As New OrderDetailsDataAdapter

    Private _filter As String

    Public Property Filter() As String
        Get
            Return _filter
        End Get
        Set(ByVal Value As String)
            _filter = Value
        End Set
    End Property

    Private Sub OrdersForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        AddHandler Me.freight.DataBindings("Text").Format, AddressOf Me.FormatCurrency
        AddHandler Me.freight.DataBindings("Text").Parse, AddressOf Me.ParseCurrency

        Dim _customersDA As New CustomersDataAdapter
        Dim _employeesDA As New EmployeesDataAdapter
        Dim _shippersDA As New ShippersDataAdapter

        _customersDA.Adapter.Fill(customersList)
        _employeesDA.Adapter.Fill(employeesList)
        _shippersDA.Adapter.Fill(shippersList)
        If _filter = Nothing Then
            _ordersDA.Adapter.Fill(ordersList)
            _orderDetailsDA.Adapter.Fill(ordersList)
        Else
            Try
                '*** FillByOrderID
                Dim adapter As New SqlDataAdapter("SELECT * FROM Orders WHERE OrderID = " & _filter, ConfigurationSettings.AppSettings("SqlConnection1.ConnectionString"))
                adapter.Fill(Me.ordersList.Orders)
                Dim adapterOD As New SqlDataAdapter("SELECT *, ProductName, [Order Details].UnitPrice * Quantity * (1 - Discount) As ExtendedPrice FROM [Order Details], Products WHERE OrderID = " & _filter & " AND [Order Details].ProductID = Products.ProductID ", ConfigurationSettings.AppSettings("SqlConnection1.ConnectionString"))
                adapterOD.Fill(Me.ordersList.Order_Details)
            Catch ex As Exception
                Debug.Write(ex.Message)
            End Try
        End If
        _ordersManager = BindingContext(ordersList, ordersList.Orders.TableName)

        Me.totalRecords.Text = _ordersManager.Count.ToString()

        CalculateTotals()

        Dim elapsedLoadTime As TimeSpan
        elapsedLoadTime = DateTime.Now.Subtract(startLoadTime)

        Me.ordersStatus.Text = "Load Time: " + elapsedLoadTime.Seconds.ToString + " seconds"

    End Sub

    Private Sub billName_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles billName.SelectedIndexChanged
        ' Updates the "Bill To" details.
        If Not Me.billName.SelectedValue Is Nothing Then
            Dim customerItem As CustomersDataSet.CustomersRow = customersList.Customers.FindByCustomerID(billName.SelectedValue.ToString)
            If Not customerItem.IsAddressNull Then Me.billAddress.Text = customerItem.Address
            If Not customerItem.IsCityNull Then Me.billCity.Text = customerItem.City
            If Not customerItem.IsRegionNull Then Me.billRegion.Text = customerItem.Region
            If Not customerItem.IsPostalCodeNull Then Me.billPostalCode.Text = customerItem.PostalCode
            If Not customerItem.IsCountryNull Then Me.billCountry.Text = customerItem.Country
        End If

        ' Updates the "Ship To" details.
        If Not _movingRecords Then
            Me.shipName.Text = Me.billName.Text
            Me.shipAddress.Text = Me.billAddress.Text
            Me.shipCity.Text = Me.billCity.Text
            Me.shipRegion.Text = Me.billRegion.Text
            Me.shipPostalCode.Text = Me.billPostalCode.Text
            Me.shipCountry.Text = Me.billCountry.Text
        End If
    End Sub

    Private Sub firstRecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles firstRecord.Click
        ' Check that the user isn't on the first record.
        If Not Me._ordersManager.Position = 0 Then
            _movingRecords = True
            Me._ordersManager.Position = 0
            _movingRecords = False
        End If
    End Sub

    Private Sub previousRecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles previousRecord.Click
        ' Check that the user isn't on the first record.
        If Not Me._ordersManager.Position = 0 Then
            _movingRecords = True
            Me._ordersManager.Position -= 1
            _movingRecords = False
        End If
    End Sub

    Private Sub nextRecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles nextRecord.Click
        ' Check that the user isn't on the last record.    
        If Not Me._ordersManager.Position = Me._ordersManager.Count - 1 Then
            _movingRecords = True
            Me._ordersManager.Position += 1
            _movingRecords = False
        End If
    End Sub

    Private Sub lastRecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lastRecord.Click
        ' Check that the user isn't on the last record.
        If Not Me._ordersManager.Position = Me._ordersManager.Count - 1 Then
            _movingRecords = True
            Me._ordersManager.Position = Me._ordersManager.Count
            _movingRecords = False
        End If
    End Sub

    '
    ' Checks to see if enter key is pressed and then moves to the
    ' appropriate order by changing the binding manager position.
    '
    Private Sub recordNumber_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles recordNumber.KeyPress
        If Char.IsWhiteSpace(e.KeyChar) Then
            _movingRecords = True
            Me._ordersManager.Position = CInt(Me.recordNumber.Text) - 1
            _movingRecords = False
        End If
    End Sub

    Private Sub _ordersManager_PositionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _ordersManager.PositionChanged
        Me.recordNumber.Text = (Me._ordersManager.Position + 1).ToString
        CalculateTotals()
    End Sub

    Private Sub FormatCurrency(ByVal sender As Object, ByVal e As ConvertEventArgs)
        If TypeOf e.Value Is Decimal Then
            e.Value = CType(e.Value, Decimal).ToString("c")
        End If
    End Sub

    Private Sub ParseCurrency(ByVal sender As Object, ByVal e As ConvertEventArgs)
        If e.DesiredType Is GetType(Decimal) Then
            e.Value = Decimal.Parse(e.Value.ToString(), Globalization.NumberStyles.Currency)
        End If
    End Sub

    Private Sub CalculateTotals()
        Dim orderItem As OrdersDataSet.OrdersRow = CType(CType(_ordersManager.Current, DataRowView).Row, OrdersDataSet.OrdersRow)

        Dim subtotal As Decimal = _business.CalculateSubtotal(orderItem.GetOrder_DetailsRows())
        Dim freight As Decimal = 0

        If Not Me.freight.Text = "" Then
            freight = Decimal.Parse(Me.freight.Text, Globalization.NumberStyles.Currency)
        End If

        Dim total As Decimal = _business.CalculateTotal(subtotal, freight)

        Me.subtotal.Text = subtotal.ToString("c")
        Me.total.Text = total.ToString("c")
    End Sub

    Private Sub freight_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles freight.LostFocus
        CalculateTotals()
    End Sub

    '
    ' Opens the Order Details form and passes a new row so that
    ' it can be edited and then added to the Order Details.
    '
    Private Sub addItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles addItem.Click
        ' Create a new row.
        Dim orderItem As OrdersDataSet.Order_DetailsRow = ordersList.Order_Details.NewOrder_DetailsRow()

        ' Pass the new row to the Order Details form.
        Dim orderDetailsForm As New OrderDetailsPopupForm(orderItem)

        ' Show the Order Details form and return the result.
        Dim result As DialogResult = orderDetailsForm.ShowDialog()

        If result = DialogResult.OK Then
            orderItem.OrderID = CType(CType(Me._ordersManager.Current, DataRowView).Item("OrderID"), Integer)
            ' Add the new row to the DataSet.
            ordersList.Order_Details.AddOrder_DetailsRow(orderItem)
            CalculateTotals()
        ElseIf result = DialogResult.Cancel Then
            ' Delete the new row.
            orderItem.Delete()
        End If
    End Sub

    '
    ' Deletes selected line item.
    '
    Private Sub deleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deleteItem.Click
        If MsgBox("Are you sure you want to delete this record?", MsgBoxStyle.YesNo, Application.ProductName) = MsgBoxResult.Yes Then
            ' Check that there is a row selected to delete.
            If Not Me.orderItems.CurrentRowIndex = -1 Then
                Dim cm As CurrencyManager = CType(BindingContext(ordersList, "Orders.OrdersOrder_Details"), CurrencyManager)

                ' Get the current row.
                Dim orderItem As OrdersDataSet.Order_DetailsRow = CType(CType(cm.Current, DataRowView).Row, OrdersDataSet.Order_DetailsRow)

                ' Delete the current row from the DataSet.
                orderItem.Delete()

                CalculateTotals()
            End If
        End If
    End Sub

    '
    ' Opens the Order Details form and passes the selected row so that
    ' it can be edited and then returned to the Order Details.
    '
    Private Sub editItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles editItem.Click
        ' Check that there is a row to edit.
        If Not BindingContext(ordersList, "Orders.OrdersOrder_Details").Position = -1 Then
            Dim cm As CurrencyManager = CType(BindingContext(ordersList, "Orders.OrdersOrder_Details"), CurrencyManager)

            ' Get the current row.
            Dim orderItem As OrdersDataSet.Order_DetailsRow = CType(CType(cm.Current, DataRowView).Row, OrdersDataSet.Order_DetailsRow)

            ' Pass the current row to the Order Details form.
            Dim orderDetailsForm As New OrderDetailsPopupForm(orderItem)

            ' Show the Order Details form and return the result.
            Dim result As DialogResult = orderDetailsForm.ShowDialog()

            ' Check if the user clicked "OK".
            If result = DialogResult.OK Then
                CalculateTotals()
            End If
        End If
    End Sub

    '
    ' Adds a new Order.
    '
    Private Sub newRecord_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles newRecord.Click
        _movingRecords = True
        Me._ordersManager.EndCurrentEdit()
        Me._ordersManager.AddNew()
        _movingRecords = False

        Dim recordCount As Integer = Convert.ToInt32(Me.totalRecords.Text)
        Me.totalRecords.Text = (recordCount + 1).ToString()

        Me.billAddress.Text = String.Empty
        Me.billCity.Text = String.Empty
        Me.billRegion.Text = String.Empty
        Me.billPostalCode.Text = String.Empty
        Me.billCountry.Text = String.Empty
        Me.subtotal.Text = String.Empty
        Me.total.Text = String.Empty
        Me.billName.SelectedIndex = -1
        Me.orderSalesperson.SelectedIndex = -1
        Me.orderShipVia.SelectedIndex = -1
    End Sub

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOK.Click
        Me._ordersManager.EndCurrentEdit()
        ' Check if changes were made
        If ordersList.HasChanges Then
            Try
                ' Update the Orders table
                _ordersDA.Adapter.Update(ordersList)
                ' Update the Order Details table
                _orderDetailsDA.Adapter.Update(ordersList)
            Catch ex As System.Data.SqlClient.SqlException
                ' Handle errors
                Select Case ex.Number
                    Case 2627
                        MsgBox("The changes could not be saved because they would create duplicate values. Change the data in the fields that contain duplicate data.", MsgBoxStyle.Information, Application.ProductName)
                    Case Else
                        MsgBox("An error has occurred: " + ex.Message, MsgBoxStyle.Information, Application.ProductName)
                End Select
            End Try
        End If
    End Sub

    '
    ' Selects an entire row of the DataGrid corresponding to selected cell.
    '
    Private Sub SelectDataGridRow(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles orderItems.MouseUp
        Dim pt As Point = New Point(e.X, e.Y)
        Dim hti As DataGrid.HitTestInfo = Me.orderItems.HitTest(pt)
        If hti.Type = DataGrid.HitTestType.Cell Then
            Me.orderItems.CurrentCell = New DataGridCell(hti.Row, hti.Column)
            Me.orderItems.Select(hti.Row)
        End If
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub
End Class