Public Class MainSwitchboardForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents exitProgram As System.Windows.Forms.Button
    Friend WithEvents suppliers As System.Windows.Forms.Button
    Friend WithEvents products As System.Windows.Forms.Button
    Friend WithEvents orders As System.Windows.Forms.Button
    Friend WithEvents categories As System.Windows.Forms.Button
    Friend WithEvents printSalesReports As System.Windows.Forms.Button
    Friend WithEvents versionNumber As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnOrdersDoneRight As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MainSwitchboardForm))
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.exitProgram = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.btnOrdersDoneRight = New System.Windows.Forms.Button
        Me.suppliers = New System.Windows.Forms.Button
        Me.products = New System.Windows.Forms.Button
        Me.orders = New System.Windows.Forms.Button
        Me.categories = New System.Windows.Forms.Button
        Me.printSalesReports = New System.Windows.Forms.Button
        Me.versionNumber = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(32, 8)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(160, 152)
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'exitProgram
        '
        Me.exitProgram.Location = New System.Drawing.Point(40, 180)
        Me.exitProgram.Name = "exitProgram"
        Me.exitProgram.Size = New System.Drawing.Size(140, 28)
        Me.exitProgram.TabIndex = 2
        Me.exitProgram.Text = "Exit Program"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnOrdersDoneRight)
        Me.GroupBox1.Controls.Add(Me.suppliers)
        Me.GroupBox1.Controls.Add(Me.products)
        Me.GroupBox1.Controls.Add(Me.orders)
        Me.GroupBox1.Controls.Add(Me.categories)
        Me.GroupBox1.Location = New System.Drawing.Point(204, 20)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(204, 144)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "View Product and Order Information:"
        '
        'btnOrdersDoneRight
        '
        Me.btnOrdersDoneRight.Location = New System.Drawing.Point(24, 104)
        Me.btnOrdersDoneRight.Name = "btnOrdersDoneRight"
        Me.btnOrdersDoneRight.Size = New System.Drawing.Size(156, 28)
        Me.btnOrdersDoneRight.TabIndex = 9
        Me.btnOrdersDoneRight.Text = "Orders (done right)"
        '
        'suppliers
        '
        Me.suppliers.BackColor = System.Drawing.Color.Red
        Me.suppliers.Location = New System.Drawing.Point(112, 24)
        Me.suppliers.Name = "suppliers"
        Me.suppliers.Size = New System.Drawing.Size(68, 28)
        Me.suppliers.TabIndex = 2
        Me.suppliers.Text = "Suppliers"
        '
        'products
        '
        Me.products.BackColor = System.Drawing.Color.Red
        Me.products.Location = New System.Drawing.Point(24, 64)
        Me.products.Name = "products"
        Me.products.Size = New System.Drawing.Size(68, 28)
        Me.products.TabIndex = 1
        Me.products.Text = "Products"
        '
        'orders
        '
        Me.orders.Location = New System.Drawing.Point(112, 64)
        Me.orders.Name = "orders"
        Me.orders.Size = New System.Drawing.Size(68, 28)
        Me.orders.TabIndex = 3
        Me.orders.Text = "Orders"
        '
        'categories
        '
        Me.categories.BackColor = System.Drawing.Color.Red
        Me.categories.Location = New System.Drawing.Point(24, 24)
        Me.categories.Name = "categories"
        Me.categories.Size = New System.Drawing.Size(68, 28)
        Me.categories.TabIndex = 0
        Me.categories.Text = "Categories"
        '
        'printSalesReports
        '
        Me.printSalesReports.BackColor = System.Drawing.Color.Red
        Me.printSalesReports.Location = New System.Drawing.Point(236, 180)
        Me.printSalesReports.Name = "printSalesReports"
        Me.printSalesReports.Size = New System.Drawing.Size(140, 28)
        Me.printSalesReports.TabIndex = 5
        Me.printSalesReports.Text = "Print Sales Reports"
        '
        'versionNumber
        '
        Me.versionNumber.Location = New System.Drawing.Point(8, 216)
        Me.versionNumber.Name = "versionNumber"
        Me.versionNumber.Size = New System.Drawing.Size(184, 20)
        Me.versionNumber.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(184, 216)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(224, 23)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "� Proudly developed by www.ssw.com.au"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'MainSwitchboardForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(412, 233)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.exitProgram)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.printSalesReports)
        Me.Controls.Add(Me.versionNumber)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "MainSwitchboardForm"
        Me.Text = "Main Switchboard"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub orders_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles orders.Click
        System.Windows.Forms.Cursor.Current = Cursors.WaitCursor

        Dim OrdersForm As New OrdersForm
        OrdersForm.Show()

        ' TIP: Since none of the form's properties or methods
        ' are used, the following code could be used:
        ' Call New OrdersForm().Show()

        System.Windows.Forms.Cursor.Current = Cursors.Default
    End Sub

    Private Sub exitProgram_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitProgram.Click
        Application.Exit()
    End Sub

    Private Sub MainSwitchboardForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.versionNumber.Text = "Version " + Application.ProductVersion.Substring(0, Application.ProductVersion.Length - 4)
    End Sub

    Private Sub btnOrdersDoneRight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrdersDoneRight.Click
        Dim SearchForm As New SearchForm
        SearchForm.Show()
    End Sub

End Class
