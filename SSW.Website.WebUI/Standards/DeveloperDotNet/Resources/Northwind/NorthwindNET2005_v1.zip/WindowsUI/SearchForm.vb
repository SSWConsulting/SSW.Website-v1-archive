Imports System.Data.SqlClient
Imports SSW.Framework.WindowsUI.Search
Imports DataSets
Imports DataAccess
Imports System.Configuration

Public Class SearchForm
    Inherits Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents OrdersSearchPanel As SSW.Framework.WindowsUI.Search.SearchPanel
    Friend WithEvents ordersList As DataSets.OrdersDataSet
    Friend WithEvents DataGridTableStyle1 As System.Windows.Forms.DataGridTableStyle
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.OrdersSearchPanel = New SSW.Framework.WindowsUI.Search.SearchPanel
        Me.ordersList = New DataSets.OrdersDataSet
        Me.DataGridTableStyle1 = New System.Windows.Forms.DataGridTableStyle
        CType(Me.ordersList, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'OrdersSearchPanel
        '
        Me.OrdersSearchPanel.DataMember = "Orders"
        Me.OrdersSearchPanel.DataSource = Me.ordersList
        Me.OrdersSearchPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.OrdersSearchPanel.Location = New System.Drawing.Point(0, 0)
        Me.OrdersSearchPanel.Name = "OrdersSearchPanel"
        Me.OrdersSearchPanel.NewSearchButtonVisible = True
        Me.OrdersSearchPanel.ResultGridTableStyles.AddRange(New System.Windows.Forms.DataGridTableStyle() {Me.DataGridTableStyle1})
        Me.OrdersSearchPanel.Size = New System.Drawing.Size(560, 445)
        Me.OrdersSearchPanel.TabControlHeight = 156
        Me.OrdersSearchPanel.TabIndex = 0
        '
        'ordersList
        '
        Me.ordersList.DataSetName = "OrdersDataSet"
        Me.ordersList.Locale = New System.Globalization.CultureInfo("en-AU")
        '
        'DataGridTableStyle1
        '
        Me.DataGridTableStyle1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.DataGridTableStyle1.MappingName = "Orders"
        Me.DataGridTableStyle1.RowHeadersVisible = False
        '
        'SearchForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(560, 445)
        Me.Controls.Add(Me.OrdersSearchPanel)
        Me.Name = "SearchForm"
        Me.Text = "SearchForm"
        CType(Me.ordersList, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Dim _dataSource As Object
    Dim _dataMember As String

    Private Const _orderID As String = "Order ID"
    Private Const _shipName As String = "Ship To Customer"

    Private Sub SearchForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.OrdersSearchPanel.SearchableCriteria.Add(New Criteria(_orderID, StringCriteriaConditions.GetInstance, CriteriaType.Standard Or CriteriaType.Advanced))
        Me.OrdersSearchPanel.SearchableCriteria.Add(New Criteria(_shipName, StringCriteriaConditions.GetInstance, CriteriaType.Standard Or CriteriaType.Advanced))
    End Sub

    Private Sub OrdersSearchPanel_OKButtonClicked(ByVal sender As Object, ByVal e As SSW.Framework.WindowsUI.Search.DataRowSelectedEventArgs) Handles OrdersSearchPanel.OKButtonClicked
        Dim row As DataRow = e.DataRow
        Dim orders As New OrdersForm
        orders.btnOK.Text = "&OK"
        orders.btnCancel.Text = "&Close"
        orders.Filter = row("OrderID").ToString
        orders.Show()
    End Sub

    Private Function GetExpression(ByVal c As SearchCriteria) As String
        If c Is Nothing Then Throw New ArgumentNullException("searchCriteria")

        If c.Condition Is StringCriteriaConditions.IsExactly Then
            Return (String.Format(GetColumnName(c.Criteria.CriteriaName) + " ='{0}'", c.Value.Replace("'", "''")))
        ElseIf c.Condition Is StringCriteriaConditions.StartsWith Then
            Return (String.Format(GetColumnName(c.Criteria.CriteriaName) + " LIKE '{0}%'", c.Value.Replace("'", "''")))
        ElseIf c.Condition Is StringCriteriaConditions.Contains Then
            Return (String.Format(GetColumnName(c.Criteria.CriteriaName) + " LIKE '%{0}%'", c.Value.Replace("'", "''")))
        ElseIf c.Condition Is StringCriteriaConditions.DoesNotContain Then
            Return (String.Format(GetColumnName(c.Criteria.CriteriaName) + " NOT LIKE '%{0}%'", c.Value.Replace("'", "''")))
        ElseIf c.Condition Is StringCriteriaConditions.IsEmpty Then
            Return ("(" + GetColumnName(c.Criteria.CriteriaName) + " IS NULL OR " + GetColumnName(c.Criteria.CriteriaName) + "='')")
        ElseIf c.Condition Is StringCriteriaConditions.IsNotEmpty Then
            Return (GetColumnName(c.Criteria.CriteriaName) + " IS NOT NULL AND " + GetColumnName(c.Criteria.CriteriaName) + "<> ''")
        End If

    End Function

    Private Function GetColumnName(ByVal criteriaName As String) As String
        Select Case criteriaName
            Case _orderID : Return "OrderID"
            Case _shipName : Return "ShipName"
            Case Else : Return criteriaName
        End Select
    End Function

    Private Sub OrdersSearchPanel_ExecuteSearch(ByVal sender As Object, ByVal criteriaSet() As SSW.Framework.WindowsUI.Search.SearchCriteria) Handles OrdersSearchPanel.ExecuteSearch

        ordersList.Clear()

        Try
            Dim criteriaSet2 As New ArrayList
            For Each s As SearchCriteria In criteriaSet
                If Not s.Value = "" Then
                    criteriaSet2.Add(GetExpression(s))
                End If
            Next

            Dim where As String = ""
            If criteriaSet2.Count > 0 Then
                where = " WHERE " + String.Join(" AND ", DirectCast(criteriaSet2.ToArray(GetType(String)), String()))
            End If

            Dim adapter As New SqlDataAdapter("SELECT * FROM Orders" & where, ConfigurationSettings.AppSettings("SqlConnection1.ConnectionString"))
            adapter.Fill(Me.ordersList, "Orders")
            'OrdersSearchPanel.DataSource = ordersList.Orders
        Catch ex As SqlException
            'MessageBox.Show(UIHelpers.GetSqlServerError(ex.Message), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub OrdersSearchPanel_CloseButtonClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles OrdersSearchPanel.CloseButtonClick
        Me.Dispose()
    End Sub

End Class
