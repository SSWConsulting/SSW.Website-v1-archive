Imports DataSets

Public Class Orders

    Public Function CalculateSubtotal(ByVal OrderLineItems As Array) As Decimal
        Dim Subtotal As Decimal

        Dim LineItem As OrdersDataSet.Order_DetailsRow
        For Each LineItem In OrderLineItems
            Subtotal += Convert.ToDecimal(LineItem.ExtendedPrice)
        Next

        Return Subtotal
    End Function

    Public Function CalculateTotal(ByVal Subtotal As Decimal, ByVal Freight As Decimal) As Decimal
        Dim Total As Decimal

        Total = Subtotal + Freight

        Return Total
    End Function

End Class
