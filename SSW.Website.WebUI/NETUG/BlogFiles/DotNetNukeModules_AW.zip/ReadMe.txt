Source Code Instructions:
=========================

1. Unzip the solution into your DotNetNuke installation directory (typically this would be C:\DotNetNuke)
2. Make sure that the UG.Testimonial project is setup to compile into the DotNetNuke\bin directory.
3. Run the db create script on your DotNetNuke db. They are in the "SSW.DNN\Database\Create Scripts" directory.
4. Run the db scripts from the NextGen code generator. They are in "SSW.DNN\Database\Auto-Generated Stored Procedures" directory.
5. Compile
6. Using DotNetNuke Module Definitions editor add the new module to the site.
	a) Testimonials.ascx as a View type
	b) EditTestimonialOptions.ascx as a Edit type with the key "Options"
7. Add the new module to the page.

Code Generator:
===============

Download it from http://www.radsoftware.com.au

To use it:
1. Reset the DB connection string
2. Open the .ngproj file provided. Its in the "SSW.DNN" directory, and its also added as a solution item.
3. Make sure that you select the Testimonial table on the objects listing.
4. Then generate.