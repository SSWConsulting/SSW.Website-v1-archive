Imports DotNetNuke

Namespace UG.DNN

    Public Class EditTestimonialOptions
        Inherits PortalModuleControl

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub
        Protected WithEvents lnkUpdate As System.Web.UI.WebControls.LinkButton
        Protected WithEvents lnkCancel As System.Web.UI.WebControls.LinkButton
        Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            ' AW: Add Load Settings to Options
            If Not IsPostBack Then
                If Not Settings("TestimonialMode") Is Nothing Then
                    DropDownList1.SelectedValue = CStr(Settings("TestimonialMode"))
                End If
            End If

        End Sub

        Private Sub lnkUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkUpdate.Click
            ' Update the module settings.
            Dim objModules As New DotNetNuke.ModuleController
            objModules.UpdateModuleSetting(ModuleId, "TestimonialMode", DropDownList1.SelectedValue)

            Response.Redirect(NavigateURL)

        End Sub

        Private Sub lnkCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lnkCancel.Click

            Response.Redirect(NavigateURL)

        End Sub
    End Class
End Namespace

