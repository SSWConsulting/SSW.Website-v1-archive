using System;
using System.Configuration;

using RAD.AppFramework.Data;
using RAD.AppFramework.QueryObjects;

using DotNetNuke;

namespace SSW.DNN.Common
{
	/// <summary>
	/// AbstractDataObjectFactory creates the 
	/// appropriate DatabaseAccessObjectFactory for the application
	/// </summary>
	public class CommonFactory
	{

		// Which provider do we want to query DNN for?
		private const string ProviderType = "data";

		public static string ConnectionString
		{
			// Add get method to ask DotNetNuke for its connection string...
			get
			{
				// Read the configuration specific information for this provider
				ProviderConfiguration objProviderConfiguration = ProviderConfiguration.GetProviderConfiguration(ProviderType);
				Provider objProvider = (Provider)objProviderConfiguration.Providers[objProviderConfiguration.DefaultProvider];

				// Read the attributes for this provider
				if (objProvider.Name != "SqlDataProvider")
					throw new NotSupportedException("Only a SQL Server database is supported at this point in time. Alter the DotNetNuke web.config to use SqlDataProvider by default.");

				// Note: That there is DotNetNuke.Globals.GetDBConnectionString()
				return objProvider.Attributes["connectionString"];
			}

		}


		/// <summary>
		/// Creates a DataObject Factory
		/// </summary>
		/// <returns>a DatabaseAccessObjectFactory</returns>
		public static DatabaseAccessObjectFactory CreateDataObjectFactory()
		{
			return new SqlDatabaseAccessObjectFactory(ConnectionString); 
		}
		
		/// <summary>
		/// Creates a Query with the appropriate QueryBuilder for the database connection
		/// </summary>
		/// <returns>a new Query</returns>
		public static Query CreateQuery()
		{
			return new Query(new SqlServerQueryBuilder());
		}

		/// <summary>
		/// An instance of this class cannot be created
		/// </summary>
		private CommonFactory()
		{
		}
	}
}
