using System;
using System.Data;

using RAD.AppFramework.Reflection;

namespace SSW.DNN.DatabaseSchema
{
	/// <summary>
	/// Defines the schema of the Testimonial table for use with the Query objects
	/// </summary>
	[DatabaseTable("viewTestimonial")]
	public enum TestimonialTable
	{
		/// <summary>
		/// TestimonialID Column 
		/// </summary>
		[DatabaseColumn("TestimonialID", DbType.Int32, AllowDBNull=false)]
		TestimonialID,
		
		/// <summary>
		/// AuthorName Column 
		/// </summary>
		[DatabaseColumn("AuthorName", DbType.AnsiString, Length=100, AllowDBNull=false)]
		AuthorName,
		
		/// <summary>
		/// CompanyName Column 
		/// </summary>
		[DatabaseColumn("CompanyName", DbType.AnsiString, Length=100)]
		CompanyName,
		
		/// <summary>
		/// AuthorWebsite Column 
		/// </summary>
		[DatabaseColumn("AuthorWebsite", DbType.AnsiString, Length=255)]
		AuthorWebsite,
		
		/// <summary>
		/// Quote Column 
		/// </summary>
		[DatabaseColumn("Quote", DbType.AnsiString, AllowDBNull=false)]
		Quote

	}
}
