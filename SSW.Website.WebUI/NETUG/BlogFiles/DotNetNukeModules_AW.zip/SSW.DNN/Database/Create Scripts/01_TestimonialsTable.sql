if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[Testimonial]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[Testimonial]
GO

CREATE TABLE [dbo].[Testimonial] (
	[TestimonialID] [int] IDENTITY (1, 1) NOT NULL ,
	[AuthorName] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL ,
	[CompanyName] [varchar] (100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[AuthorWebsite] [varchar] (255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL ,
	[Quote] [text] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL 
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

