Imports DotNetNuke
Imports SSW.DNN.BusinessService
Imports SSW.DNN.Data

Namespace UG.DNN

    Public Enum TestimonialMode
        SingleRandom = 1
        List = 2
    End Enum

    Public Class Testimonial
        Inherits PortalModuleControl

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.dstTestimonial = New SSW.DNN.Data.TestimonialDataSet
            CType(Me.dstTestimonial, System.ComponentModel.ISupportInitialize).BeginInit()
            '
            'dstTestimonial
            '
            Me.dstTestimonial.DataSetName = "TestimonialDataSet"
            Me.dstTestimonial.Locale = New System.Globalization.CultureInfo("en-US")
            CType(Me.dstTestimonial, System.ComponentModel.ISupportInitialize).EndInit()

        End Sub
        Protected WithEvents dgTestimonials As System.Web.UI.WebControls.DataGrid
        Protected WithEvents lblMessage As System.Web.UI.WebControls.Label
        Protected WithEvents dstTestimonial As SSW.DNN.Data.TestimonialDataSet

        'NOTE: The following placeholder declaration is required by the Web Form Designer.
        'Do not delete or move it.
        Private designerPlaceholderDeclaration As System.Object

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()

            MyBase.Actions.Add(GetNextActionID, "View Options", "", URL:=EditURL(, , "Options"), secure:=SecurityAccessLevel.Edit, Visible:=True)

        End Sub

#End Region

        Dim mMode As TestimonialMode = TestimonialMode.SingleRandom
        
        ''' <summary>
        ''' Property Mode (TestimonialMode)
        ''' </summary>
        ''' <value></value>
        Public Property Mode As TestimonialMode
            Get
                Return mMode
            End Get
            Set(Byval Value As TestimonialMode)
                mMode = Value
            End Set
        End Property

        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

            If Not IsPostBack Then

                If Not Settings("TestimonialMode") Is Nothing Then
                    Try
                        Mode = [Enum].Parse(GetType(TestimonialMode), Settings("TestimonialMode"))
                    Catch ex As Exception
                        ' Use default value on invalid...
                    End Try
                End If

                ' Load based on the mode that we want the module instance to run as...
                If Mode = TestimonialMode.SingleRandom Then
                    LoadRandom()
                Else
                    LoadAll()
                End If

                dgTestimonials.DataBind()
            End If

        End Sub


        Sub LoadRandom()
            Dim svc As New TestimonialService
            svc.GetSingleRandom(dstTestimonial)
        End Sub


        Sub LoadAll()
            Dim svc As New TestimonialService
            svc.GetAll(dstTestimonial)
        End Sub

    End Class

End Namespace

