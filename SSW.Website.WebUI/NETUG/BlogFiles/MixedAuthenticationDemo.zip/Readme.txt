--------------------
Mixed Authentication
--------------------

1. Make a virtual directory in IIS to the WebUI directory - we called the virtual directory "MixedAuthenticationDemo".
2. In IIS, turn off Anonymous access to the WebUI/Authentication/WinLogin.aspx

--------------------

Now when accessing Secured.aspx you should be auto logged in with your login if you use Windows XP, or you'll be pushed to the weblogin page otherwise.


