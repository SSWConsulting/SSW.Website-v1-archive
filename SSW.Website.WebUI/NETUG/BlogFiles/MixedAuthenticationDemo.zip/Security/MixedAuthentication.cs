using System;
using System.Web;
using System.Configuration;

namespace SSW.MixedAuthenticationDemo.Security
{
	/// <summary>
	/// Summary description for MixedAuthentication.
	/// </summary>
	public class MixedAuthentication
	{
		public MixedAuthentication()
		{
		}


		public static string DefaultPage
		{
			get
			{
				string value = ConfigurationSettings.AppSettings["DefaultPage"];
				if( value == null)
				{
					value = "/";
				}
				return value;
			}
		}


		public static string WinLoginPage
		{
			get
			{
				string value = ConfigurationSettings.AppSettings["WinLoginPage"];
				if( value == null)
				{
					value = "/";
				}
				return value;
			}
		}


		public static string WebLoginPage
		{
			get
			{
				string value = ConfigurationSettings.AppSettings["WebLoginPage"];
				if( value == null)
				{
					value = "/";
				}
				return value;
			}
		}


		public static bool UseIntegratedAuthentication()
		{
			// NOTE: Could tailor it to meet other purposes
			return (HttpContext.Current.Request.Browser.Platform.ToUpper() == "WINXP");
		}

		public static string GetAuthenticationUrl()
		{
			return GetAuthenticationUrl(String.Empty);
		}

		public static string GetAuthenticationUrl( string sReturnUrl)
		{
			string sAuthenticationUrl;
			if( UseIntegratedAuthentication())
			{
				sAuthenticationUrl = WinLoginPage;
			}
			else
			{
				sAuthenticationUrl = WebLoginPage;
			}

			if( sReturnUrl.Length > 0)
			{
				sAuthenticationUrl += String.Format("?ReturnUrl={0}", sReturnUrl);
			}
			else
			{
				sAuthenticationUrl += String.Format("?ReturnUrl={0}", DefaultPage);
			}

			return sAuthenticationUrl;
		}
	}
}
