using System;

namespace ThirdPartyTools
{
	/// <summary>
	/// Summary description for FunkyDataProvider.
	/// </summary>
	public class FunkyDataProvider : Business.IDataProvider
	{
		
		#region | IDataProvider Members 

		public string GetProviderName()
		{
			return "Funky Third Party Provider";
		}

		public string[] GetMovies(string searchRegion)
		{
			switch (searchRegion.ToLower())
			{
				case "canberra":
					return new string[] { "Romeo and Juliet",
											"Othello",
											"Twelth Night",
											"Amadeus" };
				case "sydney":
					return new string[] { "Nothing screening." };
				default:
					return new string[] {};
			}
		}

		#endregion

	}
}
