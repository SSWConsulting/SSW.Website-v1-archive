using System;

namespace Business
{
	public interface IDataProvider
	{

		string GetProviderName();

		string[] GetMovies(string searchRegion);

	}
}