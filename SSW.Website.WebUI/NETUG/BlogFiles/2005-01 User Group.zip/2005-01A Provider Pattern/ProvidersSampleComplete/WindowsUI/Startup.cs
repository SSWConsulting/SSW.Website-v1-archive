using System;
using System.Windows.Forms;

namespace WindowsUI
{
	/// <summary>
	/// Summary description for Startup.
	/// </summary>
	public class Startup
	{
		
		[STAThread()]
		public static void Main()
		{
			Application.EnableVisualStyles();
			Application.DoEvents();

			Application.Run(new MainForm());
		}

	}
}
