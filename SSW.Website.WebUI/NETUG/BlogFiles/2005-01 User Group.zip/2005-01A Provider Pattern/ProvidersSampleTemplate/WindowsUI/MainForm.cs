using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;
using System.Windows.Forms;

using Business;

namespace WindowsUI
{
	/// <summary>
	/// Summary description for MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ListBox searchResults;
		private System.Windows.Forms.Button searchButton;
		private System.Windows.Forms.TextBox searchRegion;
		private System.Windows.Forms.Label providerName;
		private System.Windows.Forms.Label label2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.searchResults = new System.Windows.Forms.ListBox();
			this.searchButton = new System.Windows.Forms.Button();
			this.searchRegion = new System.Windows.Forms.TextBox();
			this.providerName = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// searchResults
			// 
			this.searchResults.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.searchResults.IntegralHeight = false;
			this.searchResults.Location = new System.Drawing.Point(8, 56);
			this.searchResults.Name = "searchResults";
			this.searchResults.Size = new System.Drawing.Size(384, 221);
			this.searchResults.TabIndex = 0;
			// 
			// searchButton
			// 
			this.searchButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.searchButton.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.searchButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.searchButton.Location = new System.Drawing.Point(317, 8);
			this.searchButton.Name = "searchButton";
			this.searchButton.TabIndex = 1;
			this.searchButton.Text = "Search";
			this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
			// 
			// searchRegion
			// 
			this.searchRegion.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.searchRegion.Location = new System.Drawing.Point(8, 8);
			this.searchRegion.Name = "searchRegion";
			this.searchRegion.Size = new System.Drawing.Size(301, 20);
			this.searchRegion.TabIndex = 2;
			this.searchRegion.Text = "";
			// 
			// providerName
			// 
			this.providerName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.providerName.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.providerName.Location = new System.Drawing.Point(64, 32);
			this.providerName.Name = "providerName";
			this.providerName.Size = new System.Drawing.Size(240, 16);
			this.providerName.TabIndex = 3;
			this.providerName.Text = "[none loaded yet]";
			this.providerName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.label2.Location = new System.Drawing.Point(8, 32);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 16);
			this.label2.TabIndex = 3;
			this.label2.Text = "Provider:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// MainForm
			// 
			this.AcceptButton = this.searchButton;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(400, 285);
			this.Controls.Add(this.providerName);
			this.Controls.Add(this.searchRegion);
			this.Controls.Add(this.searchButton);
			this.Controls.Add(this.searchResults);
			this.Controls.Add(this.label2);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(408, 319);
			this.Name = "MainForm";
			this.Text = "Movie Session Finder";
			this.ResumeLayout(false);

		}
		#endregion

		private void searchButton_Click(object sender, System.EventArgs e)
		{
			DataProvider provider = new DataProvider();
			searchResults.DataSource = provider.GetMovies(searchRegion.Text);
		}

	}
}