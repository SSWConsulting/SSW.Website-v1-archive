using System;

namespace Business
{
	public class DataProvider
	{
		public DataProvider()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public string[] GetMovies(string searchRegion)
		{
			switch (searchRegion.ToLower())
			{
				case "canberra":
					return new string[] { "They don't know what movies are yet." };
				case "sydney":
					return new string[] { "The Bourne Supremacy",
											"Mean Girls",
											"Shakespeare in Love",
											"The Girl Next Door",
											"Nemo - the most boring fish ever" };
				default:
					return new string[] {};
			}
		}

	}
}