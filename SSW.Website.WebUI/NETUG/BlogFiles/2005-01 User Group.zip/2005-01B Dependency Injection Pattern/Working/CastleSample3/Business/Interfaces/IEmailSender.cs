using System;

namespace Business.Interfaces
{
	/// <summary>
	/// Summary description for IEmailSender.
	/// </summary>
	public interface IEmailSender
	{
		
		void Send(string from, string to, string message);
	}
}
