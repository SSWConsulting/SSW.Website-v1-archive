using System;

namespace Business.Interfaces
{
	/// <summary>
	/// Summary description for INewsletterService.
	/// </summary>
	public interface INewsletterService
	{
		
		void Dispatch(string from, string[] targets, string templateName);
	}
}
