using System;

namespace Business
{
	/// <summary>
	/// Summary description for NewsletterTemplateEngine.
	/// </summary>
	public class BasicTemplateEngine : Interfaces.ITemplateEngine
	{
		

		public string Format(string templateName)
		{
			switch (templateName)
			{
				case "xmas":
					return "Merry christmas!";
				case "nye":
					return "Happy new year!";
				default:
					throw new ArgumentException("Unexepected template name was supplied.", "templateName");
			}
		}
	}
}
