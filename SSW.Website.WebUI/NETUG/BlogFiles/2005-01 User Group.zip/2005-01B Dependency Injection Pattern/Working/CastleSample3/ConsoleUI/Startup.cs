using System;
using Business;
using Business.Interfaces;
using Castle.Windsor;

namespace ConsoleUI
{
	class Startup
	{

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{

			IWindsorContainer container = new WindsorContainer();
			
			container.AddComponent("newsletter", typeof(INewsletterService), typeof(BasicNewsletterService));
			container.AddComponent("smtpEmailSender", typeof(IEmailSender), typeof(SmtpEmailSender));
			container.AddComponent("exchangeEmailSender", typeof(IEmailSender), typeof(ExchangeEmailSender));
			container.AddComponent("templateEngine", typeof(ITemplateEngine), typeof(BasicTemplateEngine));

			string[] targets = new string[] { "reddog@gmail.com", "bluedog@gmail.com", "greendog@gmail.com", "orangedog@gmail.com" };
			
			INewsletterService service = (INewsletterService)container[typeof(INewsletterService)];
			service.Dispatch("tatham@e-oddie.com", targets, "xmas");

			Console.ReadLine();
		}

	}
}