using System;

namespace Business
{
	public class BasicNewsletterService : Interfaces.INewsletterService
	{
		private Interfaces.ITemplateEngine templateEngine;
		private Interfaces.IEmailSender emailSender;

		public BasicNewsletterService(Interfaces.ITemplateEngine templateEngine, Interfaces.IEmailSender emailSender)
		{
			this.templateEngine = templateEngine;
			this.emailSender = emailSender;
		}

		public void Dispatch(string from, string[] targets, string templateName)
		{
			string message = templateEngine.Format(templateName);

			foreach (string target in targets)
				emailSender.Send(from, target, message);
		}

	}
}
