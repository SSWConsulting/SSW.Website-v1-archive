using System;

namespace Business
{
	public class BasicTemplateEngine : Interfaces.ITemplateEngine
	{

		public BasicTemplateEngine()
		{
		}

		public string Format(string templateName)
		{
			switch (templateName)
			{
				case "xmas":
					return "Merry christmas!";
				case "nye":
					return "Happy new year!";
				default:
					throw new ArgumentException("Unexepected template name was supplied.", "templateName");
					//TO: Create NewsletterService
			}
		}

	}
}