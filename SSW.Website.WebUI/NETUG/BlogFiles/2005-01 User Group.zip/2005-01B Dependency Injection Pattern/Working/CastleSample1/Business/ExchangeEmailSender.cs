using System;

namespace Business
{
	/// <summary>
	/// Summary description for ExchangeEmailSender.
	/// </summary>
	public class ExchangeEmailSender : Interfaces.IEmailSender
	{
		private string hostname;

		public string Hostname
		{
			get
			{
				return hostname;
			}
			set
			{
				hostname = value;
			}
		}

		public ExchangeEmailSender()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region IEmailSender Members

		public void Send(string from, string to, string message)
		{
			string outputTemplate = "Sent via Exchange to {0}: {1}";

			Console.WriteLine(string.Format(outputTemplate, to, message));
		}

		#endregion
	}
}
