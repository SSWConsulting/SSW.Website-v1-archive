using System;

namespace Business.Interfaces
{
	/// <summary>
	/// Summary description for ITemplateEngine.
	/// </summary>
	public interface ITemplateEngine
	{
		
		string Format(string templateName);

	}
}
