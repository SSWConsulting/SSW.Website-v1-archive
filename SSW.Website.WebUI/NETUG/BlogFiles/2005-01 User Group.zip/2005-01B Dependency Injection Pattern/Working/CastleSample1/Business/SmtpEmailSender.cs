using System;
using System.Configuration;

namespace Business
{
	public class SmtpEmailSender: Interfaces.IEmailSender
	{
		private string hostname;
		private int port;

		public SmtpEmailSender(string hostname, int port)
		{
			this.hostname = hostname;
			this.port = port;
		}

		public void Send(string from, string to, string message)
		{
			string outputTemplate = "Sent via SMTP to {0}: {1}";

			Console.WriteLine(string.Format(outputTemplate, to, message));
			//TO: Create NewsletterTemplateEngine
		}
	}
}