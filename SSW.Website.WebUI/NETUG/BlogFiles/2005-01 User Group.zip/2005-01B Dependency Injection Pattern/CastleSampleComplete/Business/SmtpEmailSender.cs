using System;

namespace Business
{
	public class SmtpEmailSender : Interfaces.IEmailSender
	{
		private string host;
		private int port;

		public SmtpEmailSender(string host, int port)
		{
			this.host = host;
			this.port = port;
		}

		#region IEmailSender Members

		public void Send(string from, string to, string message)
		{
			string outputTemplate = "Sent via SMTP from {0} to {1} with the message: {2}";

			Console.WriteLine(string.Format(outputTemplate, from, to, message));
		}

		#endregion
	}
}