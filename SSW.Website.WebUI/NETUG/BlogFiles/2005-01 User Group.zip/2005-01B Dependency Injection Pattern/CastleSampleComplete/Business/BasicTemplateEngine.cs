using System;

namespace Business
{
	public class BasicTemplateEngine : Interfaces.ITemplateEngine
	{
		public BasicTemplateEngine()
		{
			
		}

		#region ITemplateEngine Members

		public string Format(string templateName)
		{
			if (templateName == "xmas")
				return "Merry Chistmas";
			else if (templateName == "nye")
				return "Happy New Year!";
			else
				throw new ArgumentException("The specified template name was not recognised.", "templateName");
		}

		#endregion
	}
}