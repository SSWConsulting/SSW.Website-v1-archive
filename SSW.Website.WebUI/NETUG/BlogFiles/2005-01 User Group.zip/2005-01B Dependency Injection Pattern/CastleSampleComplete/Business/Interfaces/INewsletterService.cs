using System;

namespace Business.Interfaces
{
	public interface INewsletterService
	{
		
		void Dispatch(string from, string[] targets, string templateName);

	}
}