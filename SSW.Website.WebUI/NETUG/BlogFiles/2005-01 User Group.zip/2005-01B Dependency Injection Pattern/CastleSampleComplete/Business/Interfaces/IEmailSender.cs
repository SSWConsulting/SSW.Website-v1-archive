using System;

namespace Business.Interfaces
{
	public interface IEmailSender
	{
		
		void Send(string from, string to, string message);

	}
}