using System;

namespace Business.Interfaces
{
	public interface ITemplateEngine
	{
		
		string Format(string templateName);

	}
}