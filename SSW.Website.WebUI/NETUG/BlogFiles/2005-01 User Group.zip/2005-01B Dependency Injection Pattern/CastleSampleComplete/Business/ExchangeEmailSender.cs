using System;

namespace Business
{
	/// <summary>
	/// Summary description for ExchangeEmailSender.
	/// </summary>
	public class ExchangeEmailSender : Interfaces.IEmailSender
	{
		private string exchangeHost;

		public ExchangeEmailSender(string exchangeHost)
		{
			this.exchangeHost = exchangeHost;
		}

		#region IEmailSender Members

		public void Send(string from, string to, string message)
		{
			string outputTemplate = "Sent via Exchange from {0} to {1} with the message: {2}";

			Console.WriteLine(string.Format(outputTemplate, from, to, message));
		}

		#endregion
	}
}
