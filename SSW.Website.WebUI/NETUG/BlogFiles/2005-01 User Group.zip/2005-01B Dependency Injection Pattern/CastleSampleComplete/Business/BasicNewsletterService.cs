using System;

namespace Business
{
	public class BasicNewsletterService : Interfaces.INewsletterService
	{
		private Interfaces.IEmailSender emailSender;
		private Interfaces.ITemplateEngine templateEngine;

		public BasicNewsletterService(Interfaces.IEmailSender emailSender, Interfaces.ITemplateEngine templateEngine)
		{
			this.emailSender = emailSender;
			this.templateEngine = templateEngine;
		}

		#region INewsletterService Members

		public void Dispatch(string from, string[] targets, string templateName)
		{
			string message = templateEngine.Format(templateName);

			foreach(string target in targets)
				emailSender.Send(from, target, message);
		}

		#endregion
	}
}