
More information about Castle.InversionOfControl 
can be found at http://www.castleproject.org/container/

