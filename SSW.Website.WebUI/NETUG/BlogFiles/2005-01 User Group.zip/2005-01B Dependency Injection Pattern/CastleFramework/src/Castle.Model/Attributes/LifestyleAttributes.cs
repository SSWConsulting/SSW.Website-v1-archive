// Copyright 2004 DigitalCraftsmen - http://www.digitalcraftsmen.com.br/
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

namespace Castle.Model
{
	using System;

	[AttributeUsage(AttributeTargets.Class)]
	public abstract class LifestyleAttribute : Attribute
	{
		private LifestyleType _type;

		protected LifestyleAttribute(LifestyleType type)
		{
			_type = type;
		}

		public LifestyleType LifestyleType
		{
			get { return _type; }
			set { _type = value; }
		}
	}

	/// <summary>
	/// Summary description for LifestyleAttributes.
	/// </summary>
	[AttributeUsage(AttributeTargets.Class)]
	public class SingletonAttribute : LifestyleAttribute
	{
		public SingletonAttribute() : base(LifestyleType.Singleton)
		{
				
		}
	}

	[AttributeUsage(AttributeTargets.Class)]
	public class TransientAttribute : LifestyleAttribute
	{
		public TransientAttribute() : base(LifestyleType.Transient)
		{
				
		}
	}

	[AttributeUsage(AttributeTargets.Class)]
	public class PerThreadAttribute : LifestyleAttribute
	{
		public PerThreadAttribute() : base(LifestyleType.Thread)
		{
			
		}
	}

	[AttributeUsage(AttributeTargets.Class)]
	public class CustomLifestyleAttribute : LifestyleAttribute
	{
		private Type _lifestyleHandler;

		public CustomLifestyleAttribute( Type lifestyleHandler ) : base(LifestyleType.Custom)
		{
			_lifestyleHandler = lifestyleHandler;
		}

		public Type LifestyleHandlerType
		{
			get { return _lifestyleHandler; }
		}
	}
}
